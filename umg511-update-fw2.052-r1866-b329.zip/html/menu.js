/*Menu*/
var menu = [{
    'firstElement': {
        "href": "/index.html",
        'content': 'menu.start'
    },
    'sub': [{
        "href": "/display.html",
        'content': 'menu.display'
    }]

}, {
    'firstElement': {
        "href": "/info.html",
        'content': 'menu.Information',
        'id': "infosubmenu"
    },	
    'sub': [{
        "href": "/info_u.html",
        'content': 'menu.voltage'
    }, {
        "href": "/info_fft.html",
        'content': 'menu.fft'
    },{
        "href": "/info_flk.html",
        'content': 'menu.flicker'
    }, {
        "href": "/info_i.html",
        'content': 'menu.current'
    }, {
        "href": "/info_p.html",
        'content': 'menu.power'
    }, {
        "href": "/info_w.html",
        'content': 'menu.energy'
    }, {
        "href": "/info_ext.html",
        'content': 'menu.periphery'
    }]
}, {
    'firstElement': {
        "href": "/info_events.html",
        'content': 'menu.records',
        'id': "recsubmenu"
    },	
    'sub': [
	 {
        "href": "/info_events.html",
        'content': 'menu.events'
    }, {
        "href": "/info_trns.html",
        'content': 'menu.transient'
    }, {
        "href": "/info_hist.html",
        'content': 'menu.hist'
    }]
}, {
    'firstElement': {
        "href": "/conf_ident.html",
        'content': 'menu.config',
        'id': "confsubmenu"
    },
    'sub': [{
        "href": "/conf_ident.html",
        'content': 'menu.identity'
    }, {
        "href": "/conf_transformator.html",
        'content': 'menu.transformer'
    }, {
        "href": "/conf_nominal.html",
        'content': 'menu.nominal'
    }, {
        "href": "/conf_events.html",
        'content': 'menu.events'
    }, {
        "href": "/conf_eventsrecord.html",
        'content': 'menu.recordevents'
    }, {
        "href": "/conf_trans.html",
        'content': 'menu.transient'
    }, {
        "href": "/conf_transrecord.html",
        'content': 'menu.recordtransient'
    }, {
        "href": "/conf_timezone.html",
        'content': 'menu.timezone'
    }]

}, {
    'firstElement': {
        "href": "/help.html",
        'content': 'menu.help'
    },
    'sub': [{
        "href": "/help.cus.de.html",
        'content': 'menu.helpcustomize',
        'id': "help_correct_lang_link"
    }]

}, {
    'firstElement': {
        "href": "/impressum.html",
        'content': 'menu.impressum'
    },
    'sub': []

}]