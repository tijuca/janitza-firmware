RegisterLanguage =new Array(

{

"abbr":"de",

"lang":"Deutsch",

"flag":"/img/flags/de.gif",

"point":","

},



{

"abbr":"en",

"lang":"English",

"flag":"/img/flags/en.gif",

"point":"."

},



{

"abbr":"nl",

"lang":"Nederlands",

"flag":"/img/flags/nl.gif",

"point":","

},
/////////////////////////

{"default":"dummy"}

/*

 * Default Language can't be definded here.

 * Use Sysvar _LANGUAGE z.B. dummy.html?_LANGUAGE=de 

 * The fallback-language is defined in header.htm

 */

);



