var eggs = 
[
    {
        "entries":[
            {
                "menu1eb":"menu.powerquality",
                "menu2eb":-1,
                "titleDE":"IEC61000-2-4 Settings",
                "titleEN":"IEC61000-2-4 Settings",
                "href":"/app/5100306/settings.html",
                "target":"",
                "icon":"/app/5100306/iconsetting.png"
            }
        ],
        "version":"3.0.1",
        "appId":"5100306",
        "descDE":"<p>Die Norm &bdquo;IEC 61000-2-4&ldquo; legt Grenzen f&uuml;r industrielle und nicht &ouml;ffentliche Stromverteilungssysteme<br />fest. Sie bildet eine Leitnorm f&uuml;r viele Produkt- und Maschinenbaunormen und definiert Immunit&auml;tspegel der Spannungsverzerrung, die Maschinen und Anlagen in Industriebetrieben in allen Betriebszust&auml;nden einhalten m&uuml;ssen. Eine &Uuml;berschreitung dieser Pegel &ndash; insbesondere &uuml;ber l&auml;ngere Zeitr&auml;ume &ndash; f&uuml;hrt zu Ausf&auml;llen, unn&ouml;tigen Reparaturkosten und eventuellem Produktionsstillstand.</p>  <p>Um einen fehlerfreien Betrieb der installierten Anlage und Maschinen zu gew&auml;hrleisten, muss eine kontinuierliche &Uuml;berwachung der Spannungsqualit&auml;t in allen technischen Anlagen nach der IEC 61000-2-4 erfolgen.</p>  <p>Die Janitza-APP &bdquo;IEC 61000-2-4 WATCHDOG&ldquo; f&uuml;hrt automatisch die komplexe Analyse der Messdaten nach den Grenzwerten der Norm f&uuml;r den Anwender aus. Die integrierte Visualisierung, die nach dem Ampelprinzip konzipiert wurde, erlaubt eine sofortige Erkennung bei Verletzung der Grenzwerte der Norm.</p>  <p><span class=\"gve-gema-app-description-hint\">Hinweis: </span><br />Diese App ist kostenlos f&uuml;r PRO-Ger&auml;te.<br />F&uuml;r Janitza Messger&auml;te die App kompatibel* sind, kann diese Funktionserweiterung unter dem Namen IEC 61000-2-4 Watchdog, Art.Nr. 51.00.265 erworben werden.</p>  <p>* Diverse Janitza-Ger&auml;tetypen k&ouml;nnen mit einem Firmware-Update App-kompatibel gemacht werden.</p>",
        "descEN":"<p>The standard &ldquo;IEC 61000-2-4&rdquo; defines limits for industrial and private power distribution systems. It represents a guiding standard for many product and machinery construction standards and defines immunity levels for the voltage distortions that the machinery and systems in industrial operations must comply with in all operating states. If this level is exceeded &ndash; in particular over extended periods of time &ndash; this can lead to failures, unnecessary repair costs and possibly even to production shutdowns.</p>  <p>Continuous monitoring of the power quality in all technical systems per IEC 61000-2-4 is necessary in order to guarantee fault-free operation of the systems and machinery installed.</p>  <p>The Janitza APP &ldquo;IEC 61000-2-4 Watchdog&rdquo; automatically carries out the complex analysis of the measurement data in accordance with the threshold values of the standards for the user. The integrated visualisation, designed in the form of a traffic-light style indicator, enables immediate detection in the event of an infringement of the threshold values from the standard.</p>  <p><span class=\"gve-gema-app-description-hint\">Note: </span><br />This app is free of charge for PRO devices.<br />For Janitza measurement devices that are app-compatible*, this functional extension can be purchased under the name IEC 61000-2-4 Watchdog, item no. 51.00.265.</p>  <p>* A range of Janitza device types can be made app-compatible with a firmware update.</p>",
        "menu1eb":"menu.powerquality",
        "menu2eb":0,
        "titleDE":"IEC61000-2-4 Watchdog",
        "titleEN":"IEC61000-2-4 Watchdog",
        "href":"/app/5100306/index.html",
        "target":"",
        "icon":"/app/5100306/iconwatchdog.png"
    },
    {
        "entries":[
            {
                "menu1eb":"menu.powerquality",
                "menu2eb":-1,
                "titleDE":"EN50160 Settings",
                "titleEN":"EN50160 Settings",
                "href":"/app/5100305/settings.html",
                "target":"",
                "icon":"/app/5100305/iconsetting.png"
            }
        ],
        "version":"3.0.1",
        "appId":"5100305",
        "descDE":"<p>Netzr&uuml;ckwirkungen, die in &ouml;ffentlichen Stromverteilungssystemen auftreten, f&uuml;hren ebenfalls zu Verzerrungen in kundenseitigen Industrienetzen und k&ouml;nnen Sch&auml;den des Maschinenparks und Unterbrechungen der Produktionsabl&auml;ufe verursachen. Um eine dauerhafte Beeinflussung und m&ouml;gliche Sch&auml;den zu vermeiden, ist es unerl&auml;sslich die bezogene Energie einer \"Wareneingangskontrolle\" zu unterziehen. Dazu ist eine rechtssichere und kontinuierliche &Uuml;berwachung der Spannungsqualit&auml;t notwendig.</p>  <p>Die Spannungsqualit&auml;ts-APP &bdquo;EN 50160 Watchdog&ldquo; hilft, die Norminterpretation in Form einer Analyse der relevanten Daten und deren Vergleich mit den Grenzwerten direkt auf dem Messger&auml;t durchzuf&uuml;hren. Die integrierte Visualisierung, die nach dem Ampelprinzip konzipiert wurde, erlaubt eine sofortige Erkennung bei Verletzung der Grenzwerte sowie der Norm.</p>  <p><span class=\"gve-gema-app-description-hint\">Hinweis: </span><br />Diese App ist kostenlos f&uuml;r PRO-Ger&auml;te.<br />F&uuml;r Janitza-Messger&auml;te, die App-kompatibel* sind, kann diese Funktionserweiterung unter dem Namen EN50160 Watchdog, Art.Nr. 51.00.264 erworben werden.</p>  <p>* Diverse Janitza-Ger&auml;tetypen k&ouml;nnen mit einem Firmware-Update App-kompatibel gemacht werden.</p>",
        "descEN":"<p>Voltage distortions that occur in the public power distribution systems likewise lead to distortions in the customers&rsquo; industrial networks and can result in damage to machinery suites and interruptions in the production processes. In order to avoid long-term disruption and possible damage, it is essential that the energy drawn is subjected to an 'incoming goods' check. Legally secure and continuous monitoring of the power quality is necessary for this.</p>  <p>The power quality APP &ldquo;EN50160 Watchdog&rdquo; helps,it has the standard interpretation carried out directly on the measurement device, in the form of an analysis of the relevant data and its comparison with the threshold values. The integrated visualisation, designed in the form of a traffic-light style indicator, enables immediate detection in the event of an infringement of the threshold values from the standard.</p>  <p><span class=\"gve-gema-app-description-hint\">Note:</span><br />This app is free of charge for PRO devices. For Janitza measurement devices that are app-compatible*, this functional extension can be purchased under the name EN50160 Watchdog, item no. 51.00.264. * A range of Janitza device types can be made app-compatible with a firmware update.</p>",
        "menu1eb":"menu.powerquality",
        "menu2eb":0,
        "titleDE":"EN50160 Watchdog",
        "titleEN":"EN50160 Watchdog",
        "href":"/app/5100305/index.html",
        "target":"",
        "icon":"/app/5100305/753.png"
    },
    "dummy"
];