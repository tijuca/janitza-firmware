RegisterLanguage =new Array(

{

"abbr":"de",

"lang":"Deutsch",

"flag":"/img/flags/de.gif",

"point":","

},



{

"abbr":"en",

"lang":"English",

"flag":"/img/flags/en.gif",

"point":"."

},



{

"abbr":"nl",

"lang":"Nederlands",

"flag":"/img/flags/nl.gif",

"point":","

},

{

"abbr":"cz",

"lang":"\u010Ce\u0161tina",

"flag":"/img/flags/cz.gif",

"point":","

},
/*{

"abbr":"es",

"lang":"Espa\u00f1ol",

"flag":"/img/flags/es.gif",

"point":","

},*/
{

"abbr":"fr",

"lang":"Fran\u00e7ais",

"flag":"/img/flags/fr.gif",

"point":","

},
{

"abbr":"ro",

"lang":"Rom\u00e2n\u0103",

"flag":"/img/flags/ro.gif",

"point":","

},
{

"abbr":"ru",

"lang":"\u0420\u0443\u0441\u0441\u043a\u0438\u0439",

"flag":"/img/flags/ru.gif",

"point":","

},
{

"abbr":"se",

"lang":"Svenska",

"flag":"/img/flags/se.gif",

"point":","

},
{

"abbr":"tr",

"lang":"T\u00fcrk\u00e7e",

"flag":"/img/flags/tr.gif",

"point":","

},
/////////////////////////

{"default":"dummy"}

/*

 * Default Language can't be definded here.

 * Use Sysvar _LANGUAGE z.B. dummy.html?_LANGUAGE=de 

 * The fallback-language is defined in header.htm

 */

);



