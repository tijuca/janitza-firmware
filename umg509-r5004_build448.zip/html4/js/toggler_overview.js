
// EDITABLE AREA
// ==============================================================

$(document).ready(function() {
      $(".toggler").toggler();
    // Content Toggler
    // ------------------------------------------------------------
    setTimeout(function(){
       
        $('#voltage').click();
    },200);
   
});

// PLUGINS
// ==============================================================


    // Content Toggler
    // ------------------------------------------------------------ 
    $.fn.toggler = function(options) {
        
        var defaults = {
            content: '.toggle-content'
        };   
        var options = $.extend(defaults, options);   
        var heading = $(this);
        var content = $(options.content);
    
        // Hide Toggle Content
        content.css("display", "none");
        
        return this.each(function() {
            
            $(this).bind('click', function() {

                if($(this).is(".active")) {
                    if($(this).next(content)) {
                        $(this).removeClass("active").next(content).slideUp(300);        
                        $('iframe').remove();
                    }
                }
                else {
                    if($(this).is(".close-all")) {
                        heading.removeClass("active");
                        content.slideUp(300);                                          
                        $('iframe').remove();
                    }          
                    if($(this).next(content)) {                                               
                        // iframe laden en toevoegen
                         $('<iframe />', {
                            name: 'frame1',
                            id: 'frame1',
                            width: '100%',
                            marginwidth: '0',
                            marginheight: '0',
                            vspace: '0',
                            hspace: '0',
                            frameBorder: '0',
                            scrolling: 'no',
                            src: 'info-' + this.id + '.html'
                        }).appendTo($(this).next(content));
                       // slider naar beneden
                       var slider = $(this);
                        //hoogte uit iframe halen
                         $('#frame1').load(function() {
                             var $currentIFrame = $('#frame1');
                             $('#frame1').height($currentIFrame.contents().find("body #hoogte").attr('data-id')); 

                             slider.addClass("active").next(content).slideDown(300);                             
  
                         });
                    }
                }       
            });
        });
        
        
        
    };

