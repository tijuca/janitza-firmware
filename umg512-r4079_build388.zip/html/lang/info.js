RegisterLanguage =new Array(
{
"abbr":"de",
"lang":"Deutsch",
"flag":"/img/flags/de.gif",
"point":","
},

{
"abbr":"en",
"lang":"English",
"flag":"/img/flags/en.gif",
"point":"."
},

{
"abbr":"ru",
"lang":"Russian",
"flag":"/img/flags/ru.gif",
"point":","
},

{
"abbr":"es",
"lang":"Espa\u00f1ol",
"flag":"/img/flags/es.gif",
"point":","
},

{
"abbr":"tr",
"lang":"T\u00fcrk\u00e7e",
"flag":"/img/flags/tr.gif",
"point":","
},

{
"abbr":"zh_CN",
"lang":"Chinese",
"flag":"/img/flags/zh_cn.gif",
"point":","
},

{
"abbr":"zh_TW",
"lang":"Chinese Taiwan",
"flag":"/img/flags/zh_tw.gif",
"point":","
},

{
"abbr":"sr",
"lang":"srpski",
"flag":"/img/flags/sr.gif",
"point":","
},

{
"abbr":"fr",
"lang":"fran\u00e7ais",
"flag":"/img/flags/fr.gif",
"point":","
},

{
"abbr":"ja",
"lang":"japanisch",
"flag":"/img/flags/ja.gif",
"point":","
},

/////////////////////////
{"default":"dummy"}
/*
 * Default Language can't be definded here.
 * Use Sysvar _LANGUAGE z.B. dummy.html?_LANGUAGE=de 
 * The fallback-language is defined in header.htm
 */
);

