var eggs = [
/*START*/


/* EGG: <egg version="1.0" xmlns="http://pasw.janitza.de/device/core/config/ext/api/egg/xml"><internalname>IEC61000-2-4</internalname><name lang="de">IEC61000-2-4 Watchdog</name><name lang="en">IEC61000-2-4 Watchdog</name><name lang="nl">IEC61000-2-4 Watchdog</name><description lang="de"> IEC61000-2-4 Watchdog Verion 1.2&lt;br>&lt;br>&amp;copy; Janitza GmbH</description><description lang="en"> IEC61000-2-4 Watchdog Verion 1.2&lt;br>&lt;br>&amp;copy; Janitza GmbH</description><description lang="nl"> IEC61000-2-4 Watchdog Verion 1.2&lt;br>&lt;br>&amp;copy; Janitza GmbH</description><files><file>html/apps/iec/css/layout.css</file><file>html/apps/iec/css/settings.css</file><file>html/apps/iec/img/loading.gif</file><file>html/apps/iec/img/logo.png</file><file>html/apps/iec/img/stoplicht_grijs.png</file><file>html/apps/iec/img/stoplicht_groen.png</file><file>html/apps/iec/img/stoplicht_oranje.png</file><file>html/apps/iec/img/stoplicht_rood.png</file><file>html/apps/iec/index.html</file><file>html/apps/iec/js/custom.js</file><file>html/apps/iec/js/jquery-ui.js</file><file>html/apps/iec/js/settings.js</file><file>html/apps/iec/js/settingstranslation.js</file><file>html/apps/iec/js/translation.js</file><file>html/apps/iec/save.html</file><file>html/apps/iec/settings.html</file></files><homepage><parentmenu>menu.start</parentmenu><title lang="de">IEC61000-2-4 Watchdog</title><title lang="en">IEC61000-2-4 Watchdog</title><title lang="nl">IEC61000-2-4 Watchdog</title><menuord>1</menuord><target/><href>/apps/iec/index.html</href></homepage><homepage><parentmenu>menu.start</parentmenu><title lang="de">IEC61000-2-4 Settings</title><title lang="en">IEC61000-2-4 Settings</title><title lang="nl">IEC61000-2-4 Instellingen</title><menuord>1</menuord><target/><href>/apps/iec/settings.html</href></homepage><jasic><file>prg1.jas</file><file>prg0</file></jasic></egg>*/
{
     "entries":[
{
 	"menu1eb":"menu.powerquality",
	"menu2eb":"4",
	"titleDE":"IEC61000-2-4 Settings",
	"titleNL":"IEC61000-2-4 Instellingen",
	"titleEN":"IEC61000-2-4 Settings",
	"href":"/apps/iec/settings.html",
	"target":""
}],
 "version":"1.0",
	"descDE":" IEC61000-2-4 Watchdog Version 1.2<br><br>&copy; Janitza GmbH",
	"descEN":" IEC61000-2-4 Watchdog Version 1.2<br><br>&copy; Janitza GmbH",
	"descNL":" IEC61000-2-4 Watchdog Version 1.2<br><br>&copy; Janitza GmbH",
	"menu1eb":"menu.powerquality",
	"menu2eb":"0",
	"titleDE":"IEC61000-2-4 Watchdog",
	"titleNL":"IEC61000-2-4 Watchdog",
	"titleEN":"IEC61000-2-4 Watchdog",
	"href":"/apps/iec/index.html",
	"target":""
},
/*END*/
"dummy"]

