
var COUNTER_POLL_INTERVAL_MS = 15000;


REASON_UMAX = 1;
REASON_UMIN = 2;
REASON_IMAX = 3;
REASON_UOFF = 4;
var hwwdata=null;
var evtdata=null;
var counter = null;

var SUID = createid(10);

var SITE = "";


var SelectedEventElement = null;
var SelectedTransElement = null;
// Which Site?
if( document.location.href.indexOf("_events.htm")>0)SITE="EVT";
if( document.location.href.indexOf("_hww.htm")>0)SITE="HWW";
if( document.location.href.indexOf("_trns.htm")>0)SITE="TRNS";

/**
 * xPhone doesn't update scrolling div properly without this fix.
 */
function appliedPhoneRedrawFix(){
	addStyleClass( ById("list"), "ui-force-redraw");
	//addStyleClass( ById("wrapper"), "ui-force-redraw");
	window.setTimeout(function(){
		removeStyleClass(ById("list"), "ui-force-redraw");
		//removeStyleClass(ById("wrapper"), "ui-force-redraw");
	}, 100 );
}

function fillspan(id,txt){
	var obj = document.getElementById(id);	
	if(obj)obj.innerHTML = txt;
}

function FindEventsForHWW(HWW){
	var list =[];
	for(var i in evtdata){
		if(i in Array.prototype)continue;
		if(HWW.StopTime>evtdata[i].StartTime && HWW.StartTime<evtdata[i].StopTime)
			list.push(parseInt(i));
	}
	return list;
}

function FindHwwForEvent(Event){
	var list =[];
	for(var i in hwwdata){
		if(i in Array.prototype)continue;
		if(Event.StartTime<hwwdata[i].StopTime && Event.StopTime>hwwdata[i].StartTime)
		list.push(parseInt(i));
	}
	return list;
}


function Events_mouseover(evt){
	evt = (evt) ? evt : ((window.event) ? window.event : "");
	var elem = (evt.target) ? evt.target : evt.srcElement;
	return overlib(elem.getAttribute("name"));
}
function Events_mouseout(){
		nd();
}
function Events_click(evt){
	evt = (evt) ? evt : ((window.event) ? window.event : "");
	var elem = (evt.target) ? evt.target : evt.srcElement;
	document.location.href="info_events.html?show="+elem.getAttribute("alt");
}
function readableSeconds(s)
{

		if (s > 60*60) {
			var h = Math.floor(s/(60*60));
			var m = Math.floor(s/60) - h*60;
			var sec = Math.runde((s-(h*60*60+m*60)),2);
			return  h+"h "+m+"m "+sec+ "s";
		}
		if (s > 60) {
			var m = Math.floor(s/(60));
			var sec = Math.runde((s-m*60),2);
			return m+"m "+sec+ "s";
		}	
	
		return Math.runde(s,2)+"s";	
}



function hwwlist_click(evt){
	evt = (evt) ? evt : ((window.event) ? window.event : "");
	var elem = (evt.target) ? evt.target : evt.srcElement;

	if(SelectedTransElement)
		removeStyleClass( SelectedTransElement, "hwwitem_selected");


	var watchdog=10;
	while(elem.tagName!="DIV" || !(elem.className && elem.className.indexOf("hwwitem")>=0)){
	elem = elem.parentNode;
	if(watchdog--==0)break;
	}
	if(!is_phone)
		MyScrollIntoView(elem);
	ById("imageloaderani").style.visibility="visible";
	
	var iHWW = parseInt(elem.getAttribute("Name"));
	document.graphimg.src = "hww.bmp?_hww_nr="+iHWW+"&_run=mk_hww.jas&suid"+SUID;
	fillspan("info_channel", hwwdata[iHWW].Channel);
	fillspan("info_starttime", timestrActual(hwwdata[iHWW].StartTime));
	fillspan("info_duration", readableSeconds(hwwdata[iHWW].StopTime-hwwdata[iHWW].StartTime)+"s");
	fillspan("info_filename", hwwdata[iHWW].File);
	fillspan("info_run-in", hwwdata[iHWW].RunIn);
	fillspan("info_data_count", hwwdata[iHWW].DataCount);
	
	var linkstr="";
	var result = FindEventsForHWW(hwwdata[iHWW]);	
	for (var i in result) {
		if (i in Array.prototype) 
			continue;
		linkstr += "<a style=\"white-space: nowrap;\" href=\"info_events.html?show=" + (result[i]) + "\"> Event Nr." + (result[i] + 1) + "</a><br>";
	}
	fillspan("info_linkevents", linkstr);
	

	addStyleClass( elem, "hwwitem_selected");
	if(is_phone)
		appliedPhoneRedrawFix();
	SelectedTransElement = elem;
}
function translist_click(evt){
	evt = (evt) ? evt : ((window.event) ? window.event : "");
	var elem = (evt.target) ? evt.target : evt.srcElement;

	if(SelectedTransElement)
		removeStyleClass( SelectedTransElement, "transitem_selected");


	var watchdog=10;
	while(elem.tagName!="DIV" || !(elem.className && elem.className.indexOf("transitem")>=0)){
	elem = elem.parentNode;
	if(watchdog--==0)break;
	}
	if(!is_phone)
		MyScrollIntoView(elem);
	ById("imageloaderani").style.visibility="visible";
	var iTrans = parseInt(elem.getAttribute("Name"));	
	document.graphimg.src = "trans.bmp?_trans_nr="+iTrans+"&_run=mk_trans.jas&suid"+SUID;

	fillspan("info_starttime", timestrActual(trnsdata[iTrans].StartTime));
	fillspan("info_phase", "L"+(trnsdata[iTrans].phase+1) );
	fillspan("info_mode", trnsdata[iTrans].mode);
	fillspan("info_flag", trnsdata[iTrans].flag);
	fillspan("info_pre", trnsdata[iTrans].pre);
	fillspan("info_data_cnt", trnsdata[iTrans].data_cnt);
	fillspan("info_sfreq", trnsdata[iTrans].s_freq);

	addStyleClass( elem, "transitem_selected");
	if(is_phone)
		appliedPhoneRedrawFix();
	SelectedTransElement = elem;


}

function showhww(i){
	if(lastSelectedHWW)
		removeStyleClass(lastSelectedHWW,"selected_hww");
	lastSelectedHWW = ById("hwwlink"+i);
	addStyleClass(lastSelectedHWW,"selected_hww");
	document.graphimg.src = "hww.bmp?_hww_nr="+i+"&_run=mk_hww.jas&suid"+SUID;
	
}
function resultsort(a,b){
	var as = getChannelName(hwwdata[a].Channel);
	var bs = getChannelName(hwwdata[b].Channel);
	if(as[0]==bs[0]){
		return hwwdata[a].Channel > hwwdata[b].Channel
	}
	else{
		return (as[0]!='U')?1:-1;
	}
}
var lastSelectedHWW=null;
function eventlist_click(evt){
	evt = (evt) ? evt : ((window.event) ? window.event : "");
	var elem = (evt.target) ? evt.target : evt.srcElement;

	if(SelectedEventElement)
		removeStyleClass( SelectedEventElement, "eventitem_selected");
	var watchdog=10;
	while(elem.tagName!="DIV" || !(elem.className && elem.className.indexOf("eventitem")>=0)){
	elem = elem.parentNode;
	if(watchdog--==0)break;
	}
	if(!is_phone)
		MyScrollIntoView(elem);
	var iHWW = parseInt(elem.getAttribute("Name"));
	ById("imageloaderani").style.visibility="visible";
	document.graphimg.src = "hww.bmp?_hww_nr="+iHWW+"&_run=mk_hww.jas&suid"+SUID;
	
	fillspan("info_starttime", timestrActual(evtdata[iHWW].StartTime));	
	fillspan("info_duration", readableSeconds(evtdata[iHWW].StopTime-evtdata[iHWW].StartTime));
	fillspan("info_phase",  "L"+evtdata[iHWW].phase );
	fillspan("info_bound",  evtdata[iHWW].Bound +" "+evtdata[iHWW].unit);
	fillspan("info_maxval", evtdata[iHWW].maxval+" "+evtdata[iHWW].unit);
	fillspan("info_minval", evtdata[iHWW].minval+" "+evtdata[iHWW].unit);
	fillspan("info_avg", evtdata[iHWW].avg+" "+evtdata[iHWW].unit);
	fillspan("info_reason",ReasonToString(evtdata[iHWW].ReasonType) );
	var linkstr="";
	var result = FindHwwForEvent(evtdata[iHWW]);
	result.sort(resultsort)
	var selected = false;
	var selectedID=-1;
	lastSelectedHWW=null;
	for (var i in result) {
		if (i in Array.prototype) 
			continue;
		var channel = getChannelName(hwwdata[result[i]].Channel);
		var dur = "&nbsp;&nbsp;&nbsp;"+channel +" "+tl("events.duration")+": "+readableSeconds(hwwdata[result[i]].StopTime-hwwdata[result[i]].StartTime);
		linkstr += "<a id=\"hwwlink"+result[i]+"\" href=\"javascript:showhww(" + (result[i]) + ")\" onmousemove=\"return overlib('"+dur+"')\" onmouseout=\"nd();\"> " + channel + "</a><br>";
		if(channel==ReasonAndPhaseToString(evtdata[iHWW].ReasonType,evtdata[iHWW].phase))
		{
			document.graphimg.src = "hww.bmp?_hww_nr="+result[i]+"&_run=mk_hww.jas&suid"+SUID;
			selected = true;
			selectedID=result[i];
			
		}
	}
	if(result.length==0){ //Display none if no hww
		document.graphimg.src ="";
		imgready();
	}else if(!selected){
		document.graphimg.src = "hww.bmp?_hww_nr="+result[0]+"&_run=mk_hww.jas&suid"+SUID;
	}
	
	fillspan("info_linkhww", linkstr);
	if(selected){
		lastSelectedHWW = ById("hwwlink"+selectedID);
		addStyleClass(lastSelectedHWW,"selected_hww");
		}
	addStyleClass( elem, "eventitem_selected");
	if(is_phone)
		appliedPhoneRedrawFix();
	SelectedEventElement = elem;	

}
function HexToPhase(i){
	if(i==1)return 1;
	if(i==2)return 2;
	if(i==4)return 3;
	if(i==8)return 4;	
}
function getChannelName(i){
	switch(i){
		case 0:return "UL1";
		case 1:return "IL1";
		case 2:return "UL2";
		case 3:return "IL2";
		case 4:return "UL3";
		case 5:return "IL3";
		case 6:return "UL4";
		case 7:return "IL4";
		default:
			return i;
	}
}
function ReasonAndPhaseToString(reason,phase){
	var s="";
	if(reason==REASON_UMAX)return "UL"+phase;
	if(reason==REASON_UMIN)return "UL"+phase;
	if(reason==REASON_IMAX)return "IL"+phase;
	if(reason==REASON_UOFF)return "UL"+phase;
	return "(unkown)"
}
function ReasonToString(re){
	if(re==REASON_UMAX)return tl("events.overvoltage");
	if(re==REASON_UMIN)return tl("events.undervoltage");
	if(re==REASON_IMAX)return tl("events.overcurrent");		
	if(re==REASON_UOFF)return tl("events.voltageoff");		
	return re+"(unkown)"
}
function evtsort(a,b){
	return a.StartTime < b.StartTime;
}
function DataReceive(text){
	//parse:
	if(text=="\r\n"){
		LibError.Add("Return from AjaxRequest is null.");
		return;
	}

	var data =text.split("-NEXT_ARRAY-");
	hwwdata = eval( "("+data[0]+")" );
	evtdata = eval( "("+data[1]+")" );
	evtdata.sort(evtsort)
	trnsdata = eval( "("+data[2]+")" );
	counter = eval( "("+data[3]+")" );

	for(var i in evtdata){
		if(i in Array.prototype)continue;
		// Umax?
		var tmp = evtdata[i].reason>>0&0xFF;
		if( tmp  ){
			evtdata[i].unit = "V";
			evtdata[i].ReasonType = REASON_UMAX;
			evtdata[i].phase = HexToPhase(tmp);
		}
		//Umin?
		var tmp = evtdata[i].reason>>8&0xFF;
		if( tmp  ){
			evtdata[i].unit = "V";
			evtdata[i].ReasonType = REASON_UMIN;
			evtdata[i].phase = HexToPhase(tmp);
		}
		var tmp = evtdata[i].reason>>16&0xFF;
		if( tmp  ){
			evtdata[i].unit = "A";
			evtdata[i].ReasonType = REASON_IMAX;
			evtdata[i].phase = HexToPhase(tmp);
		}
		var tmp = evtdata[i].reason>>24&0xFF;
		if( tmp  ){
			evtdata[i].unit = "A";
			evtdata[i].ReasonType = REASON_UOFF;
			evtdata[i].phase = HexToPhase(tmp);
		}
		if(typeof(evtdata[i].ReasonType)=="undefined")
			LibError.Add("Event can't be parsed"+i+evtdata[i].reason)
		
	}

	
	if(SITE=="TRNS"){
		var SelectElement = 0;
		if( /show=([0-9]+)/.exec( document.location.search) )
			SelectElement=parseInt(RegExp.$1);
		var parent = document.getElementById("list");
		
		if(trnsdata.length==0){
			var el = document.createElement("div");
			el.className="transitem"+((i%2==0)?"even":"");
			el.setAttribute("name",i);
			var s ="<div style=\"float:right;font-size:12pt;color:#909090;padding:3px\">"+tl("menu.transient")+": 0"+"</b><br>";
			el.innerHTML = s;
			parent.appendChild(el);			
		}
	for(var i in trnsdata){
		if(i in Array.prototype)continue;
		var el = document.createElement("div");
		el.className="transitem"+((i%2==0)?"even":"");
		el.setAttribute("name",i);
		var s ="<div style=\"float:right;font-size:10pt;color:#C0C0C0;padding:3px\">"+(parseInt(i)+1)+"</div><b style=\"cursor:pointer\">"+tl("trans.transient")+"</b><br>";
		s+=timestrActual(trnsdata[i].StartTime);
		el.innerHTML = s;
		el.onclick=translist_click;
		parent.appendChild(el);
		
		if(i==SelectElement){
			// Fake Event in order to populate Table Info on startup
			fakeevent = {'target':el};
			translist_click(fakeevent);			
		}
		
	}
	
	}
	if(SITE=="HWW"){
		for (var i in hwwdata) {
			if(i in Array.prototype)continue;
			hwwdata[i].Channel = getChannelName(hwwdata[i].Channel);
		}
		var SelectElement = 0;
		if( /show=([0-9]+)/.exec( document.location.search) )
			SelectElement=parseInt(RegExp.$1);
		var parent = document.getElementById("list");
		if(hwwdata.length==0){
			var el = document.createElement("div");
			el.className="transitem"+((i%2==0)?"even":"");
			el.setAttribute("name",i);
			var s ="<div style=\"float:right;font-size:12pt;color:#909090;padding:3px\">"+tl("menu.hww")+": 0"+"</b><br>";
			el.innerHTML = s;
			parent.appendChild(el);			
		}
	for(var i in hwwdata){
		if(i in Array.prototype)continue;
		var el = document.createElement("div");
		el.className="hwwitem"+((i%2==0)?"even":"");
		el.setAttribute("name",i);
		var s ="<div style=\"float:right;font-size:10pt;color:#C0C0C0;padding:3px\">"+(parseInt(i)+1)+"</div><b style=\"cursor:pointer\">"+tl("hww.item")+"<br>"+tl("info.channel")+" "+hwwdata[i].Channel+"</b><br>";
		s+=timestrActual(hwwdata[i].StartTime)+" "+Math.runde(hwwdata[i].StopTime-hwwdata[i].StartTime,2)+"s";
		el.innerHTML = s;
		el.onclick=hwwlist_click;
		parent.appendChild(el);
		
		if(i==SelectElement){
			// Fake Event in order to populate Table Info on startup
			fakeevent = {'target':el};
			hwwlist_click(fakeevent);			
		}
		
	}
	}
	if(SITE=="EVT"){
		var SelectElement = 0;
		if( /show=([0-9]+)/.exec( document.location.search) )
			SelectElement=parseInt(RegExp.$1);
			
		var parent = document.getElementById("list");
			for(var i in evtdata)
			{
			if(i in Array.prototype)continue;
			var el = document.createElement("div");
			el.className="eventitem"+((i%2==0)?"even":"");
			el.setAttribute("name",i);
			var s ="<div style=\"float:right;color:#C0C0C0;padding:3px\">"+(parseInt(i)+1)+"</div><b style=\"cursor:pointer\">"+tl("events.item")+" "+ReasonToString(evtdata[i].ReasonType)+" L"+evtdata[i].phase+"</b><br>";
			s+=timestrActual(evtdata[i].StartTime)+" "+readableSeconds(evtdata[i].StopTime-evtdata[i].StartTime);
			el.innerHTML = s;
			el.onclick=eventlist_click;
			parent.appendChild(el);
		
			if(i==SelectElement){
				// Fake Event in order to populate Table Info on startup
				fakeevent = {'target':el};
				eventlist_click(fakeevent);			
			}
		
		}
	}
	if(is_phone){
		if (iListScroll != null) {
			iListScroll.position =0;
			iListScroll.refresh();
		}
	}
	
}
function informUser(reason){
	var ret = null;
	if(reason=="NEW_EVT")
		ret =confirm(tl("evthww.newvalues"));	
	if(reason=="NEW_TRANS")
		ret =confirm(tl("trans.newvalues"));
	if(ret)
		document.location.reload();
}
function poll_counters_callback(ResponseText){
	var obj = eval("("+ResponseText+")");

	if( counter["_evt_count"]!= obj["_EVT_COUNT"][0]&& (SITE=="HWW"||SITE=="EVT"))
		informUser("NEW_EVT");
	
	
	if( counter["_trans_count"]!=obj["_TRANS_COUNT"][0] && SITE=="TRNS" ){
		informUser("NEW_TRANS");
	}

	setTimeout("poll_counters()",COUNTER_POLL_INTERVAL_MS);
}
function poll_counters(){
	AjaxRequestProvider.RegisterRequest("json.do?_evt_count,_trans_count",poll_counters_callback );    	
}
	iListScroll =null
function fadein(){
	ById("graphimg").src =ById("imgpreload").src	
}
function imgready(){
	ById("imageloaderani").style.visibility="hidden";
}
function InitTransData(){
	//Fetch Data from UMG BasicPrg. async
	AjaxRequestProvider.RegisterRequest("hww.html",DataReceive );    
	setTimeout("poll_counters()",COUNTER_POLL_INTERVAL_MS);
	if(is_phone)
	iListScroll = new iScroll(document.getElementById('list'))
//	addEvent(ById("imgpreload"),"load",fadein)
	addEvent(ById("graphimg"),"load",imgready)
}

RegisterOnloadFunction(InitTransData);