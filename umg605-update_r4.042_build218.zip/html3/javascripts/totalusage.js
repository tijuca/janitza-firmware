function calculatetotals() {
    setTimeout(function() {
        todaydata();
    }, 1000);

    setInterval(function() {
        todaydata();
    }, 60000);

}

var dayminimum = 0;
var daymaximum = 0;
var monthminimum = 0;
var monthmaximum = 0;

function todaydata() {

    //////////////////////
    //Current day
    /////////////////////
    
    /* TIME CALCULATION
     * 
     * The starttime is 22.59 of the previous day, 
     * because all data is one hour in front off the real time. 
     * which means that the real starttime is 23.59. 
     * 
     * We have to compensate for the timezone.
     * 
     * This way the first data would be the data of midnight (12 o clock).
     * Therefore the second data would be the data of 1 o clock.
     * 
     * The power usage of the first hour is therefore
     * the second data minus the first data.
     * 
     * We do not have to look at timezonecalculations, because it automatically 
     * picks the gmt time when you request getTime() from javascript. 
     * 
     * 
     */
    
    var starttime = new Date();
    
    starttime.setHours(0);
    starttime.setMinutes(0);
    starttime.setSeconds(0);
    starttime.setMilliseconds(0);
    starttime.setHours(starttime.getHours() - 1);
    
    var count = 30;
    var timebase = 3600.00;
    var parameter = "_WH_V[4]";
    var todaytotal = 0;
          
    var s = starttime.getTime(); 
    s = s / 1000;   
    
    $.getJSON("hist_data/HIST_DATA.html", "val$=" + parameter + "&start=" + (s + (new Date().getTimezoneOffset() * -60)) + "&cnt=" + count + "&tb=" + timebase, function(data)
    {

        var length = data[parameter][0].length;
        var dayarray = new Array();
        var hour = 0;
        var hourtime = s + (new Date().getTimezoneOffset() * -60);
        var hourtime = hourtime;
        var previoushour = -1.11;
        var value = 0;
        
        while(value < length && hour < 25){                                                                     // => until the day is full or there is no more data       
            if(previoushour === -1.11){                                                                         // => If no starthour               
                if(data[parameter][0][value][1] === hourtime){                                                  // => if valuetime = hourtime
                    previoushour = data[parameter][0][value][0];
                    hourtime = hourtime + 3600;                                                                 // => increase hour
                    value++;                                                                                    // => increase value
                }else if(data[parameter][0][value][1] > hourtime){                                              // => if valuetime is later than hourtime
                    dayarray[hour] = 0;                                                                         // => set barvalue 0
                    hourtime = hourtime + 3600;                                                                 // => increase hour
                    hour++;                  
                }else if(data[parameter][0][value][1] < hourtime){                                              // => if valuetime is earlier than hourtime
                    value++;                                                                                    // => increase value
                }
            }else{                                                                                              // => if starthour is set
                if(data[parameter][0][value][1] === hourtime){                                                  // => if valuetime = hourtime
                    dayarray[hour] = data[parameter][0][value][0] - previoushour;                               // => set barvalue
                    if(dayarray[hour] * 1.1 > daymaximum ){ daymaximum = dayarray[hour] * 1.1;};                // => check if maximum has to be adjusted
                    if(dayarray[hour] * 1.1 < dayminimum ){ dayminimum = dayarray[hour] * 1.1;};                // => check if minimum has to be adjusted
                    previoushour = data[parameter][0][value][0];                                                // => set previoushour 
                    todaytotal = todaytotal + dayarray[hour];                                                   // => add to todaytotal
                    hourtime = hourtime + 3600;                                                                 // => increase hour
                    hour++;                   
                    value++;                                                                                    // => increase value                  
                }else if(data[parameter][0][value][1] > hourtime){                                              // => if valuetime is later than hourtime
                    dayarray[hour] = 0;                                                                         // => set barvalue 0
                    hourtime = hourtime + 3600;                                                                 // => increase hour
                    hour++;
                    previoushour = -1.11;                                                                       // => set previoushour null
                    
                }else if(data[parameter][0][value][1] < hourtime){                                              // => if valuetime is earlier than hourtime
                    value++;                                                                                    // => increase value
                }
            }
        }
        
        while(hour < 25){                                                                                       // => until the day is full
            dayarray[hour] = 0;   
            hour++;
        }
        
        todaytotal = todaytotal / 1000;                                                                         // => set todaytotal from wh to kwh       
        $('#todaytotal').text(Math.round(todaytotal) + ' kWh');                                                 // => write todaytotal to screen              
        yesterdaydata(dayarray);                                                                                // => call yesterdaydata
        
    })
            .error(function() {
        console.log("Failure requesting historical data");
    });
}

function yesterdaydata(todayarray) {
    //////////////////////
    //yesterdayarray
    /////////////////////
    var startyesterdaytime = new Date();
    startyesterdaytime.setHours(0);
    startyesterdaytime.setMinutes(0);
    startyesterdaytime.setSeconds(0);
    startyesterdaytime.setMilliseconds(0);
    startyesterdaytime.setDate(startyesterdaytime.getDate() - 1);
    startyesterdaytime.setHours(startyesterdaytime.getHours() - 1);
    var count = 30;
    var timebase = 3600.00;
    var parameter = "_WH_V[4]";
    var todaytotal = 0;

    var s = startyesterdaytime.getTime(); 
    s = s / 1000;

    $.getJSON("hist_data/HIST_DATA.html", "val$=" + parameter + "&start=" + (s + (new Date().getTimezoneOffset() * -60)) + "&cnt=" + count + "&tb=" + timebase, function(data)
    {
        var length = data[parameter][0].length;
        var dayarray = new Array();
        var hour = 0;
        var hourtime = s + (new Date().getTimezoneOffset() * -60);
        var hourtime = hourtime;
        var previoushour = -1.11;
        var value = 0;
        
        while(value < length && hour < 25){                                                                     // => until the day is full or there is no more data       
            if(previoushour === -1.11){                                                                         // => If no starthour               
                if(data[parameter][0][value][1] === hourtime){                                                  // => if valuetime = hourtime
                    previoushour = data[parameter][0][value][0];
                    hourtime = hourtime + 3600;                                                                 // => increase hour
                    value++;                                                                                    // => increase value
                }else if(data[parameter][0][value][1] > hourtime){                                              // => if valuetime is later than hourtime
                    dayarray[hour] = 0;                                                                         // => set barvalue 0
                    hourtime = hourtime + 3600;                                                                 // => increase hour
                    hour++;                  
                }else if(data[parameter][0][value][1] < hourtime){                                              // => if valuetime is earlier than hourtime
                    value++;                                                                                    // => increase value
                }
            }else{                                                                                              // => if starthour is set
                if(data[parameter][0][value][1] === hourtime){                                                  // => if valuetime = hourtime
                    dayarray[hour] = data[parameter][0][value][0] - previoushour;                               // => set barvalue
                    if(dayarray[hour] * 1.1 > daymaximum ){ daymaximum = dayarray[hour] * 1.1;};                // => check if maximum has to be adjusted
                    if(dayarray[hour] * 1.1 < dayminimum ){ dayminimum = dayarray[hour] * 1.1;};                // => check if minimum has to be adjusted
                    previoushour = data[parameter][0][value][0];                                                // => set previoushour 
                    todaytotal = todaytotal + dayarray[hour];                                                   // => add to todaytotal
                    hourtime = hourtime + 3600;                                                                 // => increase hour
                    hour++;                   
                    value++;                                                                                    // => increase value                  
                }else if(data[parameter][0][value][1] > hourtime){                                              // => if valuetime is later than hourtime
                    dayarray[hour] = 0;                                                                         // => set barvalue 0
                    hourtime = hourtime + 3600;                                                                 // => increase hour
                    hour++;
                    previoushour = -1.11;                                                                       // => set previoushour null
                    
                }else if(data[parameter][0][value][1] < hourtime){                                              // => if valuetime is earlier than hourtime
                    value++;                                                                                    // => increase value
                }
            }
        }
        
        while(hour < 25){                                                                                 // => until the day is full
            dayarray[hour] = 0;   
            hour++;
        }
        
        
        todaytotal = todaytotal / 1000;                                                                         // => set todaytotal from wh to kwh       
        $('#yesterdaytotal').text(Math.round(todaytotal) + ' kWh');     
        createdaygraph(todayarray, dayarray);
    })
            .error(function() {
        //alert("error, requesting yesterdaytotal total");
    })
            .complete(function() {
        monthdata();
    });
}

function monthdata() {
    //////////////////////
    //Current month
    /////////////////////
    var startthismonthtime = new Date();
    startthismonthtime.setDate(1);
    startthismonthtime.setHours(0);
    startthismonthtime.setMinutes(0);
    startthismonthtime.setSeconds(0);
    startthismonthtime.setMilliseconds(0);

    var count = 900;
    var timebase = 3600.00;
    var parameter = "_WH_V[4]";
    var todaytotal = 0;

    var s = startthismonthtime.getTime(); 
    s = s / 1000;
    

    $.getJSON("hist_data/HIST_DATA.html", "val$=" + parameter + "&start=" + (s + (new Date().getTimezoneOffset() * -60)) + "&cnt=" + count + "&tb=" + timebase, function(data)
    {

        var length = data[parameter][0].length;
        var dayarray = new Array();
        var hour = 0;
        var hourtime = s + (new Date().getTimezoneOffset() * -60);
        var hourtime = hourtime;
        var previoushour = -1.11;
        var value = 0;
        
        while(value < length && hour < 32){                                                                     // => until the day is full or there is no more data       
            if(previoushour === -1.11){                                                                         // => If no starthour               
                if(data[parameter][0][value][1] === hourtime){                                                  // => if valuetime = hourtime
                    previoushour = data[parameter][0][value][0];
                    hourtime = hourtime + 3600*24;                                                              // => increase hour
                    value++;                                                                                    // => increase value
                }else if(data[parameter][0][value][1] > hourtime){                                              // => if valuetime is later than hourtime
                    dayarray[hour] = 0;                                                                         // => set barvalue 0
                    hourtime = hourtime + 3600*24;                                                              // => increase hour
                    hour++;                  
                }else if(data[parameter][0][value][1] < hourtime){                                              // => if valuetime is earlier than hourtime
                    value++;                                                                                    // => increase value
                }
            }else{                                                                                              // => if starthour is set
                if(data[parameter][0][value][1] === hourtime){                                                  // => if valuetime = hourtime
                    dayarray[hour] = data[parameter][0][value][0] - previoushour;                               // => set barvalue
                    if(dayarray[hour] * 1.1 > monthmaximum ){ monthmaximum = dayarray[hour] * 1.1;};            // => check if maximum has to be adjusted
                    if(dayarray[hour] * 1.1 < monthminimum ){ monthminimum = dayarray[hour] * 1.1;};            // => check if minimum has to be adjusted
                    previoushour = data[parameter][0][value][0];                                                // => set previoushour 
                    todaytotal = todaytotal + dayarray[hour];                                                   // => add to todaytotal
                    hourtime = hourtime + 3600*24;                                                              // => increase hour
                    hour++;                   
                    value++;                                                                                    // => increase value                  
                }else if(data[parameter][0][value][1] > hourtime){                                              // => if valuetime is later than hourtime
                    dayarray[hour] = 0;                                                                         // => set barvalue 0
                    hourtime = hourtime + 3600*24;                                                              // => increase hour
                    hour++;
                    previoushour = -1.11;                                                                       // => set previoushour null
                    
                }else if(data[parameter][0][value][1] < hourtime){                                              // => if valuetime is earlier than hourtime
                    value++;                                                                                    // => increase value
                }
            }
        }
        
        while(hour < 32){                                                                                 // => until the day is full
            dayarray[hour] = 0;   
            hour++;
        }
               
        todaytotal = todaytotal / 1000; 
        $('#monthtotal').text(Math.round(todaytotal) + ' kWh');

        lastmonthdata(dayarray);
        
    })
            .error(function() {
        //alert("Fout bij opvragen historische data");
    });

}

function lastmonthdata(currentmontharray) {

    //////////////////////
    //Last month
    /////////////////////

    var startthismonthtime = new Date();
    startthismonthtime.setDate(0);
    startthismonthtime.setDate(1);
    startthismonthtime.setHours(0);
    startthismonthtime.setMinutes(0);
    startthismonthtime.setSeconds(0);
    startthismonthtime.setMilliseconds(0);

    var count = 900;
    var timebase = 3600.00;
    var parameter = "_WH_V[4]";
    var todaytotal = 0;

    var s = startthismonthtime.getTime(); 
    s = s / 1000;
    

    $.getJSON("hist_data/HIST_DATA.html", "val$=" + parameter + "&start=" + (s + (new Date().getTimezoneOffset() * -60)) + "&cnt=" + count + "&tb=" + timebase, function(data)
    {
        
        var length = data[parameter][0].length;
        var dayarray = new Array();
        var hour = 0;
        var hourtime = s + (new Date().getTimezoneOffset() * -60);
        var hourtime = hourtime;
        var previoushour = -1.11;
        var value = 0;
        var days = daysInMonth(startthismonthtime.getMonth(), startthismonthtime.getYear());
        
        while(value < length && hour < days){                                                                     // => until the day is full or there is no more data       
            if(previoushour === -1.11){                                                                         // => If no starthour               
                if(data[parameter][0][value][1] === hourtime){                                                  // => if valuetime = hourtime
                    previoushour = data[parameter][0][value][0];
                    hourtime = hourtime + 3600*24;                                                              // => increase hour
                    value++;                                                                                    // => increase value
                }else if(data[parameter][0][value][1] > hourtime){                                              // => if valuetime is later than hourtime
                    dayarray[hour] = 0;                                                                         // => set barvalue 0
                    hourtime = hourtime + 3600*24;                                                              // => increase hour
                    hour++;                  
                }else if(data[parameter][0][value][1] < hourtime){                                              // => if valuetime is earlier than hourtime
                    value++;                                                                                    // => increase value
                }
            }else{                                                                                              // => if starthour is set
                if(data[parameter][0][value][1] === hourtime){                                                  // => if valuetime = hourtime
                    dayarray[hour] = data[parameter][0][value][0] - previoushour;                               // => set barvalue
                    if(dayarray[hour] * 1.1 > monthmaximum ){ monthmaximum = dayarray[hour] * 1.1;};            // => check if maximum has to be adjusted
                    if(dayarray[hour] * 1.1 < monthminimum ){ monthminimum = dayarray[hour] * 1.1;};            // => check if minimum has to be adjusted
                    previoushour = data[parameter][0][value][0];                                                // => set previoushour 
                    todaytotal = todaytotal + dayarray[hour];                                                   // => add to todaytotal
                    hourtime = hourtime + 3600*24;                                                              // => increase hour
                    hour++;                   
                    value++;                                                                                    // => increase value                  
                }else if(data[parameter][0][value][1] > hourtime){                                              // => if valuetime is later than hourtime
                    dayarray[hour] = 0;                                                                         // => set barvalue 0
                    hourtime = hourtime + 3600*24;                                                              // => increase hour
                    hour++;
                    previoushour = -1.11;                                                                       // => set previoushour null
                    
                }else if(data[parameter][0][value][1] < hourtime){                                              // => if valuetime is earlier than hourtime
                    value++;                                                                                    // => increase value
                }
            }
        }
        
        while(hour < 32){                                                                                 // => until the day is full
            dayarray[hour] = 0;   
            hour++;
        }
               
        todaytotal = todaytotal / 1000; 
        $('#lastmonthtotal').text(Math.round(todaytotal) + ' kWh');                      
        createmonthgraph(currentmontharray, dayarray);

    })
            .error(function() {
        
    });

}

//daygraph tekenen
function createdaygraph(dayarray, yesterdayarray) {
    $('#daygraph .calcgraph').hide();   
    var container = document.getElementById('daygraph');
    var d1 = [];
    var d2 = [];
    var graph = [];

    for (var i = 0; i < 24; i++) {
        d2.push([i, dayarray[i]]);
        d1.push([i - 0.3, yesterdayarray[i]]);
    }

    graph = Flotr.draw(container, [
        {data: d1,
            bars: {
                show: true,
                barWidth: 0.5,
                shadowSize: 0,
                fillOpacity: 1,
                lineWidth: 0,
                fillColor: '#B5B5B5'
            },
            color: '#B5B5B5',
            label: tl('home.yesterday')
        },
        {data: d2,
            bars: {
                show: true,
                barWidth: 0.5,
                shadowSize: 0,
                fillOpacity: 1,
                lineWidth: 0,
                fillColor: '#337490'
            },
            color: '#337490',
            label: tl('home.today')  
        }
    ], {
        legend: {
            position: 'se',
            backgroundOpacity: 0.5
        },
        fontSize: 12,
        xaxis: {
            noTicks: 24, // Display 24 ticks.	 
            tickDecimals: 0,
            color: 'grey'
        },
        yaxis: {
            tickFormatter: tickskw,
            tickDecimals: 0,
            color: 'grey',
            min: dayminimum,
            max: daymaximum
        },
        grid: {
            color: 'grey', // => primary color used for outline and labels
            backgroundColor: null, // => null for transparent, else color
            backgroundImage: null, // => background image. String or object with src, left and top
            tickColor: '#DDDDDD', // => color used for the ticks
            labelMargin: 10, // => margin in pixels
            verticalLines: false, // => whether to show gridlines in vertical direction

            horizontalLines: true, // => whether to show gridlines in horizontal direction

            outlineWidth: 2      // => width of the grid outline/border in pixels

        }
    });

}

//daygraph tekenen
function createmonthgraph(currentmontharray, lastmontharray) {

    $('#monthgraph .calcgraph').hide();

    var container = document.getElementById('monthgraph');
    var d1 = [];
    var d2 = [];
    var graph = [];


    for (var i = 0; i < 31; i++) {
        d2.push([i+1, currentmontharray[i]]);
        d1.push([i+1 - 0.3, lastmontharray[i]]);
    }

    graph = Flotr.draw(container, [
        {data: d1,
            bars: {
                show: true,
                barWidth: 0.5,
                shadowSize: 0,
                fillOpacity: 1,
                lineWidth: 0,
                fillColor: '#B5B5B5'
            },
            color: '#B5B5B5',
            label: tl('home.lastmonth')
        },
        {data: d2,
            bars: {
                show: true,
                barWidth: 0.5,
                shadowSize: 0,
                fillOpacity: 1,
                lineWidth: 0,
                fillColor: '#337490'
            },
            color: '#337490',
            label: tl('home.thismonth')
        }
    ], {
        legend: {
            position: 'se',
            backgroundOpacity: 0.5
        },
        fontSize: 12,
        xaxis: {
            noTicks: 24, // Display 24 ticks.	 
            tickDecimals: 0,
            color: 'grey'
        },
        yaxis: {
            tickFormatter: tickskw,
            tickDecimals: 0,
            color: 'grey',
            min: monthminimum,
            max: monthmaximum
        },
        grid: {
            color: 'grey', // => primary color used for outline and labels
            backgroundColor: null, // => null for transparent, else color
            backgroundImage: null, // => background image. String or object with src, left and top
            tickColor: '#DDDDDD', // => color used for the ticks
            labelMargin: 10, // => margin in pixels
            verticalLines: false, // => whether to show gridlines in vertical direction

            horizontalLines: true, // => whether to show gridlines in horizontal direction

            outlineWidth: 2      // => width of the grid outline/border in pixels

        }
    });

}

function tickskw(n) {
    return n / 1000 + " kWh";
}

function tickstime(n) {
    return n + "";
}
function daysInMonth(iMonth, iYear)
{
    return 32 - new Date(iYear, iMonth, 32).getDate();
}
