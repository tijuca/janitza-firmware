
var graphdate = new Date();
var mode = 1; //1 = year, 2 = month, 3 = day
var currentkwh = 0;

////////////////////////////////////
// Initalisation function
////////////////////////////////////
function usagegraph() {

    $.ajaxSetup({cache: false});

    //initalise date selector
    $("#datepicker").datepicker({
        changeMonth: true,
        changeYear: true,
        maxDate: "+0D",
        minDate: "-2Y",
        onSelect: function (date) {
            console.log(date);
            graphdate = new Date(date);
            getgraphdata();
        }
    });
    $("#datepicker").datepicker("setDate", graphdate);

    //initialise buttons
    $("#graphprevious").click(function () {
        
    
        if (mode === 1) {
            graphdate.setFullYear(graphdate.getFullYear() - 1);
        }
        if (mode === 2) {
            graphdate.setMonth(graphdate.getMonth() - 1);
        }
        if (mode === 3) {
            graphdate.setDate(graphdate.getDate() - 1);
        }

        $("#datepicker").datepicker("setDate", graphdate);
        graphdate = $("#datepicker").datepicker("getDate");    //trick to make sure the buttons do not go outside the date limits
        console.log('New date: ' + graphdate);
        getgraphdata();
    });

    //initialise buttons
    $("#graphnext").click(function () {
        
    
        if (mode === 1) {
            graphdate.setFullYear(graphdate.getFullYear() + 1);
        }
        if (mode === 2) {
            graphdate.setMonth(graphdate.getMonth() + 1);
        }
        if (mode === 3) {
            graphdate.setDate(graphdate.getDate() + 1);
        }

        $("#datepicker").datepicker("setDate", graphdate);
        graphdate = $("#datepicker").datepicker("getDate");    //trick to make sure the buttons do not go outside the date limits
        console.log('New date: ' + graphdate);
        getgraphdata();
    });


    $("#graphmodeselection").change(function () {
       
        
        mode = parseInt($('#graphmodeselection').val());
        console.log("Mode changed to: " + mode);
        getgraphdata();
    });


    getgraphdata();


}

function getgraphdata() {
    
    $("#usagegraph").empty();
    $("#usagegraph").html("<div style='text-align: center;padding-top: 75px;'><img src='../../../img/loading.gif' alt='loading...' ></div>");
    
    if (mode === 1) {
        var year = graphdate.getFullYear();
        getyeardata(year);
    }
    if (mode === 2) {
        getmonthdata();
    }
    if (mode === 3) {
        getdaydata();
    }

}

////////////////////////////////////
// Get data for a specific year
////////////////////////////////////
function getyeardata(year) {

    $.getJSON("../../../json.do?_VWH_MONTH[0..23],_WH_V[4]", function (data) {

        currentkwh = data['_WH_V'][0][0];
      
        var yeararray = [];
        var currentyear = new Date().getFullYear();
        var currentmonth = new Date().getMonth();
        var selyear = 1; //1 = two years ago, 2 = last year, 3= this year

        //check if selected year is current year
        if (year === currentyear) {
            selyear = 3;
        } else if (year === (currentyear - 1)) {
            selyear = 2;
        }

        console.log("Selected year: " + selyear);
        console.log("current month: " + currentmonth);


        //check if year is even or odd
        if (year % 2 === 0) {
            //loop through months
            for (var i = 0; i < 12; i++) {
                //check the following
                if (selyear === 3 && currentmonth >= i) {
                    yeararray.push([i + 1, data['_VWH_MONTH'][0][i]]);
                } else if (selyear === 2) {
                    yeararray.push([i + 1, data['_VWH_MONTH'][0][i]]);
                } else if (selyear === 1 && currentmonth < i) {
                    yeararray.push([i + 1, data['_VWH_MONTH'][0][i]]);
                } else {
                    yeararray.push([i + 1, 0]);
                }

            }
        } else {
            //loop through months
            for (var i = 0; i < 12; i++) {
                //check the following
                if (selyear === 3 && currentmonth >= i) {
                    yeararray.push([i + 1, data['_VWH_MONTH'][0][i + 12]]);
                } else if (selyear === 2) {
                    yeararray.push([i + 1, data['_VWH_MONTH'][0][i + 12]]);
                } else if (selyear === 1 && currentmonth < i) {
                    yeararray.push([i + 1, data['_VWH_MONTH'][0][i + 12]]);
                } else {
                    yeararray.push([i + 1, 0]);
                }
            }
        }

        drawgraph(yeararray);
    });
}

function getdaydata() {

    $.getJSON("../../../../../../../../../json.do?_TIME_ZONE,", function (data)
    {
        var timezone = data["_TIME_ZONE"][0];

        var time = new Date(graphdate);

        time.setHours(0);
        time.setMinutes(0);
        time.setSeconds(0);
        time.setMilliseconds(0);
        time.setHours(time.getHours() - 1);

        var count = 30;
        var timebase = 3600.00;
        var parameter = "_WH_V[4]";
        var todaytotal = 0;

        var s = time.getTime();
        s = s / 1000;
        s = s + timezone;

        $.getJSON("hist_data/HIST_DATA.html", "val$=" + parameter + "&start=" + s + "&cnt=" + count + "&tb=" + timebase, function (data)
        {

            var length = data[parameter][0].length;
            var dayarray = new Array();
            var hour = 0;
            var hourtime = s;
            var previoushour = -1.11;
            var value = 0;

            while (value < length && hour < 25) {                                                                     // => until the day is full or there is no more data       
                if (previoushour === -1.11) {                                                                         // => If no starthour               
                    if (data[parameter][0][value][1] === hourtime) {                                                  // => if valuetime = hourtime
                        previoushour = data[parameter][0][value][0];
                        hourtime = hourtime + 3600;                                                                 // => increase hour
                        value++;                                                                                    // => increase value
                    } else if (data[parameter][0][value][1] > hourtime) {                                              // => if valuetime is later than hourtime
                        dayarray[hour] = 0;                                                                         // => set barvalue 0
                        hourtime = hourtime + 3600;                                                                 // => increase hour
                        hour++;
                    } else if (data[parameter][0][value][1] < hourtime) {                                              // => if valuetime is earlier than hourtime
                        value++;                                                                                    // => increase value
                    }
                } else {                                                                                              // => if starthour is set
                    if (data[parameter][0][value][1] === hourtime) {                                                  // => if valuetime = hourtime
                        dayarray[hour] = data[parameter][0][value][0] - previoushour;                               // => set barvalue
                        previoushour = data[parameter][0][value][0];                                                // => set previoushour 
                        todaytotal = todaytotal + dayarray[hour];                                                   // => add to todaytotal
                        hourtime = hourtime + 3600;                                                                 // => increase hour
                        hour++;
                        value++;                                                                                    // => increase value                  
                    } else if (data[parameter][0][value][1] > hourtime) {                                              // => if valuetime is later than hourtime
                        dayarray[hour] = 0;                                                                         // => set barvalue 0
                        hourtime = hourtime + 3600;                                                                 // => increase hour
                        hour++;
                        previoushour = -1.11;                                                                       // => set previoushour null

                    } else if (data[parameter][0][value][1] < hourtime) {                                              // => if valuetime is earlier than hourtime
                        value++;                                                                                    // => increase value
                    }
                }
            }

            while (hour < 25) {                                                                                       // => until the day is full
                dayarray[hour] = 0;
                hour++;
            }

            var daydata = [];

            for (var i = 0; i < 24; i++) {
                daydata.push([i, dayarray[i]]);
            }

            drawgraph(daydata);


        }).error(function () {
            console.log("Failure requesting historical data");
        });
    });



}

////////////////////////////////////
// Get and calculate month data
////////////////////////////////////
function getmonthdata() {

    var time = new Date(graphdate);

    time.setDate(0);
    time.setHours(0);
    time.setMinutes(0);
    time.setSeconds(0);
    time.setMilliseconds(0);

    var count = 900;
    var timebase = 3600.00;
    var parameter = "_WH_V[4]";
    var todaytotal = 0;

    var s = time.getTime();
    s = s / 1000;
    //s = s + timezone;


    $.getJSON("hist_data/HIST_DATA.html", "val$=" + parameter + "&start=" + s + "&cnt=" + count + "&tb=" + timebase, function (data)
    {

        var length = data[parameter][0].length;
        var dayarray = new Array();
        var hour = 0;
        var hourtime = s;
        var previoushour = -1.11;
        var value = 0;

        while (value < length && hour < 32) {                                                                   // => until the day is full or there is no more data       
            if (previoushour === -1.11) {                                                                       // => If no starthour               
                if (data[parameter][0][value][1] === hourtime) {                                                // => if valuetime = hourtime
                    previoushour = data[parameter][0][value][0];
                    hourtime = hourtime + 3600 * 24;                                                            // => increase hour
                    value++;                                                                                    // => increase value
                } else if (data[parameter][0][value][1] > hourtime) {                                           // => if valuetime is later than hourtime
                    dayarray[hour] = 0;                                                                         // => set barvalue 0
                    hourtime = hourtime + 3600 * 24;                                                            // => increase hour
                    hour++;
                } else if (data[parameter][0][value][1] < hourtime) {                                           // => if valuetime is earlier than hourtime
                    value++;                                                                                    // => increase value
                }
            } else {                                                                                            // => if starthour is set
                if (data[parameter][0][value][1] === hourtime) {                                                // => if valuetime = hourtime
                    dayarray[hour] = data[parameter][0][value][0] - previoushour;                               // => set barvalue
                    previoushour = data[parameter][0][value][0];                                                // => set previoushour 
                    
                    hourtime = hourtime + 3600 * 24;                                                            // => increase hour
                    hour++;
                    value++;                                                                                    // => increase value                  
                } else if (data[parameter][0][value][1] > hourtime) {                                           // => if valuetime is later than hourtime
                    dayarray[hour] = 0;                                                                         // => set barvalue 0
                    hourtime = hourtime + 3600 * 24;                                                            // => increase hour
                    hour++;
                    previoushour = -1.11;                                                                       // => set previoushour null

                } else if (data[parameter][0][value][1] < hourtime) {                                           // => if valuetime is earlier than hourtime
                    value++;                                                                                    // => increase value
                }
            }
        }
                
        
        while (hour < 32) {                                                                                 // => until the day is full
            dayarray[hour] = 0;
            hour++;
        }

        var montharray = [];

        for (var i = 1; i < 32; i++) {
            montharray.push([i, dayarray[i]]);
        }

        drawgraph(montharray);

    }).error(function () {
        alert("Failure getting data");
    });
}



////////////////////////////////////
// Draw the graph
////////////////////////////////////
function drawgraph(d1) {
    var container = document.getElementById('usagegraph');

    Flotr.EventAdapter.stopObserving(container, 'flotr:select');
    Flotr.EventAdapter.stopObserving(container, 'flotr:click');
    $("#container").empty();

    var object = [];
    var count = 0;
    var y1label = '';
    var y2label = '';
    var datathere = false;

    var newdata = {};

    newdata['data'] = d1;
    newdata['color'] = '#337490';
    

    object.push(newdata);



    var options = {
        xaxis: {
            noTicks: 24, // Display 24 ticks.	 
            tickDecimals: 0,
            color: 'grey',
            tickFormatter: ticksdate
        },
        bars: {
            stacked: false,
            show: true,
            barWidth: 0.5,
            shadowSize: 0,
            fillOpacity: 1,
            lineWidth: 1
        },
        yaxis: {
            tickFormatter: tickskw,
            tickDecimals: 0,
            color: 'grey',
            min: 0
        }, grid: {
            color: 'grey', // => primary color used for outline and labels
            backgroundColor: null, // => null for transparent, else color
            backgroundImage: null, // => background image. String or object with src, left and top
            tickColor: '#DDDDDD', // => color used for the ticks
            labelMargin: 10, // => margin in pixels
            verticalLines: false, // => whether to show gridlines in vertical direction
            horizontalLines: true, // => whether to show gridlines in horizontal direction
            outlineWidth: 1      // => width of the grid outline/border in pixels
        },
        mouse: {
            track: true,
            relative: true,
            trackFormatter: function(obj){ return Math.round(obj.y/10)/100 + " kWh"; }
        }
        
    };

    // Draw graph with default options, overwriting with passed options


    function drawGraphhist(opts) {
        // Clone the options, so the 'options' variable always keeps intact.
        o = Flotr._.extend(Flotr._.clone(options), opts || {});
        // Return a new graph.
        flotrgraph = Flotr.draw(container, object, o);
    }


    //Make possibility to click in the graph
    Flotr.EventAdapter.observe(container, 'flotr:click', function (evt) {

        if (mode === 1) {
            console.log('click');
            var month = Math.round(evt.x);
            graphdate.setMonth(month-1);
            $("#datepicker").datepicker("setDate", graphdate);
            $('#graphmodeselection').val(2);
            mode = 2;
            getgraphdata();
        }else if(mode === 2){
            console.log('click');
            var day = Math.round(evt.x);
            graphdate.setDate(day);
            $("#datepicker").datepicker("setDate", graphdate);
            $('#graphmodeselection').val(3);
            mode = 3 ;
            getgraphdata();
        }


    });

    drawGraphhist();




    /*
     var container = document.getElementById('usagegraph');
     
     graph = Flotr.draw(container, [
     {data: d1,
     bars: {
     show: true,
     barWidth: 0.5,
     shadowSize: 0,
     fillOpacity: 1,
     lineWidth: 0,
     fillColor: '#337490'
     }
     }
     ], {
     preventDefault: false,
     fontSize: 12,
     xaxis: {
     noTicks: 24, // Display 24 ticks.	 
     tickDecimals: 0,
     color: 'grey',
     tickFormatter: ticksdate
     },
     yaxis: {
     tickFormatter: tickskw,
     tickDecimals: 0,
     color: 'grey',
     min: 0
     },
     grid: {
     color: 'grey', // => primary color used for outline and labels
     backgroundColor: null, // => null for transparent, else color
     backgroundImage: null, // => background image. String or object with src, left and top
     tickColor: '#DDDDDD', // => color used for the ticks
     labelMargin: 10, // => margin in pixels
     verticalLines: false, // => whether to show gridlines in vertical direction
     horizontalLines: true, // => whether to show gridlines in horizontal direction
     outlineWidth: 1      // => width of the grid outline/border in pixels
     },
     mouse: {
     track: true
     }
     });
     */
}

function tickskw(n) {
    return n / 1000 + " kWh";
}

function ticksdate(n) {
    if (mode === 1) {
        return tl("month" + n);
    }
    if (mode === 2 || mode === 3) {
        return n;
    }
}




























function calculatetotals() {
    writedaygraph();
    writemonthgraph();
}


function writedaygraph() {
    var container = document.getElementById('daygraph');
    var d1 = [];
    var d2 = [];
    var graph = [];


    var dayarray = new Array();

    dayarray[0] = 1450;
    dayarray[1] = 1454;
    dayarray[2] = 1460;
    dayarray[3] = 1455;
    dayarray[4] = 1453;
    dayarray[5] = 1457;
    dayarray[6] = 1456;
    dayarray[7] = 1460;
    dayarray[8] = 1815;
    dayarray[9] = 2630;
    dayarray[10] = 4050;
    dayarray[11] = 4320;
    dayarray[12] = 4280;
    dayarray[13] = 4440;
    dayarray[14] = 4385;
    dayarray[15] = 4399;
    dayarray[16] = 4630;
    dayarray[17] = 4463;
    dayarray[18] = 4210;
    dayarray[19] = 3960;
    dayarray[20] = 2721;
    dayarray[21] = 1453;
    dayarray[22] = 1423;
    dayarray[23] = 1459;


    var yesterdayarray = new Array();

    yesterdayarray[0] = 1420;
    yesterdayarray[1] = 1432;
    yesterdayarray[2] = 1452;
    yesterdayarray[3] = 1418;
    yesterdayarray[4] = 1436;
    yesterdayarray[5] = 1442;
    yesterdayarray[6] = 1414;
    yesterdayarray[7] = 1493;
    yesterdayarray[8] = 1515;
    yesterdayarray[9] = 2823;
    yesterdayarray[10] = 4254;
    yesterdayarray[11] = 4123;
    yesterdayarray[12] = 3981;
    yesterdayarray[13] = 3976;
    yesterdayarray[14] = 3956;
    yesterdayarray[15] = 4123;
    yesterdayarray[16] = 4086;
    yesterdayarray[17] = 3863;
    yesterdayarray[18] = 3212;
    yesterdayarray[19] = 2536;
    yesterdayarray[20] = 1833;
    yesterdayarray[21] = 1460;
    yesterdayarray[22] = 1451;
    yesterdayarray[23] = 1448;

    var hour = new Date().getHours();

    var todaytotal = 0;
    var yesterdaytotal = 0;

    for (var i = 0; i < 24; i++) {
        if (hour > i) {
            d2.push([i, dayarray[i]]);
            todaytotal = todaytotal + dayarray[i];
        } else {
            d2.push([i, 0]);
        }
        d1.push([i - 0.3, yesterdayarray[i]]);
        yesterdaytotal = yesterdaytotal + yesterdayarray[i];
    }

    $('#todaytotal').text(todaytotal / 1000 + ' kWh');
    $('#yesterdaytotal').text(yesterdaytotal / 1000 + ' kWh');

    graph = Flotr.draw(container, [
        {data: d1,
            bars: {
                show: true,
                barWidth: 0.5,
                shadowSize: 0,
                fillOpacity: 1,
                lineWidth: 0,
                fillColor: '#B5B5B5'
            }
        },
        {data: d2,
            bars: {
                show: true,
                barWidth: 0.5,
                shadowSize: 0,
                fillOpacity: 1,
                lineWidth: 0,
                fillColor: '#337490'
            }
        }
    ], {
        preventDefault: false,
        fontSize: 12,
        xaxis: {
            noTicks: 24, // Display 24 ticks.	 
            tickDecimals: 0,
            color: 'grey'
        },
        yaxis: {
            tickFormatter: tickskw,
            tickDecimals: 0,
            color: 'grey',
            min: 0
        },
        grid: {
            color: 'grey', // => primary color used for outline and labels
            backgroundColor: null, // => null for transparent, else color
            backgroundImage: null, // => background image. String or object with src, left and top
            tickColor: '#DDDDDD', // => color used for the ticks
            labelMargin: 10, // => margin in pixels
            verticalLines: false, // => whether to show gridlines in vertical direction
            horizontalLines: true, // => whether to show gridlines in horizontal direction
            outlineWidth: 0      // => width of the grid outline/border in pixels
        }
    });

}

function writemonthgraph() {
    var container = document.getElementById('usagegraph');
    var d1 = [];
    var d2 = [];
    var graph = [];


    var dayarray = new Array();

    dayarray[0] = 19655;
    dayarray[1] = 65222;
    dayarray[2] = 64213;
    dayarray[3] = 60158;
    dayarray[4] = 60888;
    dayarray[5] = 24235;
    dayarray[6] = 25652;
    dayarray[7] = 61255;
    dayarray[8] = 62545;
    dayarray[9] = 61054;
    dayarray[10] = 60254;
    dayarray[11] = 62155;
    dayarray[12] = 19655;
    dayarray[13] = 16523;
    dayarray[14] = 65000;
    dayarray[15] = 65000;
    dayarray[16] = 65000;
    dayarray[17] = 65000;
    dayarray[18] = 65000;
    dayarray[19] = 19000;
    dayarray[20] = 19000;
    dayarray[21] = 65000;
    dayarray[22] = 65000;
    dayarray[23] = 65000;
    dayarray[24] = 65000;
    dayarray[25] = 65000;
    dayarray[26] = 19000;
    dayarray[27] = 19000;
    dayarray[28] = 65000;
    dayarray[29] = 65000;
    dayarray[30] = 65000;
    dayarray[31] = 65000;

    var yesterdayarray = new Array();

    yesterdayarray[0] = 61156;
    yesterdayarray[1] = 21352;
    yesterdayarray[2] = 22465;
    yesterdayarray[3] = 58232;
    yesterdayarray[4] = 59215;
    yesterdayarray[5] = 61024;
    yesterdayarray[6] = 62135;
    yesterdayarray[7] = 63541;
    yesterdayarray[8] = 25132;
    yesterdayarray[9] = 25265;
    yesterdayarray[10] = 52161;
    yesterdayarray[11] = 59568;
    yesterdayarray[12] = 64212;
    yesterdayarray[13] = 63121;
    yesterdayarray[14] = 68213;
    yesterdayarray[15] = 21012;
    yesterdayarray[16] = 20099;
    yesterdayarray[17] = 63212;
    yesterdayarray[18] = 62155;
    yesterdayarray[19] = 62999;
    yesterdayarray[20] = 61548;
    yesterdayarray[21] = 59221;
    yesterdayarray[22] = 19845;
    yesterdayarray[23] = 20120;
    yesterdayarray[24] = 54002;
    yesterdayarray[25] = 55123;
    yesterdayarray[26] = 55452;
    yesterdayarray[27] = 54232;
    yesterdayarray[28] = 47532;
    yesterdayarray[29] = 19876;
    yesterdayarray[30] = 20018;

    var hour = new Date().getDate();
    hour = hour - 1;
    var todaytotal = 0;
    var yesterdaytotal = 0;

    for (var i = 0; i < 31; i++) {
        if (hour > i) {
            d2.push([i + 1, dayarray[i]]);
            todaytotal = todaytotal + dayarray[i];
        } else {
            d2.push([i + 1, 0]);
        }
        d1.push([i + 1 - 0.3, yesterdayarray[i]]);
        yesterdaytotal = yesterdaytotal + yesterdayarray[i];
    }

    $('#monthtotal').text(todaytotal / 1000 + ' kWh');
    $('#lastmonthtotal').text(yesterdaytotal / 1000 + ' kWh');

    graph = Flotr.draw(container, [
        {data: d1,
            bars: {
                show: true,
                barWidth: 0.5,
                shadowSize: 0,
                fillOpacity: 1,
                lineWidth: 0,
                fillColor: '#B5B5B5'
            }
        },
        {data: d2,
            bars: {
                show: true,
                barWidth: 0.5,
                shadowSize: 0,
                fillOpacity: 1,
                lineWidth: 0,
                fillColor: '#337490'
            }
        }
    ], {
        preventDefault: false,
        fontSize: 12,
        xaxis: {
            noTicks: 24, // Display 24 ticks.	 
            tickDecimals: 0,
            color: 'grey'
        },
        yaxis: {
            tickFormatter: tickskw,
            tickDecimals: 0,
            color: 'grey',
            min: 0
        },
        grid: {
            color: 'grey', // => primary color used for outline and labels
            backgroundColor: null, // => null for transparent, else color
            backgroundImage: null, // => background image. String or object with src, left and top
            tickColor: '#DDDDDD', // => color used for the ticks
            labelMargin: 10, // => margin in pixels
            verticalLines: false, // => whether to show gridlines in vertical direction
            horizontalLines: true, // => whether to show gridlines in horizontal direction
            outlineWidth: 0      // => width of the grid outline/border in pixels
        }
    });

}

function tickstime(n) {
    return n + "";
}