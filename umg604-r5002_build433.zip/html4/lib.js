var UMG604 = true;
var UMG605 = false;
var UMG507 = false;
var UMG508 = false;
var UMG509 = false;
var UMG510 = false;
var UMG511 = false;
var UMG512 = false;
var UMG96RME = false;

