var eggs = 
[
    {
        "entries":[
            {
                "menu1eb":"menu.powerquality",
                "menu2eb":-1,
                "titleDE":"IEC61000-2-4 Settings",
                "titleEN":"IEC61000-2-4 Settings",
                "href":"/app/5100308/settings.html",
                "target":"",
                "icon":"/app/5100308/icon.png"
            }
        ],
        "version":"3.0.1",
        "appId":"5100308",
        "descDE":"<p>Die Norm &bdquo;IEC 61000-2-4&ldquo; legt Grenzen f&uuml;r industrielle und nicht &ouml;ffentliche Stromverteilungssysteme<br />fest. Sie bildet eine Leitnorm f&uuml;r viele Produkt- und Maschinenbaunormen und definiert Immunit&auml;tspegel der Spannungsverzerrung, die Maschinen und Anlagen in Industriebetrieben in allen Betriebszust&auml;nden einhalten m&uuml;ssen. Eine<br />&Uuml;berschreitung dieser Pegel &ndash; insbesondere &uuml;ber l&auml;ngere Zeitr&auml;ume &ndash; f&uuml;hrt zu Ausf&auml;llen, unn&ouml;tigen Reparaturkosten und eventuellem Produktionsstillstand.</p>  <p>Um einen fehlerfreien Betrieb der installierten Anlage und Maschinen zu gew&auml;hrleisten, muss eine kontinuierliche &Uuml;berwachung der Spannungsqualit&auml;t in allen technischen Anlagen nach der IEC 61000-2-4 erfolgen.</p>  <p>Die Janitza-APP &bdquo;IEC 61000-2-4 WATCHDOG&ldquo; f&uuml;hrt automatisch die komplexe Analyse der Messdaten nach den Grenzwerten der Norm f&uuml;r den Anwender aus. Die integrierte Visualisierung, die nach dem Ampelprinzip konzipiert wurde, erlaubt eine sofortige Erkennung bei Verletzung der Grenzwerte der Norm.</p>  <p><span class=\"gve-gema-app-description-hint\">Hinweis: </span><br />Die IEC 61000-2-4 wird mit dieser App nicht vollst&auml;ndig abgedeckt, da nicht alle notwendigen Variablen von dem Ger&auml;t unterst&uuml;tzt werden.</p>  <p><span class=\"gve-gema-app-description-hint\">Hinweis: </span><br />Diese App ist kostenlos f&uuml;r PRO Ger&auml;te.<br />F&uuml;r Janitza Messger&auml;te die App kompatibel* sind, kann diese Funktionserweiterung unter dem Namen IEC 61000-2-4 Watchdog Light Art.Nr. 51.00.309 erworben werden.</p>  <p>* Diverse Janitza-Ger&auml;tetypen k&ouml;nnen mit einem Firmware-Update App-kompatibel gemacht werden.</p>",
        "descEN":"<p>The standard &ldquo;IEC 61000-2-4&rdquo; defines limits for industrial and private power distribution systems. It represents a guiding standard for many product and machinery construction standards and defines immunity levels for the voltage distortions that the machinery and systems in industrial operations must comply with in all operating states. If this level is exceeded &ndash; in particular over extended periods of time &ndash; this can lead to failures, unnecessary repair costs and possibly even to production shutdowns.</p>  <p>Continuous monitoring of the power quality in all technical systems per IEC 61000-2-4 is necessary in order to guarantee fault-free operation of the systems and machinery installed.</p>  <p>The Janitza APP &ldquo;IEC 61000-2-4 Watchdog&rdquo; automatically carries out the complex analysis of the measurement data in accordance with the threshold values of the standards for the user. The integrated visualisation, designed in the form of a traffic-light style indicator, enables immediate detection in the event of an infringement of the threshold values from the standard.</p>  <p><span class=\"gve-gema-app-description-hint\">Note: </span><br />The IEC 61000-2-4 is not fully covered with this app as not all of the necessary variables are supported by the device.</p>  <p><span class=\"gve-gema-app-description-hint\">Note: </span><br />This app is free of charge for PRO devices. For Janitza measurement devices that are app-compatible*, this functional extension can be purchased under the name IEC 61000-2-4 Watchdog Light, item no. 51.00.309.</p>  <p>* A range of Janitza device types can be made app-compatible with a firmware update.</p>",
        "menu1eb":"menu.powerquality",
        "menu2eb":-1,
        "titleDE":"IEC61000-2-4 Watchdog Light",
        "titleEN":"IEC61000-2-4 Watchdog Light",
        "href":"/app/5100308/index.html",
        "target":"",
        "icon":"/app/5100308/752.png"
    },
    "dummy"
];