/* JAVASCRIPT FOR EVENT PAGE JANITZA UMG512
 * 
 * Version:  1.1
 * Date:     06-06-2016   
 */

setTimeout(function(){
   eventsinit();
},200);


////////////////////////////////////////////
// EVENTSINIT: start javascript functions
////////////////////////////////////////////
function eventsinit(){

    $.getJSON("../javascripts/evt/getevt.html", function (data){                
        //console.log(data);                                                    // print result to console
        
        var aantalevents = data['events'].length;
        
        for(var i = 0; i < aantalevents;i++){
            
            var evtdata = convertreason(data['events'][i][6]);
                   
            var tablerow = "<tr>" +
            "<td>"+evtdata[1]+"</td>" +
            "<td>"+evtdata[2]+"</td>" +
            "<td>"+ timestrActual(data['events'][i][0]) +"</td>" +
            "<td>"+ readableSeconds(data['events'][i][1] - data['events'][i][0]) + "</td>" +
            "<td>" + data['events'][i][3].toString().replace(/\./, getDecimalPoint()) + " " + evtdata[0]+"</td>" +
            "<td>" + data['events'][i][4].toString().replace(/\./, getDecimalPoint()) + " " + evtdata[0]+"</td>" +
            "<td>" + data['events'][i][5].toString().replace(/\./, getDecimalPoint()) + " " + evtdata[0]+"</td>" +
            "<td>" + data['events'][i][2].toString().replace(/\./, getDecimalPoint()) + " " + evtdata[0]+"</td>" +
            "</tr>";
    
            $("#eventstable").append(tablerow);
        }
    });
}

////////////////////////////////////////////
// TIMESTRACTUAL: convert timestring to date/time
////////////////////////////////////////////
function timestrActual(i) {
    var DAYLENGTH = 24 * 60 * 60 * 1000; //24h in ms
    var past = new Date(i * 1000);
    var now = new Date();
    var tomorrowMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    var todayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var yesterdayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);

    //Today?

    if (past >= todayMidnight && past < tomorrowMidnight) {
        return tl("info.time.today") + ", " + PadZeros(past.getHours(), 2) + ":" + PadZeros(past.getMinutes(), 2) + ":" + PadZeros(past.getSeconds(), 2);
    }
    //Yesterday?
    if (past >= yesterdayMidnight && past < todayMidnight) {
        return tl("info.time.yesterday") + ", " + PadZeros(past.getHours(), 2) + ":" + PadZeros(past.getMinutes(), 2) + ":" + PadZeros(past.getSeconds(), 2);
    }
    return new Date(i * 1000).toLocaleString();
}


////////////////////////////////////////////
// READABLESECONDS: convert duration to sec
////////////////////////////////////////////
function readableSeconds(s)
{

    if (s > 60 * 60) {
        var h = Math.floor(s / (60 * 60));
        var m = Math.floor(s / 60) - h * 60;
        var sec = Math.runde((s - (h * 60 * 60 + m * 60)), 2);
        return  h + "h " + m + "m " + sec + "s";
    }
    if (s > 60) {
        var m = Math.floor(s / (60));
        var sec = Math.runde((s - m * 60), 2);
        return m + "m " + sec + "s";
    }

    return Math.runde(s, 2) + "s";
}

////////////////////////////////////////////
// CONVERTREASON: convert event reason to unit, type and phase
////////////////////////////////////////////
function convertreason(reason){
        
       
        var evtdata = new Array(3);
        
        console.log("reason: " + reason);       
        console.log("reasonhex: " + reason.toString(16));
        
        var eventcode = parseInt(reason.toString(16));
        console.log("eventcode: " + eventcode);
        
        //Overvoltage LN
        if(eventcode < 10){
            evtdata[0] = "V";
            evtdata[1] = ReasonToText(1);
            evtdata[2] = HexToPhase(eventcode);
            return evtdata;
        }
        
        eventcode = eventcode / 10;
 
        
        //Undervoltage LN
        if(eventcode < 10){
            evtdata[0] = "V";
            evtdata[1] = ReasonToText(2);
            evtdata[2] = HexToPhase(eventcode);
            return evtdata;
        }
        
        eventcode = eventcode / 10;
        
        //Voltage disruption LN
        if(eventcode < 10){
            evtdata[0] = "V";
            evtdata[1] = ReasonToText(4);
            evtdata[2] = HexToPhase(eventcode);
            return evtdata;
        }
        
        eventcode = eventcode / 10;
        
        //Over current
        if(eventcode < 10){
            evtdata[0] = "A";
            evtdata[1] = ReasonToText(3);
            evtdata[2] = HexToPhase(eventcode);
            return evtdata;
        }
        
        eventcode = eventcode / 10;
        
        //Unknown
        if(eventcode < 10){
            evtdata[0] = "-";
            evtdata[1] = ReasonToText(0);
            evtdata[2] = HexToPhase(eventcode);
            return evtdata;
        }
        
        eventcode = eventcode / 10;     
        
        //Overvoltage LL
        if(eventcode < 10){
            evtdata[0] = "V";
            evtdata[1] = ReasonToText(1);
            evtdata[2] = HexToPhase(eventcode + 10);
            return evtdata;
        }
        
        eventcode = eventcode / 10;
        
        //Undervoltage LL
        if(eventcode < 10){
            evtdata[0] = "V";
            evtdata[1] = ReasonToText(2);
            evtdata[2] = HexToPhase(eventcode + 10);
            return evtdata;
        }
        
        eventcode = eventcode / 10;
        
        //Voltage disruption LL
        if(eventcode < 10){
            evtdata[0] = "V";
            evtdata[1] = ReasonToText(4);
            evtdata[2] = HexToPhase(eventcode + 10);
            return evtdata;
        }
        
       
        return evtdata;
        
}

////////////////////////////////////////////
// HEXTOPHASE: convert hex to phase
////////////////////////////////////////////
function HexToPhase(i) {
    if (i === 1)
        return "L1";
    if (i === 2)
        return "L2";
    if (i === 4)
        return "L3";
    if (i === 8)
        return "L4";
    if (i === 11)
        return "L1-L2";
    if (i === 12)
        return "L2-L3";
    if (i === 14)
        return "L3-L1";

   
}

////////////////////////////////////////////
// HEXTOPHASE: convert binary reason to text
////////////////////////////////////////////

function ReasonToText(i){
    if (i === 0)
        return tl("-");
    if (i === 1)
        return tl("events.overvoltage");
    if (i === 2)
        return tl("events.undervoltage");
    if (i === 3)
        return tl("events.overcurrent");
    if (i === 4)
        return tl("events.voltageoff");
    
}


function PadZeros(i, len) {
    var s = i.toString();
    var erg = "";
    for (var d = 0; d < len - s.length; d++)
        erg += "0";
    return erg + s;

}
