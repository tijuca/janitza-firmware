/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function hideL4() {
    $.ajax(
            {
                url: "/json.do?_DREILEITER",
                dataType: "json",
                success: function(data) {
                    if (data["_DREILEITER"][0] === 1) {
                                 /*soverview*/
                        var $obj = jQuery(".showtable").find("td:contains('L4')").parent();
                        if ($obj.length > 0)
                            $obj.hide();
                        else
                        /*overview*/

                        if (jQuery(".toggle-content").find("#frame1").prop("src").indexOf("voltage") > 0){
                            $obj = jQuery(".toggle-content").find("#frame1").contents().find("td:contains('L')").not("td:contains('-')").parent();
                            $obj.hide();
                        }
                         $obj =  jQuery(".toggle-content").find("#frame1").contents().find("td:contains('L4')").parent();
                        if ($obj.length > 0){
                            $obj.hide();
                        }
                        $obj =  jQuery(".toggle-content").find("#frame1").contents().find("option:contains('L4')");
                        if ($obj.length > 0){
                            $obj.hide();
                        }



                    } else {

                        var $obj = jQuery(".showtable").find("td:contains('L4')").parent();
                        if ($obj.length > 0){
                            $obj.show();
                        }
                        else
                        {
                          if (jQuery(".toggle-content").find("#frame1").prop("src").indexOf("voltage") > 0){
                              $obj = jQuery(".toggle-content").find("#frame1").contents().find("td:contains('L')").not("td:contains('-')").parent();
                          }
                          else
                          {
                            var $obj =  jQuery(".toggle-content").find("#frame1").contents().find("td:contains('L4')").parent();
                          }
                        }
                        if ($obj.length > 0){
                            $obj.show();
                        }
                        $obj =  jQuery(".toggle-content").find("#frame1").contents().find("option:contains('L4')");
                        if ($obj.length > 0){
                            $obj.show();
                        }
                    }
                }
            });



}


