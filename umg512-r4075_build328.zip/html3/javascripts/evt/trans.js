/* JAVASCRIPT FOR TRANSIENT PAGE JANITZA UMG512
 * 
 * Version:  1.0
 * Date:     12-5-2016   
 */

setTimeout(function(){
addTrans();
$("#transhint").html(tl("transhint"));
   transinit();
},200); 


////////////////////////////////////////////
// transINIT: start javascript functions
////////////////////////////////////////////
function transinit(){

    $.getJSON("../javascripts/evt/gettrns.html", function (data){                
        //console.log(data);                                                    // print result to console
        
        var aantaltrans = data['trans'].length;
        
        for(var i = 0; i < aantaltrans;i++){
            
          //  var evtdata = convertreason(data['trans'][i][6]);
            
            
            var tablerow = "<tr>" +
              "<td>"+ (i+1) +"</td>" +
            "<td>"+ timestrActual(data['trans'][i][0]) +"</td>" +
            "<td>"+HexToPhase(data['trans'][i][1])+"</td>" +

            "</tr>";
    
            $("#transtable").append(tablerow);
        }
        
        
                
    
        
    });
}


////////////////////////////////////////////
// TIMESTRACTUAL: convert timestring to date/time
////////////////////////////////////////////
function timestrActual(i) {
    var DAYLENGTH = 24 * 60 * 60 * 1000; //24h in ms
    var past = new Date(i * 1000);
    var now = new Date();
    var tomorrowMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    var todayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var yesterdayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);

    //Today?

    if (past >= todayMidnight && past < tomorrowMidnight) {
        return tl("info.time.today") + ", " + PadZeros(past.getHours(), 2) + ":" + PadZeros(past.getMinutes(), 2) + ":" + PadZeros(past.getSeconds(), 2);
    }
    //Yesterday?
    if (past >= yesterdayMidnight && past < todayMidnight) {
        return tl("info.time.yesterday") + ", " + PadZeros(past.getHours(), 2) + ":" + PadZeros(past.getMinutes(), 2) + ":" + PadZeros(past.getSeconds(), 2);
    }
    return new Date(i * 1000).toLocaleString();
}


////////////////////////////////////////////
// READABLESECONDS: convert duration to sec
////////////////////////////////////////////
function readableSeconds(s)
{

    if (s > 60 * 60) {
        var h = Math.floor(s / (60 * 60));
        var m = Math.floor(s / 60) - h * 60;
        var sec = Math.runde((s - (h * 60 * 60 + m * 60)), 2);
        return  h + "h " + m + "m " + sec + "s";
    }
    if (s > 60) {
        var m = Math.floor(s / (60));
        var sec = Math.runde((s - m * 60), 2);
        return m + "m " + sec + "s";
    }

    return Math.runde(s, 2) + "s";
}

////////////////////////////////////////////
// CONVERTREASON: convert event reason to unit, type and phase
////////////////////////////////////////////
function convertreason(reason){
        
       
        var evtdata = new Array(3);
        
        console.log("reason: " + reason);       
        console.log("reasonhex: " + reason.toString(16));
        
        //overvoltage
        var tmp = reason >> 0 & 0xFF;
        console.log("temp1: " + tmp);
        if (tmp) {
            //console.log("overvoltage: " + tmp);
            evtdata[0] = "V";
               evtdata[1] = "--";
            evtdata[2] = HexToPhase(tmp);
           
        }
        //undervoltage
        var tmp = reason >> 8 & 0xFF;
        console.log("temp2: " + tmp);
        if (tmp) {
            //console.log("undervoltage: " + tmp);
            evtdata[0] = "V";
               evtdata[1] = "--";
            evtdata[2] = HexToPhase(tmp);
            
        }
        //overcurrent
        var tmp = reason >> 16 & 0xFF;
        console.log("temp3: " + tmp);
        if (tmp) {
            //console.log("overcurrent: " + tmp);
            evtdata[0] = "A";
               evtdata[1] = "--";
            evtdata[2] = HexToPhase(tmp);
            
        }
        //voltage break
        var tmp = reason >> 24 & 0xFF;
        console.log("temp4: " + tmp);
        if (tmp) {
            //console.log("voltage disrupt: " + tmp);
            evtdata[0] = "V";
            evtdata[1] = "--";
            evtdata[2] = HexToPhase(tmp);
           
        }
        
        return evtdata;
        
}

////////////////////////////////////////////
// HEXTOPHASE: convert hex to phase
////////////////////////////////////////////
function HexToPhase(i) {
    if (i === 0)
        return "L1";
    if (i === 1)
        return "L2";
    if (i === 2)
        return "L3";
    if (i === 3)
        return "L4";
    if (i === 4)
        return "L1-L2";
    if (i === 5)
        return "L2-L3";
    if (i === 6)
        return "L3-L1";
}

////////////////////////////////////////////
// HEXTOPHASE: convert binary reason to text
////////////////////////////////////////////

function ReasonToText(i){
    if (i === 1)
        return tl("trans.overvoltage");
    if (i === 2)
        return tl("trans.undervoltage");
    if (i === 3)
        return tl("trans.overcurrent");
    if (i === 4)
        return tl("trans.voltageoff");
    
}


function PadZeros(i, len) {
    var s = i.toString();
    var erg = "";
    for (var d = 0; d < len - s.length; d++)
        erg += "0";
    return erg + s;

}

function addTrans(){
  AddTranslation("en","transhint","only the last 32 transients are enlisted here.");
    AddTranslation("de","transhint","Nur die letzten 32 Transienten werden hier aufgelistet.");
}