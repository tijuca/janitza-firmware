
function pqstatusinit() {
    geteventtranscnt();
    getiecindication();
    getenindication();
}


function geteventtranscnt() {

    var evtcounter = 0;
    var trncounter = 0;


    $.get("/lib/events/hww.html", function (data) {

        //fill events
        var data = data.split("-NEXT_ARRAY-");
        var evtdata = eval("(" + data[1] + ")");
        var trndata = eval("(" + data[2] + ")");

        //create dates now and 24 hours ago
        var now = new Date();
        var past = new Date();
        past.setHours(past.getHours() - 24);

        //loop through events to count last 24 hours
        for (var i = 0; i < evtdata.length; i++) {
            var evttime = parseInt(evtdata[i].StartTime) * 1000;
            if (evttime < now.getTime() && evttime > past.getTime()) {
                evtcounter++;
            }
        }

        //loop through transients to count last 24 hours
        for (var i = 0; i < trndata.length; i++) {
            var trntime = parseInt(trndata[i].StartTime) * 1000;
            if (trntime < now.getTime() && trntime > past.getTime()) {
                trncounter++;
            }
        }

        //fill values in on page
        $("#evtcnt").html(evtcounter);
        $("#trncnt").html(trncounter);

    });


}

function getiecindication() {

    var failure = false;

    //create url with required variables
    var url = url = "../.../.../../../json.do?";
    url += "_ULN_AVG[0..2],_ULL_AVG[0..2],_THD_ULN_AVG[0..2],_FREQ_AVG,_U_SYM_AVG";
    url += ",_FFT_UL1[0..50],_FFT_UL2[0..50],_FFT_UL3[0..50]";
    url += ",_NOMINAL_U[0],_NOMINAL_F,_PHASE_MODE,_GBL_50160_LASTSTATUS,_GBL_IEC_LASTSTATUS,";

    //request data
    $.getJSON(url, function (data) {

        //determine voltage limits
        var phase_mode = data['_PHASE_MODE'][0];
        var nominalvoltage = data['_NOMINAL_U'][0][0];
        if (phase_mode === 0) {                                                 // L/N                           
            var ULNMIN = nominalvoltage - (nominalvoltage * 0.1);
            var ULNMAX = nominalvoltage + (nominalvoltage * 0.1);
            var ULLMIN = (Math.sqrt(3) * nominalvoltage) - ((Math.sqrt(3) * nominalvoltage) * 0.1);
            var ULLMAX = (Math.sqrt(3) * nominalvoltage) + ((Math.sqrt(3) * nominalvoltage) * 0.1);
        } else {                                                                // L/L
            var ULNMIN = (nominalvoltage / Math.sqrt(3)) - ((nominalvoltage / Math.sqrt(3)) * 0.1);
            var ULNMAX = (nominalvoltage / Math.sqrt(3)) + ((nominalvoltage / Math.sqrt(3)) * 0.1);
            var ULLMIN = nominalvoltage - (nominalvoltage * 0.1);
            var ULLMAX = nominalvoltage + (nominalvoltage * 0.1);
        }

        //determine frequency limits
        var nominalfreq = data['_NOMINAL_F'][0];

        if (nominalfreq === 0) {
            var freqavg = data['_FREQ_AVG'][0];
            var nominalfreq = Math.round(freqavg / 10) * 10;
        }
        var FREQMIN = nominalfreq - (nominalfreq * 0.02);
        var FREQMAX = nominalfreq + (nominalfreq * 0.02);

        //check voltage minimum
        if (data['_ULN_AVG'][0][0] < ULNMIN || data['_ULN_AVG'][0][1] < ULNMIN || data['_ULN_AVG'][0][1] < ULNMIN) {
            failure = true;
        }
         if (data['_ULL_AVG'][0][0] < ULLMIN || data['_ULL_AVG'][0][1] < ULLMIN || data['_ULL_AVG'][0][1] < ULLMIN) {
            failure = true;
        }

        //check voltage maximum
        if (data['_ULN_AVG'][0][0] > ULNMAX || data['_ULN_AVG'][0][1] > ULNMAX || data['_ULN_AVG'][0][2] > ULNMAX) {
            failure = true;
        }
        if (data['_ULL_AVG'][0][0] > ULLMAX || data['_ULL_AVG'][0][1] > ULLMAX || data['_ULL_AVG'][0][2] > ULLMAX) {
            failure = true;
        }

        //check frequency
        if (data['_FREQ_AVG'][0] < FREQMIN || data['_FREQ_AVG'][0] > FREQMAX) {
            failure = true;
        }

        //check THD-U
        if (data['_THD_ULN_AVG'][0][0] > 8 || data['_THD_ULN_AVG'][0][1] > 8 || data['_THD_ULN_AVG'][0][2] > 8) {
            failure = true;
        }

        //check asym
        if (data['_U_SYM_AVG'][0] > 2) {
            failure = true;
        }

        //check harmonics
        var c2limits = [100, 2, 5, 1, 6, 0.5, 5, 0.5, 1.5, 0.5, 3.5, 0.46, 3, 0.43, 0.40, 0.41, 2, 0.39, 1.76, 0.38, 0.20, 0.36, 1.41, 0.20, 1.27, 0.35, 0.20, 0.34, 1.06, 0.20, 0.97, 0.33, 0.20, 0.32, 0.83, 0.20, 0.77, 0.32, 0.20, 0.31, 0.67, 0.20, 0.63, 0.31, 0.20, 0.30, 0.55, 0.20, 0.52, 0.30];

        for (var i = 1; i < 50; i++) {
            var value1 = (100 * data["_FFT_UL1"][0][i]) / data["_FFT_UL1"][0][0];
            var value2 = (100 * data["_FFT_UL2"][0][i]) / data["_FFT_UL2"][0][0];
            var value3 = (100 * data["_FFT_UL3"][0][i]) / data["_FFT_UL3"][0][0];
            if (value1 > c2limits[i]) { failure = true; };
            if (value2 > c2limits[i]) { failure = true; };
            if (value3 > c2limits[i]) { failure = true; };
        }

        if(failure){
            $("#iecind").html("<img src='../../../img/fail.png' alt='failed' title='" + tl('home.iecred') + "' style='width: 30px; height: 30px;'>");  
        }else{
            $("#iecind").html("<img src='../../../img/pass.png' alt='passed' title='" + tl('home.iecgreen') + "' style='width: 30px; height: 30px;'>");
        }
        
        //last report status
        if(data['_GBL_IEC_LASTSTATUS'][0] === 3){
            $("#iecrep").html("<img src='../../../img/fail.png' alt='failed' title='" + tl('home.iecred') + "' style='width: 30px; height: 30px;'>");  
        }else if(data['_GBL_IEC_LASTSTATUS'][0] === 2){
            $("#iecrep").html("<img src='../../../img/warn.png' alt='warn' title='" + tl('home.iecorange') + "' style='width: 30px; height: 30px;'>");  
        }else if(data['_GBL_IEC_LASTSTATUS'][0] === 1){
            $("#iecrep").html("<img src='../../../img/pass.png' alt='pass' title='" + tl('home.iecgreen') + "'  style='width: 30px; height: 30px;'>");  
        }else{
            $("#iecrep").html("<img src='../../../img/icon_help_bk.png' alt='pass' title='" + tl('home.iecna') + "' style='width: 30px; height: 30px;'>");  
        }
        
         
        //last report status
        if(data['_GBL_50160_LASTSTATUS'][0] === 3){
            $("#enrep").html("<img src='../../../img/fail.png' alt='failed' title='" + tl('home.enred') + "' style='width: 30px; height: 30px;'>");  
        }else if(data['_GBL_50160_LASTSTATUS'][0] === 2){
            $("#enrep").html("<img src='../../../img/warn.png' alt='warn' title='" + tl('home.enorange') + "' style='width: 30px; height: 30px;'>");  
        }else if(data['_GBL_50160_LASTSTATUS'][0] === 1){
            $("#enrep").html("<img src='../../../img/pass.png' alt='pass' title='" + tl('home.engreen') + "'  style='width: 30px; height: 30px;'>");  
        }else{
            $("#enrep").html("<img src='../../../img/icon_help_bk.png' alt='pass' title='" + tl('home.enna') + "' style='width: 30px; height: 30px;'>");  
        }
        
    });
}


function getenindication() {

    console.log('determine en50160');

     var failure = false;

    //create url with required variables
    var url = url = "../.../.../../../json.do?";
    url += "_ULN_AVG[0..2],_ULL_AVG[0..2],_THD_ULN_AVG[0..2],_FREQ_AVG,_U_SYM_AVG";
    url += ",_FFT_UL1[0..25],_FFT_UL2[0..25],_FFT_UL3[0..25],_FLI_LONG_TERM[0..2]";
    url += ",_NOMINAL_U[0],_NOMINAL_F,_PHASE_MODE,";

    //request data
    $.getJSON(url, function (data) {

        //determine voltage limits
        var phase_mode = data['_PHASE_MODE'][0];
        var nominalvoltage = data['_NOMINAL_U'][0][0];
        if (phase_mode === 0) {                                                 // L/N                           
            var ULNMIN = nominalvoltage - (nominalvoltage * 0.1);
            var ULNMAX = nominalvoltage + (nominalvoltage * 0.1);
            var ULLMIN = (Math.sqrt(3) * nominalvoltage) - ((Math.sqrt(3) * nominalvoltage) * 0.1);
            var ULLMAX = (Math.sqrt(3) * nominalvoltage) + ((Math.sqrt(3) * nominalvoltage) * 0.1);
        } else {                                                                // L/L
            var ULNMIN = (nominalvoltage / Math.sqrt(3)) - ((nominalvoltage / Math.sqrt(3)) * 0.1);
            var ULNMAX = (nominalvoltage / Math.sqrt(3)) + ((nominalvoltage / Math.sqrt(3)) * 0.1);
            var ULLMIN = nominalvoltage - (nominalvoltage * 0.1);
            var ULLMAX = nominalvoltage + (nominalvoltage * 0.1);
        }

        //determine frequency limits
        var nominalfreq = data['_NOMINAL_F'][0];

        if (nominalfreq === 0) {
            var freqavg = data['_FREQ_AVG'][0];
            var nominalfreq = Math.round(freqavg / 10) * 10;
        }
        var FREQMIN = nominalfreq - (nominalfreq * 0.01);
        var FREQMAX = nominalfreq + (nominalfreq * 0.01);

        //check voltage minimum
        if (data['_ULN_AVG'][0][0] < ULNMIN || data['_ULN_AVG'][0][1] < ULNMIN || data['_ULN_AVG'][0][1] < ULNMIN) {
            failure = true;
        }
         if (data['_ULL_AVG'][0][0] < ULLMIN || data['_ULL_AVG'][0][1] < ULLMIN || data['_ULL_AVG'][0][1] < ULLMIN) {
            failure = true;
        }

        //check voltage maximum
        if (data['_ULN_AVG'][0][0] > ULNMAX || data['_ULN_AVG'][0][1] > ULNMAX || data['_ULN_AVG'][0][2] > ULNMAX) {
            failure = true;
        }
        if (data['_ULL_AVG'][0][0] > ULLMAX || data['_ULL_AVG'][0][1] > ULLMAX || data['_ULL_AVG'][0][2] > ULLMAX) {
            failure = true;
        }

        //check frequency
        if (data['_FREQ_AVG'][0] < FREQMIN || data['_FREQ_AVG'][0] > FREQMAX) {
            failure = true;
        }

        //check THD-U
        if (data['_THD_ULN_AVG'][0][0] > 8 || data['_THD_ULN_AVG'][0][1] > 8 || data['_THD_ULN_AVG'][0][2] > 8) {
            failure = true;
        }

        //check asym
        if (data['_U_SYM_AVG'][0] > 2) {
            failure = true;
        }
        
        //check Long-term-flicker
        if (data['_FLI_LONG_TERM'][0][0] > 1 || data['_FLI_LONG_TERM'][0][1] > 1 || data['_FLI_LONG_TERM'][0][2] > 1) {
            failure = true;
        }

        //check harmonics
         var c2limits = [100,2, 5, 1, 6, 0.5, 5, 0.5, 1.5, 0.5, 3.5, 0.5, 3.0, 0.5, 0.5, 0.5, 2, 0.5, 1.5, 0.5, 0.5, 0.5, 1.5, 0.5, 1.5];

        for (var i = 1; i < 25; i++) {
            var value1 = (100 * data["_FFT_UL1"][0][i]) / data["_FFT_UL1"][0][0];
            var value2 = (100 * data["_FFT_UL2"][0][i]) / data["_FFT_UL2"][0][0];
            var value3 = (100 * data["_FFT_UL3"][0][i]) / data["_FFT_UL3"][0][0];
            if (value1 > c2limits[i]) { failure = true; };
            if (value2 > c2limits[i]) { failure = true; };
            if (value3 > c2limits[i]) { failure = true; };
        }

        if(failure){
            $("#enind").html("<img src='../../../img/fail.png' alt='failed' title='" + tl('home.enred') + "' style='width: 30px; height: 30px;'>");  
        }else{
            $("#enind").html("<img src='../../../img/pass.png' alt='pass' title='" + tl('home.engreen') + "'  style='width: 30px; height: 30px;'>");
        }
    });
}
