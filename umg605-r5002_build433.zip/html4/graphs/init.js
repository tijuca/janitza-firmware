///////////////////////////////
// GLOBAL VARIABLES
///////////////////////////////
var mode = 0;                                                                   // => mode selection, 0 = online, 1 = historical
var graphdata = {};
var flotrgraph;
var unit1, unit2;                                                               // => the 2 units for the y axis
var currentoption = [];
var numberofvars = 0;
var graphcolors = new Array('#00A8F0', '#C0D800', '#CB4B4B', '#4DA74D', '#9440ED', '#000000');
var colornumber = 0;

///////////////////////////////
// INITIALISATION FUNCTIONS, STARTS ALL OTHER FUNCTIONS
///////////////////////////////
function initreset() {
    $("#resetbtn").button();
    $("#resetbtn").click(function(event) {

        graphdata = {};
        graphcolors = new Array('#00A8F0', '#C0D800', '#CB4B4B', '#4DA74D', '#9440ED', '#000000');
        colornumber = 0;
        unit1 = undefined;
        unit2 = undefined;
        $('.ui-draggable').show();
        $("#valuestable > tbody > tr").remove();
        if (mode === 1) {
            drawgraphhistorical();
        }
        numberofvars = 0;

    });
}

function initprint() {
    $("#printbtn").button();
    $("#printbtn").click(function(event) {
        //flotrgraph.download.saveImage("png", null, null, false);
        window.print();
    });
}

function initdateselector() {
    $('#dateselectorfrom').datepicker({
        changeMonth: true,
        changeYear: true,
        maxDate: new Date(),
        onClose: function(selectedDate) {
            $("#dateselectorto").datepicker("option", "minDate", selectedDate);
        }
    }).datepicker("setDate", new Date());

    var enddate = new Date();


    $('#dateselectorto').datepicker({
        changeMonth: true,
        changeYear: true,
        maxDate: enddate,
        onClose: function(selectedDate) {


            $("#dateselectorfrom").datepicker("option", "maxDate", selectedDate);
        }
    }).datepicker("setDate", enddate);
}

///////////////////////////////
// MODE SELECTION
///////////////////////////////
function modeselection() {
    $('#mode1').click(function() {                                              // => online mode selected
        if (mode !== 0) {                                                       // => check if mode is not current mode
            mode = 0;                                                           // => change mode
            $('#mode1').css('background-color', '#666666');                     // => change button colors
            $('#mode2').css('background-color', '#b7b7b7');
            $("#valuelist").remove();                                           // => remove historical valuelist
            $("#dateselector").hide();                                          // => hide dateselector
            $("#menu-bar-app").append('<div id="valuelist"></div>');            // => create new valuelist
            onlinevaluelist();                                                  // => fill online valuelist
            graphdata = {};
            unit1 = undefined;
            unit2 = undefined;
            $('.ui-draggable').show();
            $("#valuestable > tbody > tr").remove();
            drawgraphhistorical();
            graph();
            numberofvars = 0;
            graphcolors = new Array('#00A8F0', '#C0D800', '#CB4B4B', '#4DA74D', '#9440ED', '#000000');
            colornumber = 0;
            //$('#footernotice').hide();
        }
    });
    $('#mode2').click(function() {                                              // => historical mode selected
        if (mode !== 1) {                                                       // => check if mode is not current mode
            mode = 1;                                                           // => change mode
            $('#mode2').css('background-color', '#666666');                     // => change button colors
            $('#mode1').css('background-color', '#b7b7b7');
            $("#valuelist").remove();                                           // => remove realtime valuelist
            $("#dateselector").show();                                          // => show dateselector
            $("#menu-bar-app").append('<div id="valuelist"></div>');            // => create new valuelist
            historicalvaluelist();
            initdateselector();
            graphdata = {};
            unit1 = undefined;
            unit2 = undefined;
            $('.ui-draggable').show();
            $("#valuestable > tbody > tr").remove();
            drawgraphhistorical();
            numberofvars = 0;
            graphcolors = new Array('#00A8F0', '#C0D800', '#CB4B4B', '#4DA74D', '#9440ED', '#000000');
            colornumber = 0;
            //$('#footernotice').show();
        }
    });
}

///////////////////////////////
// ONLINE VALUE LIST, CREATES THE VALUELIST FOR ONLINE VALUES
///////////////////////////////
function onlinevaluelist() {
    $.getJSON("graphs/values.json", function(values) {                                 // => read values.json file
        $.each(values, function(item) {                                         // => loop through all valuetype
            var block = jQuery("<h3/>");                                        // => create block for new valuetype
            block.attr("id", item);                                             // => set block id
            block.text(tl(item));                                               // => set block name
            var list = jQuery("<div/>");                                        // => create new list for variables
            var listitems = jQuery("<ul/>");                                    // => create new list items for variables
            $.each(values[item], function(item2) {                              // => loop through all values in one block
                var valueitem = jQuery("<li/>");                                // => create new variableitem
                valueitem.attr("requestvalue", values[item][item2]['requestvalue']);
                valueitem.text(tl(values[item][item2]['requestvalue']));
                listitems.append(valueitem);                                    // => add variable to listitems
            });
            list.append(listitems);
            $("#valuelist").append(block);                                      // => add valuelist to valuelist
            $("#valuelist").append(list);
        });

        $("#valuelist").accordion({
            heightStyle: "content",
            collapsible: true
        });

        $("#valuelist li").draggable({
            appendTo: "body",
            helper: "clone",
            start: function(e, ui)
            {
                $(ui.helper).addClass("ui-draggable-helper");
            }
        });
    });
}

///////////////////////////////
// HISTORICAL VALUE LIST, CREATES THE VALUELIST FOR HISTORICAL VALUES
///////////////////////////////
function historicalvaluelist() {
    var valueoverload = 0;
    $.getJSON("graphs/REC_LIST.html", function(records) {
        $.each(records, function(values) {
            var nummin = records[values][1] / 60;

            if (nummin >= 1) {

                var block = jQuery("<h3/>");
                block.attr("id", "record" + values);
                block.attr("timebase", records[values][1]);

                block.text("Record: " + values + "  /  " + nummin + " min");
                var list = jQuery("<div/>");
                var listitems = jQuery("<ul/>");
                var valuecounter = 0;
                $.each(records[values][0], function(value) {
                    valuecounter++;
                    var valueitem = jQuery("<li/>");                                // => create new variableitem
                    valueitem.attr("unit", "---");
                    valueitem.attr("timebase", records[values][1]);
                    valueitem.attr("requestvalue", records[values][0][value]);
                    valueitem.text(tl(records[values][0][value]));
                    listitems.append(valueitem);
                });

                if (valuecounter > 229) {
                    valueoverload = 1;
                }

                list.append(listitems);
                $("#valuelist").append(block);
                $("#valuelist").append(list);
            }
        });

        //activate valuelist   
        $("#valuelist").accordion({
            heightStyle: "content",
            collapsible: true
        });
        $("#valuelist li").draggable({
            appendTo: "body",
            helper: "clone",
            start: function(e, ui)
            {
                $(ui.helper).addClass("ui-draggable-helper");
            }
        });

        if (valueoverload === 1) {
            alert(tl('mma.valueoverload'));
        }
    });
}

///////////////////////////////
// REQUEST HISTORICAL VARLIST OF SPECIFIC RECORD
///////////////////////////////
function requesthistoricalvarlist(record) {
    var result = null;
    var variables = [];
    var url = '/data/records/rec' + record;                                     // => create requesturl
    $.ajax({// => request variables
        url: url,
        type: 'get',
        dataType: 'html',
        async: false,
        success: function(data) {
            result = data;
        }
    });
    result = result.split('\n');                                                // => fill variables into array
    for (var i = 2; i < result.length - 2; i++) {
        var data = result[i].split('"');
        var value = data[1];
        var unit = data[3];
        var variable = [value, unit];
        variables.push(variable);
    }
    return variables;                                                           // => return variables
}

///////////////////////////////
// CREATE A DROP ZONE AND HANDLE DROPPED VARIABLES
///////////////////////////////
function createdropzone() {
    $("#dropzone").droppable({
        drop: function(event, ui) {

            if (mode === 0) {                                                   // => online mode           
                //append to table
                var id = ui.draggable.attr("requestvalue");                         // => save id's
                var go = true;
                var result;
                var url = '/json.do?' + id;                                         // => create requesturl
                $.ajax({// => request variables
                    url: url,
                    type: 'get',
                    dataType: 'json',
                    async: false,
                    success: function(data) {
                        result = data;
                    }
                });
                var unit;
                $.each(result, function(key, value) {
                    unit = value[1];
                });
                if (unit1 === undefined || unit1 === unit) {
                    unit1 = unit;
                } else if (unit2 === undefined || unit2 === unit) {
                    unit2 = unit;
                } else {
                    alert(tl('mma.noyaxis'));
                    go = false;

                }
                if (numberofvars === 6) {
                    alert(tl('mma.maxvalues'));
                    go = false;
                }

                if (go) {
                    numberofvars = numberofvars + 1;

                    if (colornumber > 5) {
                        var color = get_random_color();
                    } else {
                        var color = graphcolors[colornumber];
                    }
                    colornumber = colornumber + 1;
                    graphdata[id] = [tl(id), [], unit, color];
                    $(ui.draggable).hide();
                    var table = '<tr id=' + id + '>';                               // => add to online tables
                    table += '<td id="name' + id + '">' + tl(id) + '</td>';
                    table += '<td>' + sysvar(id, AUTOUPDATE, HOOK(valuehook)) + '</td>';
                    table += '<td id="min' + id + '"></td>';
                    table += '<td id="max' + id + '"></td>';
                    table += '<td class="optionmenu"></td>';
                    table += '</tr>';
                    $('#valuestable > tbody:last').append(table);

                    $('#valuestable > tbody:last > tr > td.optionmenu').click(function(evtobject) {
                        currentoption = $(evtobject.target).parent().attr('id');
                        $('#optiondialog .title').text(tl(currentoption));
                        $('#colval').css('background-color', graphdata[currentoption][3]);
                        $('#colorchooser').css('background-color', graphdata[currentoption][3]);
                        $('#optiondialog').show();
                    });
                }
            } else {
                $('#loader').show();
                //append to table
                var id = ui.draggable.attr("requestvalue");                         // => save id's
                var timebase = ui.draggable.attr("timebase");
                var go = true;
                var result;

                var record = ui.draggable.parent().parent().prev().attr('number');
                var starttime = $('#dateselectorfrom').datepicker("getDate");
                starttime = starttime / 1000;
                starttime = starttime + (new Date().getTimezoneOffset() * -60);


                var endtime = $('#dateselectorto').datepicker("getDate");
                var endtimedate = new Date(endtime);
                endtimedate.setDate(endtimedate.getDate() + 1);
                endtime = endtimedate.getTime();
                endtime = endtime / 1000;

                endtime = endtime + (new Date().getTimezoneOffset() * -60);

                var duration = endtime - starttime;
                var count = duration / timebase;
                if (count > 10000) {
                    alert(tl('mma.datapointsoverload'));
                    $('#loader').hide();
                } else {
                    $(ui.draggable).hide();
                    requestdata(id, count, timebase, starttime, endtime);
                }
            }
        }
    });
}


//////////////////////////////////////
// GETTING HISTORICAL DATA FROM DEVICE
//////////////////////////////////////
function requestdata(value, count, timebase, s, endtime) {
    var data = [];
    s = s - timebase;
    count = count + 1;
    endtime = parseInt(endtime) + parseInt(timebase);
    requestround();
    function requestround() {
        if (count > 900) {
            $.getJSON("../../../../../hist_data/hist_data.html", "val$=" + value + "&start=" + s + "&cnt=" + 900 + "&tb=" + timebase, function(requestvalue)
            {
                $(requestvalue[value][0]).each(function(i) {
                    data.push([ (parseInt(requestvalue[value][0][i][1]) +  parseInt(timebase)) * 1000, requestvalue[value][0][i][0]]);
                });
                s = data[data.length - 1][0] / 1000;

                var duration = endtime - s;
                if (duration > 0) {
                    count = duration / timebase;
                } else {
                    count = 1;
                }
                requestround();
            });
        } else {
            $.getJSON("../../../../hist_data/hist_data.html", "val$=" + value + "&start=" + s + "&cnt=" + count + "&tb=" + timebase, function(requestvalue)
            {
                $(requestvalue[value][0]).each(function(i) {
                    data.push([ (parseInt(requestvalue[value][0][i][1]) + parseInt(timebase)) * 1000, requestvalue[value][0][i][0]]);
                });
                getunit(data, value);
            });
        }
    }
}

function getunit(data, value) {
    $.getJSON("../.../../../json.do?" + value, function(variable) {
        var valuearray = value.split("[");
        var unit = variable[valuearray[0]][1];
        preparehistdata(data, value, unit);
    });
}


function preparehistdata(data, id, unit) {
    var go = true;

    if (unit1 === undefined || unit1 === unit) {
        unit1 = unit;
    } else if (unit2 === undefined || unit2 === unit) {
        unit2 = unit;
    } else {
        alert(tl('mma.noyaxis'));
        go = false;
    }

    if (numberofvars === 6) {
        alert(tl('mma.maxvalues'));
        go = false;
    }

    var min;
    var max;

    $.each(data, function(item) {
        if (min === undefined || data[item][1] < min) {
            min = data[item][1];
            min = Math.round(min * 1000) / 1000;
        }
        if (max === undefined || data[item][1] > max) {
            max = data[item][1];
            max = Math.round(max * 1000) / 1000;
        }
    });

    if (min === undefined && max === undefined) {
        alert(tl('mma.nodataminmax'));
        go = false;
    }

    var endtime = $('#dateselectorto').datepicker("getDate");
    var endtimedate = new Date(endtime);
    endtimedate.setDate(endtimedate.getDate() + 1);
    endtime = endtimedate.getTime();
    endtime = endtime / 1000;
    endtime = endtime + (new Date().getTimezoneOffset() * -60);
    console.log(data[0][0]/1000 + "   " + endtime);
    if (data[0][0]/1000 > endtime) {
        alert(tl('mma.nodataminmax'));
        go = false;
    }


    if (go) {
        if (colornumber > 5) {
            var color = get_random_color();
        } else {
            var color = graphcolors[colornumber];
        }
        colornumber = colornumber + 1;
        numberofvars = numberofvars + 1;
        graphdata[id] = [tl(id), data, unit, color];
        //$(ui.draggable).hide();
        var table = '<tr id=' + id + '>';                               // => add to online tables
        table += '<td id="name' + id + '">' + tl(id) + '</td>';
        table += '<td>' + sysvar(id, AUTOUPDATE) + '</td>';

        if (min !== undefined) {
            var minstring = min.toString().replace(/\./, getDecimalPoint());
        }
        if (max !== undefined) {
            var maxstring = max.toString().replace(/\./, getDecimalPoint());
        }


        table += '<td id="min' + id + '">' + minstring + ' ' + unit + '</td>';
        table += '<td id="max' + id + '">' + maxstring + ' ' + unit + '</td>';
        table += '<td class="optionmenu"></td>';
        table += '</tr>';
        $('#valuestable > tbody:last').append(table);

        $('#valuestable > tbody:last > tr > td.optionmenu').click(function(evtobject) {
            currentoption = $(evtobject.target).parent().attr('id');
            $('#optiondialog .title').text(tl(currentoption));
            $('#colval').css('background-color', graphdata[currentoption][3]);
            $('#colorchooser').css('background-color', graphdata[currentoption][3]);

            $('#optiondialog').show();
        });
        drawgraphhistorical();
    } else {

        $('.ui-draggable[requestvalue=' + jq2(id) + ']').show();


    }

    $('#loader').hide();
}

///////////////////////////////
// HANDLING REALTIMEVALUES
///////////////////////////////
function valuehook(sysvarobj) {
    var id = sysvarobj.varname;
    if (parseFloat($(jq('min' + id)).attr('waarde')) > parseFloat(sysvarobj.value) || $(jq('min' + id)).attr('waarde') === undefined) {
        $(jq('min' + id)).attr('waarde', sysvarobj.value);
        $(jq('min' + id)).text(sysvarobj.value.toString().replace(/\./, getDecimalPoint()));
    }
    if (parseFloat($(jq('max' + id)).attr('waarde')) < parseFloat(sysvarobj.value) || $(jq('max' + id)).attr('waarde') === undefined) {
        $(jq('max' + id)).attr('waarde', sysvarobj.value);
        $(jq('max' + id)).text(sysvarobj.value.toString().replace(/\./, getDecimalPoint()));
    }
    return sysvarobj.value;
}


// PAGE INITIALISATION
function initpage() {
   
    modeselection();                                                            // => start mode selection
    createdropzone();
    onlinevaluelist();                                                          // => fill the onlinevaluelist;
    initreset();
    initprint();
    initoptiondialog();

    $('#graphtitle').click(function() {
        $('#explanationoverlay').show();
    });

    $('#explanationoverlay').click(function() {
        $('#explanationoverlay').hide();
    });

    $("#dateselector").hide();                                                  // => hide dateselector (not needed in online mode)
    graph();
        
}


///////////////////////////////
// CONVERTING ID FOR JQUERY TO WORK
///////////////////////////////
function jq(myid) {
    return "#" + myid.replace(/(:|\.|\[|\])/g, "\\$1");
}

function jq2(myid) {
    return myid.replace(/(:|\.|\[|\])/g, "\\$1");
}

///////////////////////////////
// GRAPH FUNCTIONALITY
///////////////////////////////
function graph() {
    if (mode === 0) {                                                             // => when online mode                                                                 
        $.each(graphdata, function(id) {
            var value = parseFloat($(jq(id) + ' > td > span').text().replace(',', '.'));
            var tijd = new Date();
            tijd.setTime(tijd.getTime() + ((tijd.getTimezoneOffset() * -1) * 60000));
            if (isNaN(value) === false) {
                graphdata[id][1].push([tijd, value]);
            }
        });
        drawgraph();
        setTimeout(function() {
            graph();
        }, 500);
    }
}

///////////////////////////////
// DRAWS THE GRAPH
///////////////////////////////
function drawgraph() {
    var container = document.getElementById('container');

    $("#container").empty();

    var object = [];
    var count = 0;
    var y1label = '';
    var y2label = '';
    var datathere = false;
    $.each(graphdata, function(id) {
        var newdata = {};
        var unit = graphdata[id][2];
        if (y1label === '' || y1label === unit) {
            newdata['data'] = graphdata[id][1];
            newdata['label'] = graphdata[id][0];
            newdata['color'] = graphdata[id][3];

            object.push(newdata);
            $('#graphtitle').hide();
            datathere = true;
            y1label = unit;
        } else if (y2label === '' || y2label === unit) {
            newdata['data'] = graphdata[id][1];
            newdata['label'] = graphdata[id][0];
            newdata['color'] = graphdata[id][3];
            newdata['yaxis'] = 2;
            object.push(newdata);
            y2label = unit;
        }

    });

    if (datathere) {

        // Draw Graph
        flotrgraph = Flotr.draw(container, object, {
            xaxis: {
                mode: 'time',
                labelsAngle: 45,
                noTicks: 24

            },
            
            lines: {
                lineWidth: 1
            },
            yaxis: {
                title: y1label,
                autoscale: true,
                autoscaleMargin: 0.1,
                tickFormatter: ticksy
            },
            y2axis: {
                title: y2label,
                autoscale: true,
                autoscaleMargin: 0.1,
                tickFormatter: ticksy

            },
            mouse: {
                track: true,
                relative: true

            },
            HtmlText: false
        });
    } else {
        $('#graphtitle').show();
    }
}

function ticksy(n) {
    n = n * 100;
    n = Math.round(n) / 100;
    n = n.toString().replace(/\./, getDecimalPoint());
    //n = n + y1label;
    return n;
}
///////////////////////////////
// DRAWS THE GRAPH HISTORICAL
///////////////////////////////
function drawgraphhistorical() {
    var container = document.getElementById('container');

    Flotr.EventAdapter.stopObserving(container, 'flotr:select');
    Flotr.EventAdapter.stopObserving(container, 'flotr:click');
    $("#container").empty();

    var object = [];
    var count = 0;
    var y1label = '';
    var y2label = '';
    var datathere = false;

    $.each(graphdata, function(id) {
        var newdata = {};
        var unit = graphdata[id][2];
        if (y1label === '' || y1label === unit) {
            newdata['data'] = graphdata[id][1];
            newdata['label'] = graphdata[id][0];
            newdata['color'] = graphdata[id][3];
            object.push(newdata);
            $('#graphtitle').hide();
            datathere = true;
            y1label = unit;
        } else if (y2label === '' || y2label === unit) {
            newdata['data'] = graphdata[id][1];
            newdata['label'] = graphdata[id][0];
            newdata['color'] = graphdata[id][3];
            newdata['yaxis'] = 2;
            object.push(newdata);
            y2label = unit;
        }
    });

    if (datathere) {

        var options = {
            xaxis: {
                mode: 'time',
                labelsAngle: 45,
                noTicks: 20
            },
            lines: {
                lineWidth: 1
            },
            yaxis: {
                title: y1label,
                autoscale: true,
                tickFormatter: ticksy
            },
            y2axis: {
                title: y2label,
                autoscale: true,
                tickFormatter: ticksy

            },
            selection: {
                mode: 'x'
            },
            HtmlText: false
        };

        // Draw graph with default options, overwriting with passed options


        function drawGraphhist(opts) {
            // Clone the options, so the 'options' variable always keeps intact.
            o = Flotr._.extend(Flotr._.clone(options), opts || {});
            // Return a new graph.
            flotrgraph = Flotr.draw(container, object, o);
        }

        drawGraphhist();

        Flotr.EventAdapter.observe(container, 'flotr:select', function(area) {

            // Draw selected area
            drawGraphhist({
                xaxis: {
                    min: area.x1,
                    max: area.x2,
                    mode: 'time',
                    labelsAngle: 45,
                    noTicks: 24
                },
                yaxis: {
                    title: y1label,
                    autoscale: true,
                    autoscaleMargin: 0.1,
                    tickFormatter: ticksy,
                    noTicks: 9
                },
                y2axis: {
                    title: y2label,
                    autoscale: true,
                    autoscaleMargin: 0.1,
                    tickFormatter: ticksy,
                    noTicks: 9

                }
            });
        });

        // When graph is clicked, draw the graph with default area.
        Flotr.EventAdapter.observe(container, 'flotr:click', function() {
            drawGraphhist();
        });
    } else {
        $('#graphtitle').show();
    }
}

function initoptiondialog() {
    $('#optiondialog .closebutton').click(function() {
        $('#optiondialog').hide();
    });

    $('#rmval').click(function() {
        numberofvars = numberofvars - 1;
        $(jq(currentoption)).remove();

        var color = graphdata[currentoption][3];
        graphcolors.unshift(color);

        delete graphdata[currentoption];
        $('#optiondialog').hide();
        $('.ui-draggable[requestvalue=' + jq2(currentoption) + ']').show();
        determineunits();
        if (mode === 1) {
            drawgraphhistorical();
        }
    });

    $('#colval').click(function() {
        document.getElementById('colorchooser').color.showPicker();
    });
}

function determineunits() {
    unit1 = undefined;
    unit2 = undefined;
    $.each(graphdata, function(id) {
        if (unit1 === undefined || unit1 === graphdata[id][2]) {
            unit1 = graphdata[id][2];
        } else if (unit2 === undefined || unit2 === graphdata[id][2]) {
            unit2 = graphdata[id][2];
        }
    });
}

function updateColormma(color) {
    $('#colval').css('background-color', '#' + color);
}

function writecolortoarray(color) {
    graphdata[currentoption][3] = '#' + color.color;

    if (mode === 1) {
        drawgraphhistorical();
    }
}

function get_random_color() {
    var letters = '0123456789ABCDEF'.split('');
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.round(Math.random() * 15)];
    }
    return color;
}