/////////////////////////////////////////////////////////////////////////////////////////////
// Java-Script Library for Janitza UMG

LIB_JS_VERSION = "2.0.1" // 3 dots are nescessary by version test code!

UMG604 = true;
UMG510 = false;
UMG507 = false;
UMG508 = false;
UMG511 = false;
UMG605 = false;
UMG604COMP = UMG604 || UMG511 || UMG605 || UMG508
if (!(UMG604 || UMG510 || UMG507 || UMG508 || UMG511 || UMG605))
    alert("Fatal Error: No device definded in lib.js.");
if (UMG604)
    LIB_JS_VERSION += " (UMG604)";
if (UMG510)
    LIB_JS_VERSION += " (UMG510)";
if (UMG507)
    LIB_JS_VERSION += " (UMG507)";
if (UMG508)
    LIB_JS_VERSION += " (UMG508)";
if (UMG511)
    LIB_JS_VERSION += " (UMG511)";
if (UMG605)
    LIB_JS_VERSION += " (UMG605)";
/*Var for phone compatibility*/
var agent = navigator.userAgent.toLowerCase();
is_phone = (agent.indexOf('iphone') != -1);

// Std. Genauigkeit fuers Runden
STD_GENAUIGKEIT = 2;
STD_SIPREFIX = ""; //no
// Example:
// STD_SIPREFIX="k"; // z.B. kilo    

LIBERRORPOPUP_ON = false;
LIBERRORPOPUP_ANIMATION = 0; // Animation time in ms, 0=off
// Display /img/hascontext.gif on hovering tables with CMenu
DISPLAY_TABLE_HAS_CONTEXTMENU_GIF = false;
// LoadAnimation
var LOAD_ANIM_MS = 300
var LOAD_ANIM_WAIT_TICKS = 2 // * LOAD_ANIM_MS = Start delay

var FLAG_WITH = 21; //Width in pixel of one css flag block for IE fix.

AUTOUPDATE_INTERVAL = 1000; // in ms
var MENU_DISPLAY_TIMEOUT = 30000; // in ms

var MENU_ID_EXIT = 99999;

var MENU_IMG_CHECK_YES = "/img/check_yes.png";
var MENU_IMG_CHECK_NO = "/img/check_no.png";
var MENU_IMG_EXIT = "/img/menu_exit.png";
if (UMG510 || UMG507)
{
    MENU_IMG_CHECK_YES = "/check_yes.png";
    MENU_IMG_CHECK_NO = "/check_no.png";
    MENU_IMG_EXIT = "/menu_exit.png";
}


// Interne Konstanten:
UMG_MAX_INT = 2147483648 - 1;
AUTOUPDATE = {
    "type": "autoupdate"
};
SCROLL = {
    "type": "scroll"
};
DISPLAYTIME = {
    "type": "displaytime"
};
HIDEUNIT = {
    "type": "hideunit"
};
function MIN(val) {
    return {"type": "min", "value": val};
}
function MAX(val) {
    return {"type": "max", "value": val};
}
function HOOK(func) {
    return {"type": "hook", "func": func};
}
function createCookie(name, value, days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
    }
    else
        var expires = "";
    document.cookie = name + "=" + value + expires + "; path=/";
}

function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ')
            c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0)
            return c.substring(nameEQ.length, c.length);
    }
    return null;
}

function eraseCookie(name) {
    createCookie(name, "", -1);
}



function getLanguageFromCookie() {
    var lang = readCookie("lang");
    if (!lang)
        return "de";
    return lang;
}
if (UMG510 || UMG507)
    CurrentLanguage = getLanguageFromCookie();


sysvar_loaded = false;

var AlterLanguageDelay = [];

/////////////////////////////////////////////////////////////////////////////////////////////
// OnLoad
function addLoadEvent(func) {
    var oldonload = window.onload;
    if (typeof window.onload != 'function') {
        window.onload = func;
    }
    else {
        window.onload = function() {
            if (oldonload) {
                oldonload();
            }
            func();
        }
    }
}
function kickstart() {
    libonload();
}
//Safari KickStart
if (/WebKit/i.test(navigator.userAgent)) {
    var _WKtimer = setInterval(function() {
        if (/loaded|complete/.test(document.readyState)) {
            clearInterval(_WKtimer);
            kickstart();
        }
    }, 10);
}
//Firefox / Opera9+
if (document.addEventListener) {
    document.addEventListener("DOMContentLoaded", kickstart, false);
}
var RegisterOnloadFunctionArray = new Array();
function RegisterOnloadFunction(func) {
    RegisterOnloadFunctionArray.push(func);
}

var RegisterUnloadFunctionArray = new Array();
function RegisterUnloadFunction(func) {
    RegisterUnloadFunctionArray.push(func);
}
var LibLoaded = false;
function libonload() {
    
    if (LibLoaded)
        return;
    LibLoaded = true;
    
       
    if (!(UMG510 || UMG507))
        CreateMenu();
    
    InitTranslate();
    Translate();
        
    if (UMG510)
        populate510Varlist();

    InitSysvar();
    MarkSelectedMenuItem();

    addEvent(document.body, "click", body_click, true);
    while (RegisterOnloadFunctionArray.length != 0) {
        RegisterOnloadFunctionArray.shift()();

    }

    var _lang = CurrentLanguage;
    if (_lang != "de")
        _lang = "en";
    if (ById("help_correct_lang_link")) {
        if (UMG604COMP)
            ById("help_correct_lang_link").firstChild.href = "/help.cus." + _lang + ".html";
        if (UMG507)
            ById("help_correct_lang_link").firstChild.href = "/help." + _lang + ".html";
    }
    
}

function libonunload() {
    // Release Events:
    RemoveAllEvents();
    while (RegisterUnloadFunctionArray.length != 0)
        RegisterUnloadFunctionArray.shift()();
}

window.onload = libonload;
window.unload = libonunload;


function body_click(e) {
    CloseAllCMenus();
}
////////////////////////////////////////////////////////////////////////////////
//MAIN MENU CREATION FUNCTION
////////////////////////////////////////////////////////////////////////////////
function CreateMenu() {
    // GET NAVIGATION ITEM
    var navcon = $("#navigation");
    
    // LOOP menu.js for menu structure
    for (var i = 0; i < menu.length; i++) {
        var li = createLiFromObj(menu[i].firstElement);
        navcon.append(li);
        var ul = $("<UL/>");
        for (var j = 0; j < menu[i].sub.length; j++) {
            var li2 = createLiFromObj(menu[i].sub[j]);
            ul.append(li2);
        }
        li.append(ul);
    }
}

////////////////////////////////////////////////////////////////////////////////
//CREATE INDIVIDUAL MENU ITEMS
////////////////////////////////////////////////////////////////////////////////
function createLiFromObj(obj) {   
    var li = $("<li/>");
    li.attr("id",obj.id);   
    var a = jQuery("<a/>");
    var img = $("<img/>");    
    // if menu item has image add
    if (typeof(obj.img) !== "undefined") {
        img.attr("src",obj.img);       
        a.append(img);
    }   
    // if menu text is available add 
    if (obj.content !== "") {
        a.append(tl(obj.content));
    }  
    // if link add
    if (typeof(obj.href) !== "undefined") {
        a.attr("href",obj.href);
    }   
    li.append(a);
    return li;
}


/////////////////////////////////////////////////////////////////////////////////////////////
function HexToHSB(s) {
    if (s.charAt(0) == "#") {

        return RGBToHSB(parseInt(s.substr(1, 2), 16), parseInt(s.substr(3, 2), 16), parseInt(s.substr(5, 2), 16));
    }

}
function RGBToHSB(r, g, b)
{

    var rgb = {
        "r": r,
        "g": g,
        "b": b
    }
    var result = {
        "hue": 0,
        "saturation": 0,
        "brightness": 0
    }
    var red = this[0], green = this[1], blue = this[2];
    var max = Math.max(Math.max(rgb.r, rgb.g), rgb.b)
    var min = Math.min(Math.min(rgb.r, rgb.g), rgb.b);
    var delta = max - min;
    result.brightness = max / 255;
    result.saturation = (max != 0) ? delta / max : 0;
    if (result.saturation == 0) {
        result.hue = 0;
    } else {
        var rr = (max - rgb.r) / delta;
        var gr = (max - rgb.g) / delta;
        var br = (max - rgb.b) / delta;
        if (rgb.r == max)
            result.hue = br - gr;
        else if (rgb.g == max)
            result.hue = 2 + rr - br;
        else
            result.hue = 4 + gr - rr;
        result.hue /= 6;
        if (result.hue < 0)
            result.hue++;
    }
    result.hue = Math.round(result.hue * 360)
    result.saturation = Math.round(result.saturation * 100)
    result.brightness = Math.round(result.brightness * 100)
    return result;

    result.hue = h;
    result.saturation = s * 100 / 255;
    result.brightness = Math.round(b * 100 / 255);
    return result;
}
function _HSBtoRGB(hsbobj) {
    var br = Math.round(hsbobj.brightness / 100 * 255);
    if (this[1] == 0) {
        return [br, br, br];
    } else {
        var hue = hsbobj.hue % 360;
        var f = hue % 60;
        var p = Math.round((hsbobj.brightness * (100 - hsbobj.saturation)) / 10000 * 255);
        var q = Math.round((hsbobj.brightness * (6000 - hsbobj.saturation * f)) / 600000 * 255);
        var t = Math.round((hsbobj.brightness * (6000 - hsbobj.saturation * (60 - f))) / 600000 * 255);
        switch (Math.floor(hue / 60)) {
            case 0:
                return [br, t, p];
            case 1:
                return [q, br, p];
            case 2:
                return [p, br, t];
            case 3:
                return [p, q, br];
            case 4:
                return [t, p, br];
            case 5:
                return [br, p, q];
        }
    }
    return false;
}
function HSBtoRGB(hsbobj) {
    var ret = _HSBtoRGB(hsbobj)
    return "#" + decToHex(ret[0]) + "" + decToHex(ret[1]) + decToHex(ret[2])


}
/////////////////////////////////////////////////////////////////////////////////////////////
// Login Script 
function toFloatChallenge(fC) {
    var s = String(fC);
    if (s.indexOf(".") == -1)
        return s + ".000";
    if (s.length - s.indexOf(".") < 4)
        s += "00000";
    return s.substr(0, s.indexOf(".") + 4);
}
function toggleLoginDevDetails() {
    if (ById('devdet').style.display == "block")
        ById('devdet').style.display = "none";
    else
        ById('devdet').style.display = "block";
}
var actAuthAjaxObj = null;
var actAuthRequest = null;
function displayAuthDialog(AjaxObj, request) {
    if (!ById("auth_dialog")) {
        LibError.Add("989: auth_dialog id not found!");
        return;
    }
    actAuthAjaxObj = AjaxObj;
    actAuthRequest = request;

    var ma = AjaxObj.xhttp.responseText.match(/\/\*CH\*\/(.*)\/\*LA\*\//)
    if (ma.length != 2)
        LibError.Debug("834: Couln't find CH LA seq with Challenge login.html.")
    CurrentChallenge = toFloatChallenge(parseFloat(ma[1]))
    ById("auth_dialog").style.display = "block";
    ById("login_pwd").value = ""
    ById("login_pwd").focus();
}
function hideAuthDialog() {
    ById("auth_dialog").style.display = "none";
}
function login() {
    if (isNaN(parseInt(ById("login_pwd").value)))
        return;
    var loginstring = parseInt(ById("login_pwd").value) + CurrentChallenge;

    var ma = actAuthRequest[0].match(/65000=([0-9A-Fa-f]{32})/)
    if (ma) {
        actAuthRequest[0] = actAuthRequest[0].replace(ma[1], hex_md5(loginstring));
    } else
        actAuthRequest[0] += "&65000=" + hex_md5(loginstring)
    //Reinitate AjaxRequest, now with Auth Infos
    actAuthAjaxObj.SentNext();
    //document.location.href="/index.html?65000="+hex_md5(loginstring)
    hideAuthDialog();
}
function abortlogin() {
    hideAuthDialog();
    actAuthAjaxObj.queue.shift();
    actAuthAjaxObj.bWaiting = false;
    if (actAuthAjaxObj.queue.length > 0) {
        actAuthAjaxObj.SentNext();
    }


}
RegisterOnloadFunction(function() {
    if (ById("login_pwd"))
        ById("login_pwd").onkeypress = pwd_keyup;
})

function pwd_keyup(e)
{
    keyID = ((window.event) ? event.keyCode : e.keyCode)
    if (keyID == 27)
        abortlogin()
    if (keyID == 13)
        login()
}
/*
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Version 2.1 Copyright (C) Paul Johnston 1999 - 2002.
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for more info.
 */

/*
 * Configurable variables. You may need to tweak these to be compatible with
 * the server-side, but the defaults work in most cases.
 */
var hexcase = 1;  /* hex output format. 0 - lowercase; 1 - uppercase        */
var b64pad = ""; /* base-64 pad character. "=" for strict RFC compliance   */
var chrsz = 8;  /* bits per input character. 8 - ASCII; 16 - Unicode      */

/*
 * These are the functions you'll usually want to call
 * They take string arguments and return either hex or base-64 encoded strings
 */
function hex_md5(s) {
    return binl2hex(core_md5(str2binl(s), s.length * chrsz));
}
function b64_md5(s) {
    return binl2b64(core_md5(str2binl(s), s.length * chrsz));
}
function str_md5(s) {
    return binl2str(core_md5(str2binl(s), s.length * chrsz));
}
function hex_hmac_md5(key, data) {
    return binl2hex(core_hmac_md5(key, data));
}
function b64_hmac_md5(key, data) {
    return binl2b64(core_hmac_md5(key, data));
}
function str_hmac_md5(key, data) {
    return binl2str(core_hmac_md5(key, data));
}

/*
 * Perform a simple self-test to see if the VM is working
 */
function md5_vm_test()
{
    return hex_md5("abc") == "900150983cd24fb0d6963f7d28e17f72";
}

/*
 * Calculate the MD5 of an array of little-endian words, and a bit length
 */
function core_md5(x, len)
{
    /* append padding */
    x[len >> 5] |= 0x80 << ((len) % 32);
    x[(((len + 64) >>> 9) << 4) + 14] = len;

    var a = 1732584193;
    var b = -271733879;
    var c = -1732584194;
    var d = 271733878;

    for (var i = 0; i < x.length; i += 16)
    {
        var olda = a;
        var oldb = b;
        var oldc = c;
        var oldd = d;

        a = md5_ff(a, b, c, d, x[i + 0], 7, -680876936);
        d = md5_ff(d, a, b, c, x[i + 1], 12, -389564586);
        c = md5_ff(c, d, a, b, x[i + 2], 17, 606105819);
        b = md5_ff(b, c, d, a, x[i + 3], 22, -1044525330);
        a = md5_ff(a, b, c, d, x[i + 4], 7, -176418897);
        d = md5_ff(d, a, b, c, x[i + 5], 12, 1200080426);
        c = md5_ff(c, d, a, b, x[i + 6], 17, -1473231341);
        b = md5_ff(b, c, d, a, x[i + 7], 22, -45705983);
        a = md5_ff(a, b, c, d, x[i + 8], 7, 1770035416);
        d = md5_ff(d, a, b, c, x[i + 9], 12, -1958414417);
        c = md5_ff(c, d, a, b, x[i + 10], 17, -42063);
        b = md5_ff(b, c, d, a, x[i + 11], 22, -1990404162);
        a = md5_ff(a, b, c, d, x[i + 12], 7, 1804603682);
        d = md5_ff(d, a, b, c, x[i + 13], 12, -40341101);
        c = md5_ff(c, d, a, b, x[i + 14], 17, -1502002290);
        b = md5_ff(b, c, d, a, x[i + 15], 22, 1236535329);

        a = md5_gg(a, b, c, d, x[i + 1], 5, -165796510);
        d = md5_gg(d, a, b, c, x[i + 6], 9, -1069501632);
        c = md5_gg(c, d, a, b, x[i + 11], 14, 643717713);
        b = md5_gg(b, c, d, a, x[i + 0], 20, -373897302);
        a = md5_gg(a, b, c, d, x[i + 5], 5, -701558691);
        d = md5_gg(d, a, b, c, x[i + 10], 9, 38016083);
        c = md5_gg(c, d, a, b, x[i + 15], 14, -660478335);
        b = md5_gg(b, c, d, a, x[i + 4], 20, -405537848);
        a = md5_gg(a, b, c, d, x[i + 9], 5, 568446438);
        d = md5_gg(d, a, b, c, x[i + 14], 9, -1019803690);
        c = md5_gg(c, d, a, b, x[i + 3], 14, -187363961);
        b = md5_gg(b, c, d, a, x[i + 8], 20, 1163531501);
        a = md5_gg(a, b, c, d, x[i + 13], 5, -1444681467);
        d = md5_gg(d, a, b, c, x[i + 2], 9, -51403784);
        c = md5_gg(c, d, a, b, x[i + 7], 14, 1735328473);
        b = md5_gg(b, c, d, a, x[i + 12], 20, -1926607734);

        a = md5_hh(a, b, c, d, x[i + 5], 4, -378558);
        d = md5_hh(d, a, b, c, x[i + 8], 11, -2022574463);
        c = md5_hh(c, d, a, b, x[i + 11], 16, 1839030562);
        b = md5_hh(b, c, d, a, x[i + 14], 23, -35309556);
        a = md5_hh(a, b, c, d, x[i + 1], 4, -1530992060);
        d = md5_hh(d, a, b, c, x[i + 4], 11, 1272893353);
        c = md5_hh(c, d, a, b, x[i + 7], 16, -155497632);
        b = md5_hh(b, c, d, a, x[i + 10], 23, -1094730640);
        a = md5_hh(a, b, c, d, x[i + 13], 4, 681279174);
        d = md5_hh(d, a, b, c, x[i + 0], 11, -358537222);
        c = md5_hh(c, d, a, b, x[i + 3], 16, -722521979);
        b = md5_hh(b, c, d, a, x[i + 6], 23, 76029189);
        a = md5_hh(a, b, c, d, x[i + 9], 4, -640364487);
        d = md5_hh(d, a, b, c, x[i + 12], 11, -421815835);
        c = md5_hh(c, d, a, b, x[i + 15], 16, 530742520);
        b = md5_hh(b, c, d, a, x[i + 2], 23, -995338651);

        a = md5_ii(a, b, c, d, x[i + 0], 6, -198630844);
        d = md5_ii(d, a, b, c, x[i + 7], 10, 1126891415);
        c = md5_ii(c, d, a, b, x[i + 14], 15, -1416354905);
        b = md5_ii(b, c, d, a, x[i + 5], 21, -57434055);
        a = md5_ii(a, b, c, d, x[i + 12], 6, 1700485571);
        d = md5_ii(d, a, b, c, x[i + 3], 10, -1894986606);
        c = md5_ii(c, d, a, b, x[i + 10], 15, -1051523);
        b = md5_ii(b, c, d, a, x[i + 1], 21, -2054922799);
        a = md5_ii(a, b, c, d, x[i + 8], 6, 1873313359);
        d = md5_ii(d, a, b, c, x[i + 15], 10, -30611744);
        c = md5_ii(c, d, a, b, x[i + 6], 15, -1560198380);
        b = md5_ii(b, c, d, a, x[i + 13], 21, 1309151649);
        a = md5_ii(a, b, c, d, x[i + 4], 6, -145523070);
        d = md5_ii(d, a, b, c, x[i + 11], 10, -1120210379);
        c = md5_ii(c, d, a, b, x[i + 2], 15, 718787259);
        b = md5_ii(b, c, d, a, x[i + 9], 21, -343485551);

        a = safe_add(a, olda);
        b = safe_add(b, oldb);
        c = safe_add(c, oldc);
        d = safe_add(d, oldd);
    }
    return Array(a, b, c, d);

}

/*
 * These functions implement the four basic operations the algorithm uses.
 */
function md5_cmn(q, a, b, x, s, t)
{
    return safe_add(bit_rol(safe_add(safe_add(a, q), safe_add(x, t)), s), b);
}
function md5_ff(a, b, c, d, x, s, t)
{
    return md5_cmn((b & c) | ((~b) & d), a, b, x, s, t);
}
function md5_gg(a, b, c, d, x, s, t)
{
    return md5_cmn((b & d) | (c & (~d)), a, b, x, s, t);
}
function md5_hh(a, b, c, d, x, s, t)
{
    return md5_cmn(b ^ c ^ d, a, b, x, s, t);
}
function md5_ii(a, b, c, d, x, s, t)
{
    return md5_cmn(c ^ (b | (~d)), a, b, x, s, t);
}

/*
 * Calculate the HMAC-MD5, of a key and some data
 */
function core_hmac_md5(key, data)
{
    var bkey = str2binl(key);
    if (bkey.length > 16)
        bkey = core_md5(bkey, key.length * chrsz);

    var ipad = Array(16), opad = Array(16);
    for (var i = 0; i < 16; i++)
    {
        ipad[i] = bkey[i] ^ 0x36363636;
        opad[i] = bkey[i] ^ 0x5C5C5C5C;
    }

    var hash = core_md5(ipad.concat(str2binl(data)), 512 + data.length * chrsz);
    return core_md5(opad.concat(hash), 512 + 128);
}

/*
 * Add integers, wrapping at 2^32. This uses 16-bit operations internally
 * to work around bugs in some JS interpreters.
 */
function safe_add(x, y)
{
    var lsw = (x & 0xFFFF) + (y & 0xFFFF);
    var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
    return (msw << 16) | (lsw & 0xFFFF);
}

/*
 * Bitwise rotate a 32-bit number to the left.
 */
function bit_rol(num, cnt)
{
    return (num << cnt) | (num >>> (32 - cnt));
}

/*
 * Convert a string to an array of little-endian words
 * If chrsz is ASCII, characters >255 have their hi-byte silently ignored.
 */
function str2binl(str)
{
    var bin = Array();
    var mask = (1 << chrsz) - 1;
    for (var i = 0; i < str.length * chrsz; i += chrsz)
        bin[i >> 5] |= (str.charCodeAt(i / chrsz) & mask) << (i % 32);
    return bin;
}

/*
 * Convert an array of little-endian words to a string
 */
function binl2str(bin)
{
    var str = "";
    var mask = (1 << chrsz) - 1;
    for (var i = 0; i < bin.length * 32; i += chrsz)
        str += String.fromCharCode((bin[i >> 5] >>> (i % 32)) & mask);
    return str;
}

/*
 * Convert an array of little-endian words to a hex string.
 */
function binl2hex(binarray)
{
    var hex_tab = hexcase ? "0123456789ABCDEF" : "0123456789abcdef";
    var str = "";
    for (var i = 0; i < binarray.length * 4; i++)
    {
        str += hex_tab.charAt((binarray[i >> 2] >> ((i % 4) * 8 + 4)) & 0xF) +
                hex_tab.charAt((binarray[i >> 2] >> ((i % 4) * 8)) & 0xF);
    }
    return str;
}

/*
 * Convert an array of little-endian words to a base-64 string
 */
function binl2b64(binarray)
{
    var tab = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    var str = "";
    for (var i = 0; i < binarray.length * 4; i += 3)
    {
        var triplet = (((binarray[i >> 2] >> 8 * (i % 4)) & 0xFF) << 16)
                | (((binarray[i + 1 >> 2] >> 8 * ((i + 1) % 4)) & 0xFF) << 8)
                | ((binarray[i + 2 >> 2] >> 8 * ((i + 2) % 4)) & 0xFF);
        for (var j = 0; j < 4; j++)
        {
            if (i * 8 + j * 6 > binarray.length * 32)
                str += b64pad;
            else
                str += tab.charAt((triplet >> 6 * (3 - j)) & 0x3F);
        }
    }
    return str;
}
/*
 END of
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 **/
/////////////////////////////////////////////////////////////////////////////////////////////
// Menu
// Example:
// function callbackhandler(item){
// if(item.id==1)foo();
// }
// var myContextMenu = new CMenu(callbackhandler);
// myContextMenu.AddButton(1/*ID*/, "Autoupdate", "/img/autoupdate.gif");
// myContextMenu.AddSeperator();
// myContextMenu.AddCheckbox(2/*ID*/, "Ja/Nein", "/img/autoupdate.gif");
// myContextMenu.AddButton(3/*ID*/, "Autoupdate", "/img/autoupdate.gif");
// On Event, z.b. Click::
// myContextMenu.popup(x,y);
function CMenuItem() {
    this.Visible = true;
    return this;
}

var CMenuList = [];

function CMenu(callbackfunc) {
    if (typeof(callbackfunc) != "function")
        LibError.Debug("CMenu Constructor needs callback function");
    this.type = "CMenu";
    this.id = createid(10);
    this.Items = [];
    this.el = null;
    this.callback = callbackfunc;
    this.suppressExitItem = false; // Show Exit Item
    CMenuList.push(this);
}
;
CMenu.prototype.AddButton = function(id, name, img) {
    var item = new CMenuItem();
    item.parent = this;
    item.id = id;
    item.name = name;
    item.image = img;
    this.Items.push(item);
}
/**
 *
 * @param {int} id
 * @param {String} name
 * @param {bool} checked
 * @param {Array} optimgs
 */
CMenu.prototype.AddCheck = function(id, name, checked, optimgs) {
    var item = new CMenuItem();
    item.parent = this;
    item.id = id;
    item.name = name;
    if (optimgs && typeof(optimgs) == "object")
        item.image = optimgs;
    else
        item.image = [MENU_IMG_CHECK_YES, MENU_IMG_CHECK_NO];
    if (!checked)
        checked = false;
    item.checked = checked;
    this.Items.push(item);
}
CMenu.prototype.AddSeperator = function() {
    var item = new CMenuItem();
    item.parent = this;
    item.type = "seperator";
    this.Items.push(item);
}
CMenu.prototype.DeleteById = function(id) {
    for (var it in this.Items) {
        if (it in Array.prototype)
            continue;
        if (this.Items[it].id == id)
            delete this.Items[it];
    }

}
CMenu.prototype.close = function() {
    clearTimeout(this.timeout);
    delete this.timeout;
    if (typeof(this.el) != "undefined" && this.el != null) {
        this.el.parentNode.removeChild(this.el);
        this.el = null;
    }

}
function CMenu_close(id) {

    for (var i in CMenuList) {
        if (i in Array.prototype)
            continue;
        if (CMenuList[i].id == id) {
            CMenuList[i].close();
            if (CMenuList[i].onCancel)
                CMenuList[i].onCancel();
        }

    }
}

function CloseAllCMenus() {
    for (var i in CMenuList) {
        if (i in Array.prototype)
            continue;
        CMenuList[i].close();
    }
}

function CMenu_clicked(evt) {
    evt = (evt) ? evt : ((window.event) ? window.event : "");
    var elem = (evt.target) ? evt.target : evt.srcElement;
    evt.cancelBubble = true;
    var watchdog = 10;
    while (elem.tagName != "A") {
        elem = elem.parentNode;
        if (watchdog-- == 0)
            break;
    }

    var ar = elem.id.split("|");
    var id = ar[0];
    if (id == MENU_ID_EXIT) {
        CloseAllCMenus();
        return;
    }
    for (var i in CMenuList) {
        if (i in Array.prototype)
            continue;
        if (CMenuList[i].id == id)
            CMenuList[i].clicked(ar[1]);
    }
}

CMenu.prototype.GetItemById = function(id) {
    for (var i in this.Items) {
        if (i in Array.prototype)
            continue;
        if (this.Items[i].id == id)
            return this.Items[i];
    }
    return null;
}
function attach_button_hover_style(evt) {
    evt = (evt) ? evt : ((window.event) ? window.event : "");
    var elem = (evt.target) ? evt.target : evt.srcElement;
    if (elem.tagName != "A")
        return;
    addStyleClass(elem, "popupclass_button_IE_JS_FIX_hover");
    addStyleClass(elem.firstChild, "popupclass_button_IE_JS_FIX_a_hover_img");

}

function detach_button_hover_style(evt) {
    evt = (evt) ? evt : ((window.event) ? window.event : "");
    var elem = (evt.target) ? evt.target : evt.srcElement;
    if (elem.tagName != "A")
        return;
    removeStyleClass(elem, "popupclass_button_IE_JS_FIX_hover");
    removeStyleClass(elem.firstChild, ".popupclass_button_IE_JS_FIX_a_hover_img");


}

//TODO: Stop/Resume Timout on mouseover/out
CMenu.prototype.popup = function(x, y) {
    CloseAllCMenus();
    this.timeout = setTimeout("CMenu_close('" + this.id + "')", MENU_DISPLAY_TIMEOUT);
    this.el = document.createElement("div");
    this.el.className = "popupclass";
    this.el.style.border = "2px solid #CCCCCC";
    this.el.id = this.id;
    if (!this.suppressExitItem) {
        //Tmp. add Exit button
        this.AddSeperator();
        this.AddButton(MENU_ID_EXIT, tl("cmenu.exit"), MENU_IMG_EXIT);
    }
    for (var i in this.Items) {
        if (i in Array.prototype)
            continue;
        var item = this.Items[i];
        if (!item.Visible)
            return;
        var elem = document.createElement("div");
        elem.className = "button";
        if (item.type == "seperator") {
            var hr = document.createElement("div");
            hr.style.borderTop = "1px solid #9D9DA1";
            hr.style.borderBottom = "1px solid #E0DFE3";
            elem.style.height = "2px";
            elem.style.margin = "2px";
            elem.style.padding = "2px";
            elem.appendChild(hr);
            this.el.appendChild(elem);
            continue;
        }
        var aelem = document.createElement("a");

        var img;
        if (typeof(item.image) != "undefined") {
            img = document.createElement("img");

            if (typeof(item.image) == "object")
                img.src = item.image[(item.checked) ? 0 : 1];
            else
                img.src = item.image;
            img.width = "16";
            img.height = "16";
            img.style.marginRight = "5px";
        }
        else {
            img = document.createElement("span");
            img.style.marginRight = "16px";
            img.style.Height = "16px";
            //			img.style.display = "block";			
            img.innerHTML = "&nbsp;";
        }
        var content = null
        if (typeof(item.name) == "object")
            content = document.createTextNode(item.name[(item.checked) ? 0 : 1]);
        else
            content = document.createTextNode(item.name);
        aelem.appendChild(img);
        aelem.appendChild(content);
        aelem.id = this.id + "|" + item.id;
        addEvent(aelem, 'click', CMenu_clicked, false);
        addEvent(aelem, 'mouseover', attach_button_hover_style, false);
        addEvent(aelem, 'mouseout', detach_button_hover_style, false);

        elem.appendChild(aelem);
        this.el.appendChild(elem);
    }
    if (!this.suppressExitItem) {
        //remove tmp. Exit button
        this.Items.pop();
        this.Items.pop();
    }
    this.el.style.left = x + "px";
    this.el.style.top = y + "px";
    document.body.appendChild(this.el);

}
CMenu.prototype.clicked = function(objid) {
    var close = true;
    for (var i in this.Items) {
        if (i in Array.prototype)
            continue;
        var item = this.Items[i];
        if (item.id == objid) {
            if (typeof(item.checked) != "undefined")
                item.checked = !item.checked;
            close = this.callback(item);
            if (typeof(close) == "undefined")
                close = true;
        }

    }
    if (close != false)
        this.close();

}

/////////////////////////////////////////////////////////////////////////////////////////////
// Ajax
// Using:
// AjaxRequestProvider = new CAjaxRequestProvider();
// AjaxRequestProvider.RegisterRequest("/json.do?_dev_desc", jcallback,"callbackParam");
// AjaxRequestProvider.RegisterRequest("/json.do?_dev_name", jcallbackXY,"callbackParam2");


var CAjaxRequestProviderList = [];
function CAjaxRequestProvider() {
    this.xhttp = false;
    this.queue = [];
    this.id = createid(10);
    this.bWaiting = false;
    this._LibErrorHandler = null;
    this.Active = true;
    CAjaxRequestProviderList.push(this);
}


CAjaxRequestProvider.prototype.EnsureInitState = function() {

    if (window.ActiveXObject) {
        try {
            //Internet Explorer 6.x
            this.xhttp = new ActiveXObject("Msxml2.XMLHTTP");
        }
        catch (e) {
            //IE 5.x
            try {
                this.xhttp = new ActiveXObject("Microsoft.XMLHTTP");
            }
            catch (e) {
                this.xhttp = false;
            }
        }
    }
    else
    if (window.XMLHttpRequest) {
        // F?r Mozilla, Opera und Safari
        try {
            this.xhttp = new XMLHttpRequest();
        }
        catch (e) {
            this.xhttp = false;
        }
    }
    this.xhttp.onreadystatechange = CAjaxRequestProviderAjaxCallback;
}

CAjaxRequestProvider.prototype.SentNext = function() {
    if (!this.Active)
        return;
    this.bWaiting = true;
    delete this.xhttp;
    this.xhttp = null;
    this.EnsureInitState();
    // asynchronen GET Request vorbereiten und abschicken 
    if (this.queue[0][3] == "XML") {

        if (this.xhttp.overrideMimeType) {
            // this.xhttp.overrideMimeType('text/xml');
        }
    }
    if (this.queue[0][0].length >= 2048)
        LibError.Add("URL in AjaxRequest to long for IE.");

    this.xhttp.open(this.queue[0][4], this.queue[0][0], true);

    if (typeof(this.queue[0][5]) == "undefined")
        this.xhttp.send("");
    else {
        this.xhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        this.xhttp.setRequestHeader("Content-length", this.queue[0][5].length);
        this.xhttp.setRequestHeader('Connection', 'close');
        this.xhttp.send(this.queue[0][5]);

    }

}
CAjaxRequestProvider.prototype.ErrorHandler = function(er) {
    this._LibErrorHandler = er;
}
function dump(obj) {
    var s = "Obj Dump:";
    for (var propName in obj) {
        s += "<br>" + propName + "=" + obj[propName];
    }
    LibError.Add(s);

}
CAjaxRequestProvider.prototype.ValidResponseCode = function(code) {
    switch (code) {
        case 200:
        case 0://Safari	
            //IE Bug Return, but transfer is OK
        case 12029:
        case 12030:
        case 12031:
        case 12152:
        case 12159:
            return true;
        default:
            return false;

    }
}
CAjaxRequestProvider.prototype.ReadyHandler = function() {
    if (!this.Active)
        return;
//test on Auth req
    // This reg is only len:2 if login.html ~ responseText
    if (this.xhttp.status == 200) {
        var ma = this.xhttp.responseText.match(/\/\*CH\*\/(.*)\/\*LA\*\//)
        if (ma && ma.length == 2) {
            displayAuthDialog(this, this.queue[0]);
            this.xhttp.abort();
            return;
        }
    }
    //Safari Bug: Code = 0
    if (this.ValidResponseCode(this.xhttp.status) && this.queue[0][1]) {

        if (this.queue[0][3] == "XML") {
            if (window.ActiveXObject) {
                var doc = new ActiveXObject("MSXML2.DOMDocument");
                doc.loadXML(this.xhttp.responseText);

                this.queue[0][1](this.xhttp.responseXML, this.queue[0][2], true);
            }
            else
                this.queue[0][1](this.xhttp.responseXML, this.queue[0][2], false);
        }
        else
            this.queue[0][1](this.xhttp.responseText, this.queue[0][2]);
    }
    this.queue.shift();
    this.xhttp.abort();

    this.bWaiting = false;
    if (this.queue.length > 0) {
        this.SentNext();
    }

}
function CAjaxRequestProviderAjaxCallback() {

    if (typeof(CAjaxRequestProviderList) == "undefined")
        return;
    for (var i = 0; i < CAjaxRequestProviderList.length; i++) {

        if (typeof(CAjaxRequestProviderList[i].xhttp) == "object" && CAjaxRequestProviderList[i].xhttp.readyState == 4) {
            //	try{


            if (!CAjaxRequestProviderList[i].ValidResponseCode(CAjaxRequestProviderList[i].xhttp.status)) {
                if (CAjaxRequestProviderList[i]._LibErrorHandler != null && CAjaxRequestProviderList[i]._LibErrorHandler(CAjaxRequestProviderList[i].xhttp))
                {

                }
                else {
                    LibError.Add("HTTP Ajax LibError, Request:" + CAjaxRequestProviderList[i].queue[0][0] + " Code:" + CAjaxRequestProviderList[i].xhttp.status);
                }

            }
            CAjaxRequestProviderList[i].ReadyHandler();

            //}catch(e){ LibError.Add("HTTP Ajax Exception, Request:"+CAjaxRequestProviderList[i].queue[0][0]);}
        }
    }

}

/**
 * Register an async. HTTP-Request.
 * The function "callback" will be called when data is ready.
 * @param {String} url
 * @param {function} callback
 * @param {Object} CallBackParam
 */
CAjaxRequestProvider.prototype.RegisterRequest = function(url, callback, CallBackParam) {
    // Add to queue
    if (!(UMG510 || UMG507)) { //510 can't uncache using paramter ?time, "file.html?" => ERROR 404
        if (url.substr(0, 7) == "json.do" || url.substr(0, 8) == "/json.do")
            url = uncachejson(url);
        else
            url = uncache(url);
    }
    this.queue.push(new Array(url, callback, CallBackParam, null, "GET"));
    // Any other Requests running:
    if (this.bWaiting == false) {
        // no, then request:
        this.SentNext();
    }
}
CAjaxRequestProvider.prototype.RegisterRequestXML = function(url, callback, CallBackParam) {
    // Add to queue
    if (url.substr(0, 7) == "json.do" || url.substr(0, 8) == "/json.do")
        url = uncachejson(url);
    else
        url = uncache(url);
    this.queue.push(new Array(url, callback, CallBackParam, "XML", "GET"));
    // Any other Requests running:
    if (this.bWaiting == false) {
        // no, then request:
        this.SentNext();
    }
}
CAjaxRequestProvider.prototype.RegisterPostRequest = function(url, text, callback, CallBackParam) {
    // Add to queue
    if (url.substr(0, 7) == "json.do" || url.substr(0, 8) == "/json.do")
        url = uncachejson(url);
    else
        url = uncache(url);
    this.queue.push(new Array(url, callback, CallBackParam, null, "POST", text));
    // Any other Requests running:
    if (this.bWaiting == false) {
        // no, then request:
        this.SentNext();
    }
}
function CancelAllAjaxRequests() {
    if (typeof(CAjaxRequestProviderList) == "undefined")
        return;
    for (var i = 0; i < CAjaxRequestProviderList.length; i++) {
        CAjaxRequestProviderList[i].Active = false;
        if (typeof(CAjaxRequestProviderList[i].xhttp) == "object")
            CAjaxRequestProviderList[i].xhttp.abort();
        CAjaxRequestProviderList[i].queue = [];
    }
}
RegisterUnloadFunction(CancelAllAjaxRequests)
/////////////////////////////////////////////////////////////////////////////////////////////////////
var TERROR = 1;
var TWARNING = 2;
var TINFO = 3;
var TDEBUG = 4;
function CLibError() {
    this.list = [];
    this.d = new Date();
    this.Initiated = false;
    this.Info("Document:" + document.location.href);
    this.Info("Browser:" + navigator.userAgent);
    this.Info("Time:" + this.d.toLocaleString());

}

CLibError.prototype._Add = function(_type, s) {
    var obj = new Object();
    obj.type = _type;
    obj.meldung = s;
    var d = new Date();
    obj.TimeOffset = d - this.d;
    this.list.push(obj);
    if (this.Initiated) {
        var el = document.getElementById("errorpopup_count");
        el.innerHTML = "Es traten " + this.Count() + " Fehler auf.";
        this._AddListElement(obj);
    }
    this.Show();
}
CLibError.prototype.Show = function() {
    //Animation:
    if (this.Initiated && LIBERRORPOPUP_ANIMATION != 0 && typeof(this.ani) == "undefined") {
        this.main.style.display = "block";
        this.ani = new Object();
        this.ani.start = -50;
        this.ani.end = 5;
        this.ani.steps = 100;
        this.ani.Time = LIBERRORPOPUP_ANIMATION;
        this.ani.currentStep = 0;
        this.ani.currentPos = this.ani.start;
        this.ani.AddPerStep = (/*delta*/this.ani.end - this.ani.start) / this.ani.steps;
        this.ani.TimePerStep = parseInt(this.ani.Time / this.ani.steps);
        this.ani.timer = setInterval("LibErrorpopupani()", this.ani.TimePerStep);
        this.main.style.top = parseInt(this.ani.currentPos) + "px";
    }

}
CLibError.prototype.Info = function(s) {
    this._Add(TINFO, s);
}
CLibError.prototype.Add = function(s) {
    this._Add(TERROR, s);
}
CLibError.prototype.Warning = function(s) {
    this._Add(TWARNING, s);
}
CLibError.prototype.Debug = function(s) {
    this._Add(TDEBUG, s);
}
CLibError.prototype.Count = function() {
    return this.list.length - 3;//3 von Info
}
CLibError.prototype.toString = function() {
    var s = "";
    for (var i in this.list) {
        if (i in Array.prototype)
            continue;
        var obj = this.list[i];
        s += "\n+" + obj.TimeOffset + "ms : ";
        if (obj.type == TERROR)
            s += "Fehler:";
        if (obj.type == TWARNING)
            s += "Warnung:";
        s += obj.meldung;
    }
    return s;
}
CLibError.prototype._AddListElement = function(obj) {
    var mdiv = document.createElement("div");
    var s = "";
    mdiv.className = "item";
    s += "+" + obj.TimeOffset + "ms : ";
    if (obj.type == TERROR) {
        s += "Fehler:";
        mdiv.style.background = "#ff9966";
    }
    if (obj.type == TWARNING) {
        s += "Warnung:";
        mdiv.style.background = "#ffff99";
    }
    if (obj.type == TINFO) {
        mdiv.style.background = "#C7FFB9";
    }
    if (obj.type == TDEBUG) {
        mdiv.style.background = "#D9C4C4";
    }
    s += obj.meldung;
    mdiv.innerHTML = s;
    this.body.appendChild(mdiv);
}
CLibError.prototype.CloseHTML = function() {
    //this.main.parentNode.removeChild(this.main);	
    this.main.style.display = "none";
}
CLibError.prototype.Init = function(parent) {

    var main = document.createElement("div");
    this.main = main;
    main.className = "errorpopup";
    var header = document.createElement("div");
    var info = document.createElement("span");
    info.innerHTML = "Es traten " + this.Count() + " Fehler auf.";
    info.id = "errorpopup_count";
    var einblenden = document.createElement("button");
    einblenden.innerHTML = "Anzeigen";
    einblenden.id = "showhide";
    var ausblenden = document.createElement("button");
    ausblenden.innerHTML = "Ausblenden";
    ausblenden.id = "close";
    header.appendChild(info);
    header.appendChild(einblenden);
    header.appendChild(ausblenden);
    main.appendChild(header);
    if (!parent)
        parent = document.getElementsByTagName("body")[0];

    var body = document.createElement("div");
    this.body = body;
    body.className = "list";
    body.id = "errorpopupbody";

    for (var i in this.list) {
        if (i in Array.prototype)
            continue;
        this._AddListElement(this.list[i]);
    }
    main.appendChild(body);
    if (typeof(parent) != "undefined")
        parent.appendChild(main);
    buttonlist = main.getElementsByTagName("button");
    addEvent(buttonlist[0], 'click', LibErrorpopup_toggle, false);
    addEvent(buttonlist[1], 'click', LibErrorpopup_close, false);
    this.Initiated = true;
}

function LibErrorpopupani() {
    if (LibError.ani.currentStep++ == LibError.ani.steps) {
        clearInterval(LibError.ani.timer);
    }
    LibError.ani.currentPos += LibError.ani.AddPerStep
    LibError.main.style.top = parseInt(LibError.ani.currentPos) + "px";
}

function LibErrorpopup_toggle() {
    var obj = document.getElementById("errorpopupbody");
    if (!obj.style.display || obj.style.display == "none")
        obj.style.display = "block";
    else
        obj.style.display = "none";
}

function LibErrorinit() {
    LibError.Init();
}

function LibErrorpopup_close() {
    LibError.CloseHTML();
}

function checkforLibErrors() {
    if (LibError.Count() != 0)
        LibError.Show();
}

AjaxRequestProvider = new CAjaxRequestProvider();
LibError = new CLibError();
RegisterOnloadFunction(function() {
    LibError.Init();
});
setTimeout("checkforLibErrors()", 3000);
/////////////////////////////////////////////////////////////////////////////////////////////////////
////////
SIPrefixLong = {
    "yotta": 0,
    "zetta": 1,
    "exa": 2,
    "peta": 3,
    "tera": 4,
    "giga": 5,
    "mega": 6,
    "kilo": 7,
    "hecto": 8,
    "deca": 9,
    "deci": 10,
    "centi": 11,
    "milli": 12,
    "micro": 13,
    "nano": 14,
    "pico": 15
            /*
             "femto":16,
             "atto":17,
             "zepto":18,
             "yocto":19*/
};
SIPrefixShort = {
    "Y": 0,
    "Z": 1,
    "E": 2,
    "P": 3,
    "T": 4,
    "G": 5,
    "M": 6,
    "k": 7,
    "h": 8,
    "da": 9,
    "d": 10,
    "c": 11,
    "m": 12,
    "u": 13,
    "n": 14,
    "p": 15
            /*
             "f":16,
             "a":17,
             "z":18,
             "y":19*/
};
SIPrefixExp = new Array(24, 21, 18, 15, 12, 9, 6, 3, 2, 1, -1, -2, -3, -6, -9, -12/*
 -15,
 -18,      JavaScript: Nur 14 Nachkommastellen
 -21,
 -24*/
        );
function GetSIPrefixExponend(siPrefix) {
    if (typeof(SIPrefixShort[siPrefix]) == "number")
        return SIPrefixExp[SIPrefixShort[siPrefix]];
    if (typeof(SIPrefixLong[siPrefix.toLowerCase()]) == "number")
        return SIPrefixExp[SIPrefixLong[siPrefix]];
    return 0;
}

var sysvartable = new Object();
var aktGenauigkeit = STD_GENAUIGKEIT;
var aktSiPrefix = STD_SIPREFIX;
var _lastSiPrefix = "";

/*sysvar("_ULN[0]")
 sysvar("_ULN[0]", 2)
 sysvar("_ULN[0]", 2, AUTOUPDATE)
 sysvar("_ULN[0]", 2, SCROLL)
 sysvar("_ULN[0]", 2, ["n"])
 sysvar("_ULN[0]", 2, ["kilo"])
 sysvar("_ULN[0]", 2, ["kilo"],AUTOUPDATE,HIDEUNIT)
 */
// Sysvar Einstellungen:
function SysvarStellenReset() {
    aktGenauigkeit = STD_GENAUIGKEIT;
}

function SysvarStellen(i) {
    if (typeof(i) == "undefined")
        return SysvarStellenReset();
    if (i > 4)
        i = 4; // Mehr kommt nicht vom System
    aktGenauigkeit = i;
}

function SysvarLastSiPrefix() {
    aktSiPrefix = _lastSiPrefix;
}

function SysvarSiPrefix(v) {
    if (typeof(v) == "undefined") {
        v = STD_SIPREFIX;
    }
    _lastSiPrefix = aktSiPrefix;
    if (typeof(v) == "object")
        aktSiPrefix = v[0];
    else
        aktSiPrefix = v;
}

function sysvarFromElement(el) {
    var id = createid(14);
    el.id = id;
    sysvartable[id] = new _Sysvar();
    var tmp = sysvarsplit(el.getAttribute('name'));
    sysvartable[id].varname = tmp.varname;
    sysvartable[id].array = tmp.array;
    sysvartable[id].org = el.getAttribute('name');
    if (el.getAttribute("stellen"))
        sysvartable[id].genauigkeit = parseInt(el.getAttribute("stellen"));
    else
        sysvartable[id].genauigkeit = aktGenauigkeit;

    sysvartable[id].Exponent = GetSIPrefixExponend(aktSiPrefix);
    sysvartable[id].siPrefix = aktSiPrefix;
    if (el.getAttribute("si")) {
        var si = el.getAttribute("si");
        if (si.trim().charAt(0) == "[") {
            si = si.substring(1, si.lastIndexOf("]"));
        }
        sysvartable[id].Exponent = GetSIPrefixExponend(si);
        sysvartable[id].siPrefix = (sysvartable[id].Exponent != 1) ? si : ""; // Nur wenn wirklich genutzt
    }




}

function _Sysvar() {
    this.DisplayTime = false;
    this.Time = 0;
    return this;
}

_Sysvar.prototype.getURL = function() {
    if (this.DisplayTime)
        if (UMG507)
            return [this.org, this.varname + "_t" + this.arrayString()];
        else
            return [this.org, this.varname + "_T" + this.arrayString()];
    return this.org;
}
_Sysvar.prototype.arrayString = function() {
    if (this.array)
        return this.array.str;
    return "";
}
function sysvar(name, Params) {
    var id = createid(14);
    var tmp = sysvarsplit(name);
    sysvartable[id] = new _Sysvar();
    sysvartable[id].varname = tmp.varname;
    sysvartable[id].array = tmp.array;
    sysvartable[id].org = name;
    sysvartable[id].genauigkeit = aktGenauigkeit;
    sysvartable[id].Exponent = GetSIPrefixExponend(aktSiPrefix);
    sysvartable[id].siPrefix = aktSiPrefix;
    var className = "sysvar";
    for (var i = 1; i < sysvar.arguments.length; i++) {
        var param = sysvar.arguments[i];
        if (typeof(param) == "number")
            sysvartable[id].genauigkeit = param; //TODO
        if (typeof(param) == "object" && param.constructor == Array) {
            sysvartable[id].Exponent = GetSIPrefixExponend(param[0]);
            sysvartable[id].siPrefix = (sysvartable[id].Exponent != 1) ? param[0] : ""; // Nur wenn wirklich genutzt
        }
        if (typeof(param.type) == "string" && param.type == "autoupdate")
            className = "autoupdate";
        if (typeof(param.type) == "string" && param.type == "scroll")
            className = "autoupdatescroller";
        if (typeof(param.type) == "string" && param.type == DISPLAYTIME.type)
            sysvartable[id].DisplayTime = true;
        if (typeof(param.type) == "string" && param.type == "hideunit")
            sysvartable[id].hideunit = true;
        if (typeof(param.type) == "string" && param.type == "min")
            sysvartable[id].min = param;
        if (typeof(param.type) == "string" && param.type == "max")
            sysvartable[id].max = param;
        if (typeof(param.type) == "string" && param.type == "hook")
            sysvartable[id].hook = param;

    }

    return '<span class="' + className + '" name="' + name + '" id="' + id + '" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>';
}

function sysvarsplit(s) {
    var varname = s;
    var array = {
        "from": -1,
        "to": -1
    };
    var isAnArray = false;
    if (s.charAt(s.length - 1) == "]") {
        isAnArray = true;
        varname = s.substr(0, s.indexOf("["));
        array.str = s.substring(s.indexOf("["));
        if (s.indexOf("..") != -1) {
            //Fix: from should be 0 since return has no index clues
            array.from = 0;//(s.substring(s.indexOf("[") + 1, s.indexOf("..")));
            array.to = (s.substring(s.indexOf("..") + 2, s.indexOf("]")));
        }
        else {
            array.to = array.from = (s.substring(s.indexOf("[") + 1, s.indexOf("]")));
        }
    }
    if (UMG510)
        return {
            "varname": s
        };
    if (!isAnArray)
        return {
            "varname": varname
        };
    else {
        return {
            "varname": varname,
            "array": array
        };
    }

}

function sysvar_mouseover(evt) {
    evt = (evt) ? evt : ((window.event) ? window.event : "");
    var elem = (evt.target) ? evt.target : evt.srcElement;
    return overlib(timestr(sysvartable[elem.id].Time), BGCOLOR, '#FF0000');
}

function sysvar_mouseout() {
    nd();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////
function CResponse() {
    this.res = new Array();
    this.warn = true;
}
CResponse.prototype.disableWarnings = function() {
    this.warn = false;
}
CResponse.prototype.mergeWith = function(secondCResp) {
    for (x in secondCResp.res) {
        if (x in Array.prototype)
            continue;
        this.res[x] = secondCResp.res[x];
    }
}
CResponse.prototype.parse = function(responseText) {
    delete this.res;
    this.res = {};

    try {
        this.res = eval("(" + responseText + ")");
    }
    catch (e) {
        LibError.Add("can't parse Ajax-Response:" + e.message);
        return;
    }
    // Remove Indices from Hashname
    for (tmp in this.res) {
        if (this.res[tmp] == "var not found !" && this.res[tmp][0] == "var not found !")
            LibError.Add("Couldn't find Sysvar " + tmp);
        //Don't split up array in UMG510
        if (!UMG510 && tmp.indexOf("]") != -1) {
            var v = sysvarsplit(tmp);
            var tmpar = this.res[tmp];
            delete this.res[tmp];
            this.res[v.varname] = tmpar;
            if (v.array.from == v.array.to && v.array.to != -1) { // Einelementige Array
                var ttt = this.res[v.varname][0];
                this.res[v.varname][0] = new Array();
                this.res[v.varname][0][0] = ttt;
                delete ttt;
            }
            this.res[v.varname].array = v.array;
        }
    }

}
/*private*/
CResponse.prototype.getvar = function(s, i, set) {
    var tmp = 0;

    if (typeof(s) == "object") {
        if (!(UMG510 || UMG507))
            s.varname = s.varname.toUpperCase();
        if (typeof(this.res[s.varname]) == "undefined") {
            if (this.warn)
                LibError.Add("System-Variable not found:\"" + s.varname + "\"");
            return [0, "NF"];
        }
        //array offset correction: Bsp _ULL_AVG[2..4], Zugriff auf _ULL_AVG[2] ist in der zur?ckgegebenen array an Pos 0 
        var arrayoffset = 0;// this.res[s.varname].array.from;
        if (s.array)
            arrayoffset = s.array.from;
        if (s.array) {
            if (typeof(set) != "undefined") {
                if (typeof(set) == "string" && set.substr(0, 4) == "UNIT")
                    this.res[s.varname][0][arrayoffset] = set.substr(4);
                else
                    this.res[s.varname][0][arrayoffset] = set;
            }
            var zahl = this.res[s.varname][0][arrayoffset];
        }
        else {
            if (typeof(set) != "undefined")
                this.res[s.varname][0] = set;
            var zahl = this.res[s.varname][0];
        }
        if (isNaN(parseInt(zahl))) { // Sysvarstring:            		
            return "Not available";
        }

        zahl = zahl * Math.pow(10, s.Exponent * -1);
        var gerundet = String(Math.runde(zahl, s.genauigkeit));
        tmp = [gerundet, s.siPrefix + this.res[s.varname][1]];
    }
    else {
        if (!(UMG510 || UMG507))
            s = s.toUpperCase();
        try {
            if (!(UMG510 || UMG507) && s.indexOf("[") > 0) {
                var tmp = sysvarsplit(s);
                s = tmp.varname;
                i = tmp.array.from;
            }
            if (typeof(this.res[s]) != "undefined" && typeof(this.res[s][0]) == "object") {
                if (typeof(set) != "undefined") {

                    if (typeof(set) == "string" && set.substr(0, 4) == "UNIT")
                        this.res[s][1] = set.substr(4);
                    else
                        this.res[s][0][i] = set;
                }
                tmp = [this.res[s][0][i], this.res[s][1]];
            }
            else {
                if (typeof(set) != "undefined") {
                    if (typeof(set) == "string" && set.substr(0, 4) == "UNIT")
                        this.res[s][1] = set.substr(4);
                    else
                        this.res[s][0] = set;
                }
                if (typeof(this.res[s]) == "undefined")
                    tmp = ["var not in response", ""];
                else
                    tmp = [this.res[s][0], this.res[s][1]];
            }
        }
        catch (e) {
        }
    }

    return tmp;
}
/*public*/
CResponse.prototype.get = function(s, i) {
    var r = this.getvar(s, i);
    if (typeof(r) == "string")
        return r;
    if (typeof(s) == "object" && s.hideunit)
        return r[0];
    return r[0] + " " + r[1];
}
/*public*/
CResponse.prototype.unit = function(s, i) {
    var x = this.getvar(s, i);
    return x[1];
}
/*public*/
CResponse.prototype.value = function(s, i) {
    var x = this.getvar(s, i);
    return x[0];
}
CResponse.prototype.set = function(s, i, data) {
    this.getvar(s, i, data);
}
//////////////////////////////////////////////////////
// Paramter:
// Name of an json-Array, like _FFT_UL1[0..40]
CResponse.prototype.Max = function(s, _from, _to) {
    if (!(UMG510 || UMG507))
        s = s.toUpperCase();
    ar = this.res[s][0];

    var from = 0;
    var to = ar.length;
    if (CResponse.prototype.Max.arguments.length >= 2)
        from = _from;
    if (CResponse.prototype.Max.arguments.length >= 3)
        to = _to;
    max = 0;
    for (var i = from; i < to; i++)
        if (ar[i] > max)
            max = ar[i];
    return max;
}
CResponse.prototype.Min = function(s, _from, _to) {
    if (!(UMG510 || UMG507))
        s = s.toUpperCase();
    ar = this.res[s][0];
    if (CResponse.prototype.Min.arguments.length >= 2)
        from = _from;
    if (CResponse.prototype.Min.arguments.length >= 3)
        to = _to;
    min = ar[0];
    for (var i = from; i < to; i++)
        if (ar[i] < min)
            min = ar[i];
    return min;
}
Response = new CResponse();
///////////////////////////////////////////////////////////////////////
function uncache(url) {
    var d = new Date();
    var time = d.getTime();
    if (url.indexOf("?") > 0)
        delim = "&";
    else
        delim = "?";
    return url + delim + 'time=' + time;
}

function uncachejson(url) {
    var d = new Date();
    var time = d.getTime();

    return url + ',time=' + time;
}

var staticI = 0;
/**
 * Creates an unique ID based on Time and Math.random().
 * "length" is the number of characters of the ID
 * @param {int} length
 * @return {string} ID
 */
function createid(length) {
    //	return staticI++;
    var d = new Date();
    var a = "" + d.getTime();
    var b = "" + (Math.random() * length);
    var s = "";
    for (var i = 0; i < length; i++)
        s += (i % 2 == 0) ? a.charAt(i % a.length) : b.charAt(i % b.length);
    return s;
}

function getIPAsString(doubleIP) {
    return (doubleIP >> 24 & 0xFF) + "." + (doubleIP >> 16 & 0xFF) + "." + (doubleIP >> 8 & 0xFF) + "." + (doubleIP & 0xFF);
}
function getIPMode(v_DHCPMODE) {
    var ret = "UNDEF";
    if (v_DHCPMODE == 0)
        ret = tl("info.fix_ip");
    if (v_DHCPMODE == 1)
        ret = "BootP";
    if (v_DHCPMODE == 2)
        ret = "DHCP";
    return ret;
}

function ById(id) {
    return document.getElementById(id);
}

function trim(str) {
    return String(str).replace(/^\s+|\s+$/g, '');

}
String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g, '');
};
function MyScrollIntoView(elem) {
    var parent = elem.parentNode;
    var ScrollTop = parent.scrollTop;
    var Height = parent.offsetHeight;
    // Not in Viewport?

    if (ScrollTop < elem.offsetTop && (elem.offsetTop + elem.offsetHeight) < (ScrollTop + Height)) {

    }
    else {
        elem.scrollIntoView();


    }

}

function showhelp_perform() {

    if (showhelp_check() && document.location.pathname == "/") {
        if (UMG510)
            document.location = "help.shtml";
        else
            document.location = "help.html"; //604/507
    }
}

function showhelp_set(bool) {
    createCookie("help", bool, 90);
}

function showhelp_gui() {
    RegisterOnloadFunction(showhelp_gui_onload);
}

function showhelp_gui_onload() {
    ById("showhelp_checkbox").checked = showhelp_check();
    addEvent(ById("showhelp_checkbox"), "click", showhelp_gui_onclick);
}

function showhelp_gui_onclick() {
    showhelp_set(ById("showhelp_checkbox").checked);
}

function showhelp_check() {
    var result = readCookie("help");
    if (result != null)
        return result[1] == "true";
    return true;
}

function openPW(href, title, width, height, showToolbar) {
    var x = (screen.availWidth - width) / 2;
    var y = (screen.availHeight - height) / 2;

    if (showToolbar) {
        if (navigator.appName == "Microsoft Internet Explorer")
            toolbar = "yes"
    } else
        toolbar = "no"
    if (window.opera) {
        var w = window.open(href, title, "width=" + width + ",height=" + height + ",toolbar=yes,scrollbars=yes,resizable=yes,menubar=yes,directories=yes,location=yes");
    } else {
        var w = window.open(href, title, "width=" + width + ",height=" + height + ",top=" + y + ",toolbar = " + toolbar + ",left=" + x + ",scrollbars=yes,resizable=yes,menubar=" + ((showToolbar) ? "yes" : "no"));
    }


}

function PadChar(i, len, charchar) {
    var s = i.toString();
    var erg = "";
    for (var d = 0; d < len - s.length; d++)
        erg += charchar;
    return erg + s;

}
function PadZeros(i, len) {
    var s = i.toString();
    var erg = "";
    for (var d = 0; d < len - s.length; d++)
        erg += "0";
    return erg + s;

}

function timestr(i) {
    return new Date(i * 1000).toLocaleString();
}

function timestrActual(i) {
    var DAYLENGTH = 24 * 60 * 60 * 1000; //24h in ms
    var past = new Date(i * 1000);
    var now = new Date();
    var tomorrowMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    var todayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    var yesterdayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);

    //Today?

    if (past >= todayMidnight && past < tomorrowMidnight) {
        return tl("info.time.today") + ", " + PadZeros(past.getHours(), 2) + ":" + PadZeros(past.getMinutes(), 2) + ":" + PadZeros(past.getSeconds(), 2);
    }
    //Yesterday?
    if (past >= yesterdayMidnight && past < todayMidnight) {
        return tl("info.time.yesterday") + ", " + PadZeros(past.getHours(), 2) + ":" + PadZeros(past.getMinutes(), 2) + ":" + PadZeros(past.getSeconds(), 2);
    }
    return new Date(i * 1000).toLocaleString();
}

function ExtractPathName(s) {
    s = s.substring(s.indexOf("/") + 1);
    s = s.substring(s.indexOf("/") + 1);
    s = s.substring(s.indexOf("/") + 1);

    return s.toLowerCase();
}

function RecTraverseTree(src, element) {
    if (!element)
        return;
    for (var i = 0; i < element.childNodes.length; i++) {
        if (element.childNodes[i].hasChildNodes())
            RecTraverseTree(src, element.childNodes[i]);

        if (String(element.childNodes[i].tagName).toLowerCase() == "a") {
            if (ExtractPathName(src) == ExtractPathName(element.childNodes[i].href))
                addStyleClass(element.childNodes[i].parentNode, "selected");
        }


    }
}

function MarkSelectedMenuItem() {
    //Find File Name:
    pathname = window.location.pathname;
    //Iterate over menu:
    var rootElement = document.getElementById("navigation");
    RecTraverseTree(pathname, rootElement);
}

function addStyleClass(elem, cssClassName) {

    if (elem.className.indexOf(cssClassName) < 0)
        elem.className += " " + cssClassName;
}

function removeStyleClass(elem, cssClassName) {
    elem.className = elem.className.replace(cssClassName, "");
}

var EventList = [];
function addEvent(obj, eventType, _function) {
    EventList.push([obj, eventType, _function]);
    if (obj.addEventListener) {
        obj.addEventListener(eventType, _function, false);
        return true;
    }
    else
    if (obj.attachEvent) {
        var retVal = obj.attachEvent("on" + eventType, _function);
        return retVal;
    }
    else {
        return false;
    }
}

function removeEvent(obj, type, fn) {
    if (obj.removeEventListener)
        obj.removeEventListener(type, fn, false);
    else
    if (obj.detachEvent) {
        obj.detachEvent("on" + type, obj[type + fn]);
        obj[type + fn] = null;
        obj["e" + type + fn] = null;
    }
}

function RemoveAllEvents() {
    for (var i = 0; i < EventList.length; i++)
        removeEvent(EventList[i][0], EventList[i][1], EventList[i][2]);

}

Math.frunde = function(x, n) {
    return parseFloat(Math.runde(x, n));
}/*
 Math.runde = function(x, n){
 if (n == 0) 
 return parseInt(x);
 if (n < 1 || n > 14) 
 return false;
 var e = Math.pow(10, n);
 var k = (Math.round(x * e) / e).toString();
 k = k.replace(".",getDecimalPoint())
 if (k.indexOf(getDecimalPoint()) == -1) 
 k += getDecimalPoint();
 k += e.toString().substring(1);
 return k.substring(0, k.indexOf(getDecimalPoint()) + n + 1);
 }*/
Math.runde = function(x, n) {

    if (n == 0)
        return parseInt(x);
    if (n < 1 || n > 14)
        return false;
    var e = Math.round(Math.pow(10, n));
    var k = (Math.round(x * e) / e).toString();
    if (k.indexOf(".") == -1)
        k += ".";
    k += e.toString().substring(1);

    return k.substring(0, k.indexOf(".") + n + 1);
}
/**
 * Retrive Mousecoordinates from Event e
 * @param {Object} e
 * @return {Object} X & Y
 */
function extractMouseFromEvent(e) {
    var posx = 0;
    var posy = 0;
    if (e.pageX || e.pageY) {
        posx = e.pageX;
        posy = e.pageY;
    }
    else
    if (e.clientX || e.clientY) {
        posx = e.clientX + document.body.scrollLeft +
                document.documentElement.scrollLeft;
        posy = e.clientY + document.body.scrollTop +
                document.documentElement.scrollTop;
    }
    return {
        "x": posx,
        "y": posy
    };
}


/////////////////////////////////////////////////////////////////////////////////////////////
// Translate

lang = new Array();
//fallback;
function TranslateWord(id) {
    InitTranslate();
    if (typeof((lang[0][1])) != "undefined" && lang[0][1][id])
        return lang[0][1][id];
    if (lang[1][id]) {
        LibError.Warning("Translate: Couldn't find id \"" + id + "\" in main Language, using Fallback-Language, Result:" + lang[1][id]);
        return lang[1][id];
    }
    LibError.Add("Translate: Couldn't find id \"" + id + "\" in main Language and Fallback-Language, returning id.");
    return id;
}

function mapIdsToArray(prefix, count) {
    var arr = {};
    var curLang = lang[lang.length - 1];
    for (var i = 0; i <= count; i++)
        arr[i] = curLang[prefix + i];
    return arr;
}

function getMonthArray() {
    if (TimeStrArray[0][1])
        return TimeStrArray[0][1];
    if (TimeStrArray[1])
        return TimeStrArray[1];
    return "LibError in getMonthArray()!";
}

function getDayOfWeekArray() {
    if (TimeStrArray[0][2])
        return TimeStrArray[0][2];
    if (TimeStrArray[2])
        return TimeStrArray[2];
    return "LibError in getDayOfWeekArray()!";
}


/**
 * Create a new Language
 * //Example:
 * CreateNewLanguage("de","Deutsch", "/img/flags/de.gif",",");
 * @param {Object} abbr
 * @param {Object} Long Name of Language
 * @param {Object} Path to flag symbole
 * @param {Object} Decimal Point
 */
function CreateNewLanguage(abbr, lang, flag, decPoint) {
    if (typeof(RegisterLanguage) == "undefined") {
        AlterLanguageDelay.push(["create", abbr, lang, flag, decPoint])
        return;
    }
    //Update if already here:
    for (i = 0; i < RegisterLanguage.length - 1; i++) {
        if (RegisterLanguage[i]["abbr"].toLowerCase() == abbr) {
            RegisterLanguage[i]["lang"] = lang;
            RegisterLanguage[i]["flag"] = flag;
            RegisterLanguage[i]["point"] = decPoint;
            return;
        }
    }
    //no?. then create new lang
    RegisterLanguage.push(
            {
                "abbr": abbr,
                "lang": lang,
                "flag": flag,
                "point": decPoint
            }
    );
}
/**
 * Add a new entry to the Translationtable.
 * Only if abbr matches current language, change will have effect.
 * Example:
 * AddTranslation("de","info.lang.id","NeuesWort");
 * @param {Object} abbr
 * @param {Object} id
 * @param {Object} word
 */
function AddTranslation(abbr, id, word) {
    if (typeof(RegisterLanguage) == "undefined") {
        AlterLanguageDelay.push(["newtrans", abbr, id, word])
        return;
    }
    if (CurrentLanguage == abbr) {
        lang[0][1][id] = word;
    }
}

var staticPoint = "";
function getDecimalPoint() {
    if (staticPoint != "")
        return staticPoint;
    for (i = 0; i < RegisterLanguage.length - 1; i++) {
        if (RegisterLanguage[i]["abbr"].toLowerCase() == CurrentLanguage) {
            staticPoint = RegisterLanguage[i]["point"]
            return staticPoint;
        }
    }
}
function Translate() {
    //Check if there is a language defined
    if (typeof(RegisterLanguage) === "undefined") {
        return;
    }

    // Create main nodes
    var Node = $('<li/>');
    var SecNode = $('<ul/>');
    Node.append(SecNode);

    //add languages to nodes
    for (var i = 0; i < RegisterLanguage.length; i++) {

        if (RegisterLanguage[i]["default"]) {
            continue;
        }

        if (RegisterLanguage[i]["abbr"] === CurrentLanguage) {
            var ta2 = $("<a/>");
            ta2.attr("class", "languagename");

            ta2.append(RegisterLanguage[i]["lang"]);

            Node.attr("alt", RegisterLanguage[i]["abbr"]);
            ta2.attr("alt", RegisterLanguage[i]["abbr"]);

            var timg = $("<img/>");
            timg.attr("src", RegisterLanguage[i]["flag"]);
            timg.attr("alt", RegisterLanguage[i]["abbr"]);
            timg.attr("title", RegisterLanguage[i]["lang"]);

            Node.append(timg);
            Node.append(ta2);

        } else {
            var tli = $("<li/>");
            var ta2 = $("<a/>");

            ta2.attr("class", "languagename");
            ta2.append(RegisterLanguage[i]["lang"]);

            tli.attr("alt", RegisterLanguage[i]["abbr"]);
            ta2.attr("alt", RegisterLanguage[i]["abbr"]);

            var timg = $("<img/>");
            timg.attr("src", RegisterLanguage[i]["flag"]);
            timg.attr("alt", RegisterLanguage[i]["abbr"]);
            timg.attr("title", RegisterLanguage[i]["lang"]);

            tli.append(timg);
            tli.append(ta2);

            tli.click(function() {
                location.href = location.pathname + "?_LANGUAGE=" + $(this).attr("alt");
            });
            SecNode.append(tli);
        }
    }
    $("#languageselector").append(Node);

    TranslatePage();

}

function TranslatePage() {
    var transselects = $("select");
    for (var i = transselects.length - 1; i >= 0; i--) {
        for (var j = 0; j < transselects[i].options.length; j++) {
            transselects[i].options[j].text = tl(transselects[i].options[j].text);
        }
    }
    var transelements = $(".trans");
    for (var i = transelements.length - 1; i >= 0; i--) {
        if (!$(transelements[i]).is("select")) {
            var translation = document.createElement("span");
            translation.innerHTML = (tl(transelements[i].innerHTML));
            transelements[i].parentNode.replaceChild(translation, transelements[i]);
        }
    }
}
/**
 * Translate Floats with Dot Decimal Point to local decimal point.
 * @param {float/String} n
 */
function tlnum(n) {
    return String(n).replace(/\./, getDecimalPoint());
}
function tlToFloat(n) {
    return String(n).replace(getDecimalPoint(), ".");
}

function tl(s) {
    return TranslateWord(s);
    //return "<span class=\"trans\">"+s+"</span>";
}

var lang_fallback = "";
var lang = new Array();
var TimeStrArray = new Array();

function InitTranslate() {
    //Ensure _LANGUAGE is correct:
    var foundCurLang = false;
    for (i = 0; i < RegisterLanguage.length - 1; i++) {
        if (RegisterLanguage[i]["abbr"].toLowerCase() == CurrentLanguage) {
            foundCurLang = true;
        }
    }
    if (!foundCurLang) {
        CurrentLanguage = "de";
        oldlang = lang;
        lang[0] = [[], lang[1]];
        AjaxRequestProvider.RegisterRequest("dummy.html?_LANGUAGE=de", null, null);
    }
    //Alter Laguage	
    for (var i = 0; i < AlterLanguageDelay.length; i++) {
        var a = AlterLanguageDelay[i]
        if (a[0] == "create")
            CreateNewLanguage(a[1], a[2], a[3], a[4]);
        if (a[0] == "newtrans")
            AddTranslation(a[1], a[2], a[3]);
    }
    if (UMG510 || UMG507) {
        if (CurrentLanguage == "de")
            lang[0][1] = lang[1];
    }
    AlterLanguageDelay = [];

}

function change_language(evt) {
    evt = (evt) ? evt : ((window.event) ? window.event : "");
    var elem = (evt.target) ? evt.target : evt.srcElement;

    newlang = elem.getAttribute("alt");
    if (UMG510 || UMG507) {
        createCookie("lang", newlang, 90);
        if (newlang != readCookie("lang"))
            alert(tl("error.cookielang"));
        document.location.reload();
    } else {
        location.href = location.pathname + "?_LANGUAGE=" + newlang;
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////
// AutoUpdate
function AutoUpdate(sysvar) {
    return '<span class="autoupdate" name="' + sysvar + '">&nbsp;&nbsp;&nbsp;&nbsp;</span>';
}

function AutoUpdateScroller(sysvar) {
    return '<span class="autoupdateScroller" name="' + sysvar + '">&nbsp;&nbsp;&nbsp;&nbsp;</span>';
}
function HandleSysvarMinMax(item, obj, value) {
    if (item.min) {
        if (value < item.min.value)
            addStyleClass(obj, "sysvar_min")
        else
            removeStyleClass(obj, "sysvar_min");
    }
    if (item.max) {
        if (value > item.max.value)
            addStyleClass(obj, "sysvar_max")
        else
            removeStyleClass(obj, "sysvar_max");
    }
}
function AutoUpdateWorker_callback(responseText) {
    var AutoUpdateResponse = new CResponse();
    if (UMG510 || UMG507) {
        AutoUpdateResponse.res = responseText; // see callback 510
        AutoUpdateResponse.disableWarnings();
    }
    else
        AutoUpdateResponse.parse(responseText);
    var ToDo = [];
    var AutoUpdateObjs = document.getElementsByTagName("span");
    for (i = 0; i < AutoUpdateObjs.length; i++) {
        var type = containsMarker(AutoUpdateObjs[i].className)
        if (type == "autoupdate") {

            var value = String(AutoUpdateResponse.get(sysvartable[AutoUpdateObjs[i].id]));
            var sysvarobj = {
                "varname": sysvartable[AutoUpdateObjs[i].id].org,
                "value": value
            }
            var hookret = false;
            if (sysvartable[AutoUpdateObjs[i].id].hook)
                hookret = sysvartable[AutoUpdateObjs[i].id].hook.func(sysvarobj);

            if (hookret)
                value = sysvarobj.value;


            if (UMG604COMP && sysvartable[AutoUpdateObjs[i].id].varname == "_DIGIN_STAT") {
                value = value.replace("0", tl("info.off"));
                value = value.replace("1", tl("info.on"));
            }
            if (UMG507) {
                var xname = sysvartable[AutoUpdateObjs[i].id].varname;
                if (xname.indexOf("digin") == 0 && xname.indexOf("digin_") != 0) {
                    value = value.replace("0", tl("info.off"));
                    value = value.replace("1", tl("info.on"));
                }
            }
            if (UMG510 && sysvartable[AutoUpdateObjs[i].id].varname.indexOf("binxinp") == 0) {
                value = value.replace("0", tl("info.off"));
                value = value.replace("1", tl("info.on"));
            }
            if (value.indexOf("NF") < 0)
                AutoUpdateObjs[i].innerHTML = (!isNaN(parseInt(value))) ? value.replace(/\./, getDecimalPoint()) : value;
            if (sysvartable[AutoUpdateObjs[i].id].DisplayTime) {
                sysvartable[AutoUpdateObjs[i].id].Time = AutoUpdateResponse.value(sysvartable[AutoUpdateObjs[i].id].getURL()[1]);
            }
            HandleSysvarMinMax(sysvartable[AutoUpdateObjs[i].id], AutoUpdateObjs[i], AutoUpdateResponse.value(sysvartable[AutoUpdateObjs[i].id]));
        }
        if (type == "autoupdatescroller") {
            var ValueList = [];
            spanlist = AutoUpdateObjs[i].getElementsByTagName("span");
            for (X = 0; X < spanlist.length; X++)
                ValueList[X] = spanlist[X].innerHTML;
            var nxtValue = AutoUpdateResponse.get(sysvartable[AutoUpdateObjs[i].id]);
            if (UMG604COMP) {
                if (sysvartable[AutoUpdateObjs[i].id].varname == "_DIGIN_STAT") {
                    nxtValue = String(nxtValue).replace("0", tl("info.off"));
                    nxtValue = String(nxtValue).replace("1", tl("info.on"));

                } else {
                    nxtValue = String(nxtValue).replace(/\./, getDecimalPoint());
                }
            }
            if (UMG507) {
                var xname = sysvartable[AutoUpdateObjs[i].id].varname;
                if (xname.indexOf("digin") == 0 && xname.indexOf("digin_") != 0) {
                    nxtValue = String(nxtValue).replace("0", tl("info.off"));
                    nxtValue = String(nxtValue).replace("1", tl("info.on"));

                } else {
                    nxtValue = String(nxtValue).replace(/\./, getDecimalPoint());
                }
            }
            if (UMG510) {
                if (sysvartable[AutoUpdateObjs[i].id].varname.indexOf("binxinp") == 0) {
                    nxtValue = String(nxtValue).replace("0", tl("info.off"));
                    nxtValue = String(nxtValue).replace("1", tl("info.on"));

                } else {
                    nxtValue = String(nxtValue).replace(/\./, getDecimalPoint());
                }
            }
            ValueList.unshift(nxtValue);
            if (ValueList.length > 3)
                ValueList.pop();
            var s = "";
            for (X = 0; X < ValueList.length; X++)
                s += '<span class="auscroll' + X + '">' + ValueList[X] + '</span>';
            ToDo[ToDo.length] = new Array(AutoUpdateObjs[i], s);
        }
    }
    // Noetig, da sonst die Schleife sich staendig neue Elemente selbst hinzufuegt.
    for (var i = 0; i < ToDo.length; i++)
        ToDo[i][0].innerHTML = ToDo[i][1];
    AutoUpdateResponse = null;
    setTimeout("AutoUpdateWorker()", AUTOUPDATE_INTERVAL);
}

var AutoUpdateVarList = new VarListBuilder();
var _AutoUpdateRescan = false;

function AutoUpdateWorker() {

    if (_AutoUpdateRescan) {

        var AutoUpdateObjs = document.getElementsByTagName("span");
        AutoUpdateVarList = null;
        AutoUpdateVarList = new VarListBuilder();

        for (i = 0; i < AutoUpdateObjs.length; i++) {
            var type = containsMarker(AutoUpdateObjs[i].className)
            if (!type)
                continue;

            if (type == "autoupdate" || type == "autoupdatescroller")
                AutoUpdateVarList.Add(sysvartable[AutoUpdateObjs[i].id].getURL());
        }
        _AutoUpdateRescan = false;

    }
    if (AutoUpdateVarList.count() > 0) {
        if (UMG604COMP) {
            AjaxRequestProvider.RegisterRequest("/json.do?" + AutoUpdateVarList.Build(), AutoUpdateWorker_callback, "Autoupdate");
        }
        if (UMG510 || UMG507) {
            var fileList = AutoUpdateVarList.Build510();
            if (typeof(UMG510ResponseAU) != "undefined" && UMG510ResponseAU.toGo != 0) {
                LibError.Debug("AutoUpdateWorker, Queue LibError");
                setTimeout("AutoUpdateWorker()", 1000);
                return;
            }
            UMG510ResponseAU = {
                "Buffer": [],
                "toGo": fileList.length,
                "FileList": fileList
            };
            for (var i in fileList) {
                if (i in Array.prototype)
                    continue;
                //Note: 510 can't use the uncache option, due to "?" leads to 404 as it is interpreted as a filename
                AjaxRequestProvider.RegisterRequest((UMG510) ? fileList[i] : uncache(fileList[i]), AutoUpdateWorker_callback_510, "Autoupdate");
            }
        }

    }
    else
        setTimeout("AutoUpdateWorker()", 1000);
}

function sysvar_callback(responseText) {
    clearInterval(loadAnim);
    if (UMG510 || UMG507) {
        Response.res = responseText; // see sysvar_callback510
    }
    else
        Response.parse(responseText);
    var ToDo = new Array();
    var AutoUpdateObjs = document.getElementsByTagName("span");
    for (i = 0; i < AutoUpdateObjs.length; i++) {
        var type = containsMarker(AutoUpdateObjs[i].className);
        if (type == "sysvar") {
            var sysvarobj = {
                "varname": sysvartable[AutoUpdateObjs[i].id].org,
                "value": Response.get(sysvartable[AutoUpdateObjs[i].id])
            }
            var hookret = false;
            if (sysvartable[AutoUpdateObjs[i].id].hook)
                hookret = sysvartable[AutoUpdateObjs[i].id].hook.func(sysvarobj);
            if (hookret)
                AutoUpdateObjs[i].innerHTML = (!isNaN(parseInt(sysvarobj.value))) ? sysvarobj.value.replace(/\./, getDecimalPoint()) : sysvarobj.value;
            else
                AutoUpdateObjs[i].innerHTML = Response.get(sysvartable[AutoUpdateObjs[i].id]).replace(/\./, getDecimalPoint());

            if (sysvartable[AutoUpdateObjs[i].id].DisplayTime)
                sysvartable[AutoUpdateObjs[i].id].Time = Response.value(sysvartable[AutoUpdateObjs[i].id].getURL()[1]);
            HandleSysvarMinMax(sysvartable[AutoUpdateObjs[i].id], AutoUpdateObjs[i], Response.value(sysvartable[AutoUpdateObjs[i].id]));
        }

    }
    // Noetig, da sonst die Schleife sich staendig neue Elemente selbst hinzufuegt.
    for (var i = 0; i < ToDo.length; i++)
        ToDo[i][0].innerHTML = ToDo[i][1];
    delete responseText;
    sysvar_loaded = true;
}

///////////////////////////////////////////////////////////////////////////7
// Klasse VarListBuilder
// Funktion: 
// Dabei werden Arrays zusammegefasst und doppeldeutigkeiten vermieden.
// Beispiel:
// var VarList = new VarListBuilder();
// VarList.Add("_TIME");
// VarList.Add("_DEV_DESC", "_FFT_UL1[0..2]");
// VarList.Add("_TIME");
// VarList.Build() gibt dann zur?ck:
function VarListBuilder() {
    this.list = new Array();

}

VarListBuilder.prototype._Add = function(s) {
    if (UMG510 || UMG507) {
        //510  arrays like vars
        this.list[s] = {
            "varname": s
        };
        return;
    }
    //Array?
    var varname = s;
    var array = {
        "from": 0,
        "to": 0
    };
    var isAnArray = false;
    if (s.charAt(s.length - 1) == "]") {
        isAnArray = true;
        varname = s.substr(0, s.indexOf("["));
        if (s.indexOf("..") != -1) {
            //Fix: from should be 0 since return has no index clues
            array.from = 0;//(s.substring(s.indexOf("[") + 1, s.indexOf("..")));
            array.to = (s.substring(s.indexOf("..") + 2, s.indexOf("]")));
        }
        else {
            array.to = array.from = (s.substring(s.indexOf("[") + 1, s.indexOf("]")));
        }
    }

    if (typeof(this.list[varname]) == "undefined") {
        if (!isAnArray) {
            this.list[varname] = {
                "varname": varname
            };
        }
        else {
            this.list[varname] = {
                "varname": varname,
                "array": array
            };
        }
    }
    else
    if (isAnArray) {
        //Update min/max	
        //Fix: from should be 0 since return has no index clues
        this.list[varname].array.from = 0;// Math.min(this.list[varname].array.from, array.from);
        this.list[varname].array.to = Math.max(this.list[varname].array.to, array.to);
    }


}
/**
 * Example:
 * VarList.Add("_ULN[0]");
 * VarList.Add( ["_ULN[0]","_ULN[1]"] );
 * @param {String|Array} sysvar(s)
 */
VarListBuilder.prototype.Add = function(sysvars) {
    /*for(var i=0;i<VarListBuilder.prototype.Add.arguments.length;i++)
     this._Add( VarListBuilder.prototype.Add.arguments[i].toUpperCase() );		*/
    if (sysvars == null)
        return false;
    if (typeof(sysvars) == "object" && sysvars.constructor == Array) {
        for (var i in sysvars) {
            if (i in Array.prototype)
                continue;
            if (!(UMG510 || UMG507))
                this._Add(sysvars[i].toUpperCase());
            else
                this._Add(sysvars[i]);
        }
    }
    else
    if (!(UMG510 || UMG507))
        this._Add(sysvars.toUpperCase());
    else
        this._Add(sysvars);

}
VarListBuilder.prototype.count = function() {
    var x = 0;
    for (var obj in this.list) {
        if (obj in Array.prototype)
            continue;
        x++;
    }
    return x;
}
VarListBuilder.prototype.Build = function() {
    var s = "";
    for (var obj in this.list) {
        if (obj in Array.prototype)
            continue;
        s += obj;
        if (typeof(this.list[obj].array) == "object")
            if (this.list[obj].array.from == this.list[obj].array.to)
                s += "[" + this.list[obj].array.from + "]";
            else
                s += "[" + this.list[obj].array.from + ".." + this.list[obj].array.to + "]";
        s += ",";
    }
    s = s.substr(0, s.length - 1);
    return s;
}
// Varlist510
// Returns all necessary files.
// Because 510 is without JSON-Interface
VarListBuilder.prototype.Build510 = function() {

    var filenameTmpl;
    if (UMG510)
        filenameTmpl = "data{CNT}.shtml"
    if (UMG507)
        filenameTmpl = "data{CNT}.html"
    var numMap = new Object();
    for (var obj in this.list) {
        var iDataFile;
        if (UMG510)
            iDataFile = Varlist510[obj];
        else
            iDataFile = Varlist507[obj];

        if (typeof(iDataFile) == "undefined") {
            LibError.Add("System variable " + obj + " is not supported in " + ((UMG510) ? "UMG510" : "UMG507") + " Webinterface. Sure it is valid? ");
            continue;
        }
        numMap[iDataFile] = iDataFile;
    }
    var filelist = [];
    var i = 0;
    for (var n in numMap)
        filelist[i++] = filenameTmpl.replace("{CNT}", n);
    return filelist;
}
///////////////////////////////////////////////////////////////////////////
function AutoUpdateRescan() {
    _AutoUpdateRescan = true;
}

var UMG510Response = new Object();
var UMG510ResponseAU = new Object();

function isAlpha(cha) {
    if (cha >= 'a' && cha <= 'z')
        return true;
    if (cha >= 'A' && cha <= 'Z')
        return true;
    return false;
}

////
// bsp:  1234abc =>4
function LastBeginOfAlphaStr(str) {
    for (var i = str.length - 1; i >= 0; i--) {
        if (!isAlpha(str.charAt(i)) && str.charAt(i) != "%")
            return i + 1;

    }
    return 0;
}

function transform510OutputToResponseInternalStructur(s) {
    var newObjVar = new Object();
    var aVars = s.split(/\~\|\$/);
    for (var i in aVars) {
        if (i in Array.prototype)
            continue;
        var aTokens = aVars[i].split(/:/);
        if (aTokens == "")
            continue;
        var iTrenn = LastBeginOfAlphaStr(aTokens[1]);

        var rawvalue = aTokens[1].substr(0, iTrenn);
        var rawunit = aTokens[1].substr(iTrenn);
        var factor = 1;
        var unit = rawunit;

        if (rawunit.charAt(0) == "p") {
            factor = 1e-12;
            unit = rawunit.substr(1);
        }
        if (rawunit.charAt(0) == "n") {
            factor = 1e-9;
            unit = rawunit.substr(1);
        }
        if (rawunit.charAt(0) == "u") {
            factor = 1e-6;
            unit = rawunit.substr(1);
        }
        if (rawunit.charAt(0) == "m") {
            factor = 1e-3;
            unit = rawunit.substr(1);
        }
        if (rawunit.charAt(0) == "k") {
            factor = 1e3;
            unit = rawunit.substr(1);
        }
        if (rawunit.charAt(0) == "M") {
            factor = 1e6;
            unit = rawunit.substr(1);
        }
        if (rawunit.charAt(0) == "G") {
            factor = 1e9;
            unit = rawunit.substr(1);
        }
        if (rawunit.charAt(0) == "T") {
            factor = 1e12;
            unit = rawunit.substr(1);
        }
        var fValue = parseFloat(rawvalue);
        if (rawvalue.charAt(0) == '"')
            newObjVar[aTokens[0]] = [rawvalue.substr(1, rawvalue.length - 2), unit]; //String
        else
            newObjVar[aTokens[0]] = [fValue * factor, unit];//Num

    }
    return newObjVar;
}

function sysvar_callback510(responseText, obj) {
    if (responseText.trim() != "" && responseText.indexOf(":") != -1)
        UMG510Response.Buffer.push(responseText);
    if (--UMG510Response.toGo == 0) {
        var newObjVar = transform510OutputToResponseInternalStructur(UMG510Response.Buffer.join("~|$"))
        if (newObjVar != false && UMG510Response.Buffer.length == UMG510Response.FileList.length)
            sysvar_callback(newObjVar);
    }
}

function AutoUpdateWorker_callback_510(responseText, obj) {
    if (responseText.trim() != "" && responseText.indexOf(":") != -1)
        UMG510ResponseAU.Buffer.push(responseText);
    if (--UMG510ResponseAU.toGo == 0) {
        var newObjVar = transform510OutputToResponseInternalStructur(UMG510ResponseAU.Buffer.join("~|$"))
        if (newObjVar != false && UMG510ResponseAU.Buffer.length == UMG510ResponseAU.FileList.length)
            AutoUpdateWorker_callback(newObjVar);
    }
}
var loadAnim;
var loadAnimAr = ["|", "/", "--", "\\"]
var loadAnimArI = 0;
var loadAnimTick = 0;
function updateLoadAnim() {
    if (loadAnimTick++ < LOAD_ANIM_WAIT_TICKS)
        return;
    var AutoUpdateObjs = document.getElementsByTagName("span");
    var mChar = loadAnimAr[loadAnimArI++ % loadAnimAr.length];

    for (i = 0; i < AutoUpdateObjs.length; i++) {
        var type = containsMarker(AutoUpdateObjs[i].className)
        if (!type)
            continue;
        if (type == "sysvar" || type == "autoupdate" || type == "autoupdatescroller")
            AutoUpdateObjs[i].innerHTML = mChar;

    }
}
function SysvarWorker() {
    if (LOAD_ANIM_MS > 0)
        loadAnim = setInterval("updateLoadAnim()", LOAD_ANIM_MS);
    var VarList = "";
    var AutoUpdateObjs = document.getElementsByTagName("span");
    var VarList = new VarListBuilder();

    for (i = 0; i < AutoUpdateObjs.length; i++) {
        var type = containsMarker(AutoUpdateObjs[i].className)
        if (!type)
            continue;
        if (type == "sysvar")
            VarList.Add(sysvartable[AutoUpdateObjs[i].id].getURL());
        if (type == "autoupdate" || type == "autoupdatescroller")
            AutoUpdateVarList.Add(sysvartable[AutoUpdateObjs[i].id].getURL());
    }
    if (UMG604COMP) {
        AjaxRequestProvider.RegisterRequest("/json.do?" + VarList.Build() + "", sysvar_callback);
        AjaxRequestProvider.RegisterRequest("/json.do?" + AutoUpdateVarList.Build(), AutoUpdateWorker_callback, "Autoupdate");
    }
    if (UMG510 || UMG507) {
        var fileList = VarList.Build510();
        UMG510Response = {
            "Buffer": [],
            "toGo": fileList.length,
            "FileList": fileList
        };
        for (var i in fileList) {
            if (i in Array.prototype)
                continue;
            //Note: 510 can't use the uncache option, due to "?" leads to 404 as it is interpreted as a filename
            AjaxRequestProvider.RegisterRequest((UMG510) ? fileList[i] : uncache(fileList[i]), sysvar_callback510)
        }
        var fileList = AutoUpdateVarList.Build510();

        UMG510ResponseAU = {
            "Buffer": [],
            "toGo": fileList.length,
            "FileList": fileList
        };
        for (var i in fileList) {
            if (i in Array.prototype)
                continue;
            //Note: 510 can't use the uncache option, due to "?" leads to 404 as it is interpreted as a filename
            AjaxRequestProvider.RegisterRequest((UMG510) ? fileList[i] : uncache(fileList[i]), AutoUpdateWorker_callback_510, "Autoupdate");
        }
        if (fileList.length == 0) {
            //Trigger AutoUpdate Check Routine:
            AutoUpdateWorker_callback("");
        }
    }

}

/**
 * Returns whether className contains string "sysvar",
 * "autoupdate" or "autoupdatescroller".
 * @param {String} A className
 * @return {bool/String}
 */
function containsMarker(s) {
    var ar = s.split(" ");
    for (var XZ in ar) {
        if (XZ in Array.prototype)
            continue;
        if (ar[XZ].toLowerCase() == "sysvar")
            return "sysvar";
        if (ar[XZ].toLowerCase() == "autoupdate")
            return "autoupdate";
        if (ar[XZ].toLowerCase() == "autoupdatescroller")
            return "autoupdatescroller";

    }
    return false;
}

function InitSysvar() {
    var AutoUpdateObjs = document.getElementsByTagName("span");
    var z = 0;
    for (i = 0; i < AutoUpdateObjs.length; i++) {
        if (containsMarker(AutoUpdateObjs[i].className)) {
            z++;
            if (!sysvartable[AutoUpdateObjs[i].id])
                sysvarFromElement(AutoUpdateObjs[i]);
            if (sysvartable[AutoUpdateObjs[i].id].DisplayTime) {
                AutoUpdateObjs[i].onmouseover = sysvar_mouseover;
                AutoUpdateObjs[i].onmouseout = sysvar_mouseout;
            }
        }

    }
    if (z > 0)
        SysvarWorker();




}



/////////////////////////////////////////////////////////////////////////////////////////////
// TableHelper

function tableclick(evt) {
    evt = (evt) ? evt : ((window.event) ? window.event : "");
    var elem = (evt.target) ? evt.target : evt.srcElement;
    evt.cancelBubble = true; // Stop event from bubbling

    if (!LibLoaded)
        return;
    var iDeadlock
    var parentTable = elem;
    var watchdog = 10;
    while (parentTable.tagName != "TABLE") {
        parentTable = parentTable.parentNode;
        if (watchdog-- == 0)
            break;
    }
    var pos = extractMouseFromEvent(evt);
    for (var i in TableHelperList) {
        if (i in Array.prototype)
            continue;
        if (TableHelperList[i].id == parentTable.id) {
            TableHelperList[i].menu.eventSource = parentTable;
            { // Modify Popup: Show only avialible options, see StdMenuCallback
                //a)  Count Min,Max,avg_max
                var Counter = {
                    "MIN": 0,
                    "MAX": 0,
                    "AVG_MAX": 0
                };
                var spans = parentTable.getElementsByTagName("span");
                for (var z = 0; z < spans.length; z++) {
                    if (!spans[z] || typeof(spans[z].className) == "undefined")
                        continue;
                    var type = containsMarker(spans[z].className);
                    if (type == "sysvar" || type == "autoupdate") {
                        var name = spans[z].getAttribute("name");

                        if (name.indexOf("_MIN") > 0)
                            Counter["MIN"]++;
                        if (name.indexOf("_MAX") > 0)
                            Counter["MAX"]++;
                        if (name.indexOf("_AVG_MAX") > 0)
                            Counter["AVG_MAX"]++;

                    }

                }
                //b) delte if counter is 0
                if (Counter["MIN"] == 0)
                    TableHelperList[i].menu.DeleteById(ID_DELMIN);
                if (Counter["MAX"] == 0)
                    TableHelperList[i].menu.DeleteById(ID_DELMAX);
                if (Counter["AVG_MAX"] == 0)
                    TableHelperList[i].menu.DeleteById(ID_DELAVGMAX);

            }
            TableHelperList[i].menu.popup(pos.x, pos.y);
        }
    }


}

function tableleave(obj) {
    obj.className = obj.className.replace(/theadhighlight/, "");
    nd();
}

var TableHelperList = [];
function TableHelper() {
    var AttrList = "";
    if (TableHelper.arguments.length >= 1) {
        var arg2 = TableHelper.arguments[0];
        for (var y in arg2) {
            if (y in Array.prototype)
                continue;
            AttrList += " " + y + " = \"" + arg2[y] + "\"";
        }
    }
    this.id = "tab" + createid(12);
    this.s = "<table id=\"" + this.id + "\" class=\"contenttable\" " + AttrList + ">";
    this.HeadOpen = false;
    this.RowOpen = false;
    this.TableClosed = false;
    this.RowCount = 0;
    TableHelperList.push(this);
}

////////
// Only if DISPLAY_TABLE_HAS_CONTEXTMENU_GIF == true
function tableover() {
    overlib("", WIDTH, 38, HEIGHT, 34, BACKGROUND, "/img/hascontext.gif", FGCOLOR, '');
}

function tableout() {
    nd();
}

//
///////
TableHelper.prototype.AssignMenu = function(menu) {
    if (menu.type != "CMenu")
        LibError.Debug("AssignMenu: Paramter must be instance of class CMenu.");
    this.menu = menu;
    RegisterOnloadFunction(new Function("", "addEvent(document.getElementById('" + this.id + "'),'click',tableclick,true);"));
    if (DISPLAY_TABLE_HAS_CONTEXTMENU_GIF) {
        RegisterOnloadFunction(new Function("", "addEvent(document.getElementById('" + this.id + "'),'mouseover',tableover,true);"));
        RegisterOnloadFunction(new Function("", "addEvent(document.getElementById('" + this.id + "'),'mouseout',tableout,true);"));
    }
    RegisterOnloadFunction(new Function("", "addStyleClass(document.getElementById('" + this.id + "'),'hand');"));
}

TableHelper.prototype.NewRow = function() {
    if (this.HeadOpen) {
        this.s += "</tr></thead>";
        this.HeadOpen = false;
    }
    if (this.RowOpen)
        this.s += "</tr>";
    this.RowCount++;
    var AttrList = "";
    if (TableHelper.prototype.NewRow.arguments.length >= 1) {
        var arg2 = TableHelper.prototype.NewRow.arguments[0];
        for (var y in arg2) {
            if (y in Array.prototype)
                continue;
            AttrList += " " + y + " = \"" + arg2[y] + "\"";
        }
    }
    if (this.RowCount % 2 == 0)
        this.s += "<tr class=\"odd\" " + AttrList + ">";
    else
        this.s += "<tr " + AttrList + ">";

    this.RowOpen = true;
}
TableHelper.prototype.NewHeader = function() {
    if (this.RowOpen) {
        this.s += "</tr>";
        this.RowOpen = false
    }
    if (this.HeadOpen)
        this.s += "<tr>";
    else
        this.s += "<thead><tr>";
    this.HeadOpen = true;
}
TableHelper.prototype.AddCellWithOverlib = function(Content, overlibstr, addpram) {
    var obj = {
        "onmouseout": "return nd();",
        "onmouseover": "return overlib('" + overlibstr.replace(/'/ig, "\\'") + "');"
    };
    if (is_phone) {
        obj.onmouseover = "return overlib('" + overlibstr.replace(/'/ig, "\\'") + "',TIMEOUT,5000);"
    }
    for (var x in addpram) {
        obj[x] = addpram[x];
    }
    this.AddCell(Content, obj);
}

TableHelper.prototype.AddRaw = function(Content) {
    if (!Content)
        Content = "";
    this.s += Content;
}
/*
 use:
 t.AddCell("XY");
 t.AddCell("xy", {"onmouseover":"overlib()"});
 */
TableHelper.prototype.AddCell = function(Content) {
    if (!Content)
        Content = "";
    var AttrList = "";
    if (TableHelper.prototype.AddCell.arguments.length > 1 && typeof(TableHelper.prototype.AddCell.arguments[1]) != "string") {
        var arg2 = TableHelper.prototype.AddCell.arguments[1];
        for (var y in arg2) {
            if (y in Array.prototype)
                continue;
            AttrList += " " + y + " = \"" + arg2[y] + "\"";
        }
    }
    //if(this.HeadOpen)
    //AttrList+=" onmouseover=\"tableover(this)\" onmouseout=\"tableleave(this)\"";
    this.s += "<td" + AttrList + ">" + Content + "</td>";
}
TableHelper.prototype.flush = function() {
    if (this.RowOpen) {
        this.s += "</tr>";
        this.RowOpen = false;
    }
    if (this.HeadOpen) {
        this.s += "</tr></thead>";
        this.HeadOpen = false;
    }

    if (!this.TableClosed) {
        this.s += "</table>"
        this.TableClosed = true;
    }
    return this.s;
}
/////////////////////////////////////////////////////////////////////////////////////////////
// ConfigHelper
/*DELAY=0;
 WRAP = 0;
 TIMEOUT = 1500;
 vtimeout= 0;
 function overlib(s, x,y,z){
 if(vtimeout!=0)
 clearTimeout(vtimeout);
 el = document.getElementById("overDiv");
 if(!el)return;
 el.innerHTML = s;
 el.style.visibility = "visible";
 }
 function nd(){
 vtimeout = setTimeout("hideover()",TIMEOUT);
 }*/
function hideover() {
    el = document.getElementById("overDiv");
    if (!el)
        return;
    el.innerHTML = "";
    el.style.visibility = "hidden";
}

var ConfigHelperInstances = new Array();
var ConfigHelper_IntervalID;
function ConfigHelper_callback(responseText, form) {
    var Response = new CResponse();
    if (UMG507)
        Response.res = responseText;
    else
        Response.parse(responseText);

    var formObj = null;
    for (var i = 0; i < ConfigHelperInstances.length; i++)
        if (ConfigHelperInstances[i].id == form.id)
            formObj = ConfigHelperInstances[i];
    if (formObj == null)
        LibError.Add("FormObj is null, so no form with correct id was found. 0x74472");

    var elements = form.getElementsByTagName("*");
    var VarList = new VarListBuilder();
    for (var i = 0; i < elements.length; i++) {
        if (typeof(elements[i]) == "undefined" || !elements[i].getAttribute)
            continue;
        var n = elements[i].getAttribute("name");
        if (!n)
            continue;
        if (n.indexOf("|") > 0) {
            n = n.substr(0, n.indexOf("|"));
        }
        elements[i].disabled = false;
        if (elements[i].getAttribute("type") == "text") {
            var scaleval = Response.value(n);
            formObj.LoadedValues[n] = scaleval;
            if (typeof(elements[i].getAttribute("scale")) == "string") {
                var scale = elements[i].getAttribute("scale")
                var exp = GetSIPrefixExponend(scale);
                scaleval *= Math.pow(10, exp * -1);
                scaleval = String(Math.runde(scaleval, 2));
            }
            //check if number:
            scaleval = String(scaleval); //convert
            if (scaleval.split(/\./) != null && scaleval.split(/\./).length >= 2)
                elements[i].value = scaleval;
            else
                elements[i].value = tlnum(scaleval);

        }
        if (elements[i].tagName == "SELECT") {
            elements[i].value = parseInt(Response.value(n));
            formObj.LoadedValues[n] = parseInt(Response.value(n));
        }

    }


}
var UMG510CHResponse;
function ConfigHelper_callback_507(responseText) {
    if (responseText.trim() != "" && responseText.indexOf(":") != -1)
        UMG510CHResponse.Buffer.push(responseText);
    if (--UMG510CHResponse.toGo == 0) {
        var newObjVar = transform510OutputToResponseInternalStructur(UMG510CHResponse.Buffer.join("~|$"))
        if (newObjVar != false && UMG510CHResponse.Buffer.length == UMG510CHResponse.FileList.length)
            ConfigHelper_callback(newObjVar, UMG510CHResponse.form);
    }
}
function ConfigHelper_LoadFormContent() {
    for (var j = 0; j < ConfigHelperInstances.length; j++) {
        if (ConfigHelperInstances[j].loaded)
            continue;
        //	var lastelementid = ConfigHelperInstances[i].id + ConfigHelperInstances[i].sysvars[ConfigHelperInstances[i]
        //.sysvars.length-1][0];
        if (document.getElementById(ConfigHelperInstances[j].id)) {
            clearInterval(ConfigHelperInstances[j].intervalID);
            ConfigHelperInstances[j].loaded = true;
            var form = document.getElementById(ConfigHelperInstances[j].id);
            var elements = form.getElementsByTagName("*");
            var VarList = new VarListBuilder();

            for (var i = 0; i < elements.length; i++) {

                if (typeof(elements[i]) == "undefined" || !elements[i].getAttribute)
                    continue;
                var n = elements[i].getAttribute("name");

                if (!UMG507)
                {
                    if (!n || n.charAt(0) != "_")
                        continue;
                    if (n.indexOf("|") > 0) {
                        n = n.substr(0, n.indexOf("|"));
                    }
                } else { // 507 doesnt start with _, ident sysvar by id check

                    if (!n)
                        continue;
                    if (!elements[i].id)
                        continue;
                    if (elements[i].id.indexOf(ConfigHelperInstances[j].id) != 0)
                        continue;
                }
                VarList.Add(n);
            }
            if (UMG510)
                LibError.Add("ConfigHelper not supported by UMG510!");
            if (!UMG507) {
                AjaxRequestProvider.RegisterRequest("/json.do?" + VarList.Build(), ConfigHelper_callback, form);
            } else {
                var fileList = VarList.Build510();
                UMG510CHResponse = {
                    "Buffer": [],
                    "toGo": fileList.length,
                    "form": form,
                    "FileList": fileList
                };
                for (var i in fileList) {
                    if (i in Array.prototype)
                        continue;
                    AjaxRequestProvider.RegisterRequest(uncache(fileList[i]), ConfigHelper_callback_507);
                }

            }

        }
    }
}

function ConfigHelper_Submit(id) {
    for (var i = 0; i < ConfigHelperInstances.length; i++) {
        if (ConfigHelperInstances[i].id == id) {
            ConfigHelperInstances[i].Submit();
            break;
        }
    }
    return false; //Stop normal Submit
}

var ConfigHelperLastErrorElement = null;
var NOHEADER = {
    "type": "ConfigHelperNoHeader"
};
function ConfigHelper(o) {
    this.NoHeader = false;
    for (var i = 0; i < ConfigHelper.arguments.length; i++) {
        if (ConfigHelper.arguments[i].type == NOHEADER.type)
            this.NoHeader = true;
    }
    this.id = "f" + createid(15);
    this.Table = new TableHelper();

    if (!this.NoHeader) {
        this.Table.AddRaw('<colgroup><col width=50%><col width=50%></colgroup>');
        this.Table.NewHeader();
        this.Table.AddCell(tl("info.var_desc"));
        this.Table.AddCell(tl("info.content_desc"));
    }
    this.s = '<form id="' + this.id + '" method="GET" name="confighelperform" accept-charset="ISO-8859-1" onSubmit="return ConfigHelper_Submit(\'' + this.id + '\')">';
    this.intervalID = setInterval("ConfigHelper_LoadFormContent('" + this.id + "')", 10);
    this.sysvars = new Array();
    this.loaded = false;
    this.LoadedValues = {};
    //Global list:
    ConfigHelperInstances.unshift(this);
}

function ConfigHelper_Submit_callback(response, form) {
    var ret = null;
    if (ret = response.match(/Error\s*(_[\w]*) = ([^\s]*) .*max\[(.*)\.\.([^\]]*)/)) {
        //console.log(ret)
    }

//	debugger;
    var Ident = "<br>Error";
    if (response.substr(0, Ident.length) == Ident) {
        // error detected, display:
        var desc;
        //"set _FIX_STAGES0 - no write permission\nhh".match(/set (_[\w]*) - (.*)/) 
        //match(/Error\s*(_[\w]*) = ([^\s]*) .*max\[(.*)\.\.([^\]]*)/)
        var sysStart = response.indexOf("_");
        var sysEnd = response.substring(sysStart).indexOf(" ");
        var descStart = response.substring(sysEnd).indexOf("=") + 1 + sysEnd;
        var descEnd = response.substring(descStart).indexOf("<br>");
        var sysvar = response.substr(sysStart, sysEnd);
        if (response.substring(sysStart).indexOf("=") > response.substring(sysStart).indexOf("<br>")) {
            desc = response.substr(sysStart + 1, response.substring(sysStart).indexOf("<br>") - 1);
        }
        else {
            desc = response.substr(descStart + 1, descEnd - 1);
        }
        form.element(sysvar).style.background = "#FFAAAA";
        form.element(sysvar).focus();
        ConfigHelperLastErrorElement = form.element(sysvar);
        overlib(tl("config.errorinfo") + "<br>" + desc, STICKY, MOUSEOFF, BGCOLOR, 'red', FGCOLOR, '#FFF7E2');

    }
    else {
        overlib(tl("config.transfer_success"), STICKY, MOUSEOFF, BGCOLOR, '8BFF5E', FGCOLOR, '#DEFFD1', TIMEOUT, 1200);

    }
}

function decToHex(dec) {
    var hexa = "0123456789ABCDEF";
    var hex = "";
    while (dec > 15) {
        tmp = dec - (Math.floor(dec / 16)) * 16;
        hex = hexa.charAt(tmp) + hex;
        dec = Math.floor(dec / 16);
    }
    hex = hexa.charAt(dec) + hex;
    if (hex.length == 1)
        hex = "0" + hex
    return(hex);
}

function toHex(decimal) {
    var hex = decimal.toString(16).toUpperCase();
    if (hex.length < 2) {
        hex = '0' + hex;
    }
    return hex;
}

function encodeISO(sIn) {
    var s = "";
    for (var i = 0; i < sIn.length; i++) {
        if (sIn.charCodeAt(i) >= 160)
            s += "%" + toHex(sIn.charCodeAt(i));
        else
            s += sIn.substr(i, 1);
    }
    return s;
}

ConfigHelper.prototype.Submit = function() {
    if (ConfigHelperLastErrorElement)
        ConfigHelperLastErrorElement.style.background = "";
    //1. Build RequestURI
    var RequestURI = "dummy.html";
    if (UMG507)
        RequestURI = ""; // use own site
    var form = document.getElementById(this.id);
    var elements = form.getElementsByTagName("*");
    var VarList = new VarListBuilder();
    var z = 0;
    for (var i = 0; i < elements.length; i++) {
        if (typeof(elements[i]) == "undefined" || !elements[i].getAttribute)
            continue;
        var n = elements[i].getAttribute("name");

        if (!UMG507)
        {
            if (!n || n.charAt(0) != "_")
                continue;
        } else { // 507 doesnt start with _, ident sysvar by id check
            if (!n)
                continue;
            if (!elements[i].id)
                continue;
            if (elements[i].id.indexOf(this.id) != 0)
                continue;
        }
        var id = elements[i].getAttribute("name");
        var value = tlToFloat(elements[i].value);
        if (typeof(elements[i].getAttribute("scale")) == "string")
        {
            var scale = elements[i].getAttribute("scale");
            var exp = GetSIPrefixExponend(scale);
            value = Math.runde(value * Math.pow(10, 1 * exp), 2);
        }
        var maybeWriteList = id.split("|");
        for (var idx in maybeWriteList) {
            if (idx in Array.prototype)
                continue;
            RequestURI += ((z++ == 0) ? '?' : '&') + (maybeWriteList[idx] + "=" + encodeISO(value));
        }

    }

    overlib(tl("config.data_transfer"), STICKY, MOUSEOFF, TIMEOUT, 2500);
    AjaxRequestProvider.RegisterRequest(RequestURI, ConfigHelper_Submit_callback, this);
}

TYPE = 0;
NAME = 1;
DESC = 2;
LENGTH = 3;
SELECTARRAY = 4;
CLASSNAME = 5;
SCALE = 6;

ConfigHelper.prototype.element = function(sysvarname) {
    var id = this.id + sysvarname.toUpperCase();
    var ret = document.getElementById(id);
    return ret;
}

CreateHTML = function(a) {
    switch (a[TYPE]) {
        case "Text":
            return '<input id="{FORM_ID}' + a[NAME] + '" type="text" size="' + a[LENGTH] + '" name="' + a[NAME] + '" value="" onmouseover="return overlib(\'' + a[DESC].replace(/'/ig, "\\'") + '\', DELAY, 500, WRAP);" onmouseout="return nd();" disabled ' + ((a[SCALE] != "") ? ' scale="' + a[SCALE] + '"' : "") + '>';
        case "DropDown":
            {
                var s = "";
                s += '<select id="{FORM_ID}' + a[NAME] + '" name="' + a[NAME] + '" size="' + a[LENGTH] + '" class="' + a[CLASSNAME] + '" onmouseover="return overlib(\'' + a[DESC].replace(/'/ig, "\\'") + '\', DELAY, 500, WRAP);" onmouseout="return nd();" disabled>';
                for (x in a[SELECTARRAY])
                    s += '<option value="' + x + '" >' + a[SELECTARRAY][x] + '</option>';
                s += '</select>';
                return s;
            }
    }
}

ConfigHelper.prototype.AddTitle = function(content) {
    this.addCellNextTime = "<b>" + content + "</b>";
}
ConfigHelper.prototype.AddSysvar = function(Name) {

    if (this.addCellNextTime) {
        this.Table.NewRow();
        this.Table.AddCell(this.addCellNextTime, {
            "colspan": "2"
        });
        this.addCellNextTime = null;
    }
    this.Table.NewRow();
    this.Table.AddCell(Name);
    var s = "";
    var ob = null;
    for (var i = 1; i < ConfigHelper.prototype.AddSysvar.arguments.length; ++i) {
        var tmp = ConfigHelper.prototype.AddSysvar.arguments[i];
        if (typeof(tmp) == "object") {
            ob = tmp;
            continue;
        }
        if (typeof(tmp) == "string")
            tmp = tmp.replace("{FORM_ID}", this.id);
        s += tmp;
    }

    this.Table.AddCell(s, ob);
}
ConfigHelper.prototype.NewRow = function() {
    this.Table.NewRow();
}
ConfigHelper.prototype.AddCell = function() {
    var s = "";
    var ob = null;
    for (var i = 0; i < ConfigHelper.prototype.AddCell.arguments.length; ++i) {
        var tmp = ConfigHelper.prototype.AddCell.arguments[i];
        if (typeof(tmp) == "object") {
            ob = tmp;
            continue;
        }
        if (typeof(tmp) == "string")
            tmp = tmp.replace("{FORM_ID}", this.id);
        s += tmp;
    }

    this.Table.AddCell(s, ob);
}
ConfigHelper.prototype.AddRow = function() {

    if (this.addCellNextTime) {
        this.Table.NewRow();
        this.Table.AddCell(this.addCellNextTime, {
            "colspan": "2"
        });
        this.addCellNextTime = null;
    }
    this.Table.NewRow();
    var s = "";
    var ob = null;
    for (var i = 0; i < ConfigHelper.prototype.AddRow.arguments.length; ++i) {
        var tmp = ConfigHelper.prototype.AddRow.arguments[i];
        if (typeof(tmp) == "object") {
            ob = tmp;
            continue;
        }
        if (typeof(tmp) == "string")
            tmp = tmp.replace("{FORM_ID}", this.id);
        s += tmp;
    }


    this.Table.AddCell(s, ob);
}
ConfigHelper.prototype.flush = function() {
    return this.s + this.Table.flush() + "</form>";
}

ConfigHelper.prototype.AddSubmit = function(subName) {
    this.Table.NewRow();
    this.Table.AddCell('<input type="submit" value="' + subName + '">', {
        "colspan": "2"
    });
}
function SysvarText(name, length, desc) {
    var regexret = name.match(/(.*)%SCALE\|([a-zA-Z])%/)
    if (regexret) {
        name = regexret[1];
    }
    if (!UMG507) {
        name = name.toUpperCase();
    }
    return CreateHTML(new Array("Text", name, desc, length, null, "", ((regexret) ? regexret[2] : "")));
}

var TRANSLATE = "trans"; // className for select
function SysvarSelect(name, length, SelectArray, desc, translate) {
    if (!UMG507)
        name = name.toUpperCase();
    return CreateHTML(new Array("DropDown", name, desc, length, SelectArray, translate));
}

function Text(s) {
    return s;
}

ConfigHelper.prototype.getChangedObjs = function() {

    var list = [];
    var elements = ById(this.id).getElementsByTagName("*");

    for (var i = 0; i < elements.length; i++) {
        if (typeof(elements[i]) == "undefined" || !elements[i].getAttribute)
            continue;
        var n = elements[i].getAttribute("name");
        if (!n)
            continue;
        if (n.indexOf("|") > 0) {
            n = n.substr(0, n.indexOf("|"));
        }

        if (elements[i].getAttribute("type") == "text") {
            var value = elements[i].value;
            if (!isNaN(parseInt(value)))
                value = tlToFloat(value);
            if (typeof(elements[i].getAttribute("scale")) == "string")
            {
                var scale = elements[i].getAttribute("scale");
                var exp = GetSIPrefixExponend(scale);
                value = Math.runde(value * Math.pow(10, 1 * exp), 2);
            }
            if (value != this.LoadedValues[n])
                list.unshift(elements[i]);

        }
        if (elements[i].tagName == "SELECT") {
            if (elements[i].value != this.LoadedValues[n])
                list.unshift(elements[i]);
        }

    }

    return list;
}
ConfigHelper.prototype.hasChanged = function() {
    return this.getChangedObjs().length != 0;
}
///////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////
// Std. Menu for Data-Tables 
function hasClass(a, s) {
    var ar = a.split(" ");
    for (var i in ar) {
        if (ar[i] == s)
            return true;
    }
    return false;
}

function StdMenuCallback(item) {
    if (item.id == ID_AUTOUPDATE) {
        if (!sysvar_loaded) {
            item.checked = false;
            alert(tl("autoupdate.wait"));
            return false;
        }

        var i = 0;
        var spans = item.parent.eventSource.getElementsByTagName("span");
        for (var z = 0; z < spans.length; z++) {
            if (!spans[z] || typeof(spans[z].className) == "undefined")
                continue;

            var type = containsMarker(spans[z].className);
            if (type == "sysvar" || type == "autoupdate") {
                spans[z].className = (item.checked) ? "autoupdate" : "sysvar";
                i++;
            }
        }

        AutoUpdateRescan();

        return true;
    }
    var spans = item.parent.eventSource.getElementsByTagName("span");
    var ResetVarlist = new VarListBuilder();
    var i = 0;
    for (var z = 0; z < spans.length; z++) {
        if (!spans[z] || typeof(spans[z].className) == "undefined")
            continue;
        var type = containsMarker(spans[z].className);
        if (type == "sysvar" || type == "autoupdate") {
            var name = spans[z].getAttribute("name");
            if (!UMG510)
                name = name.toUpperCase();
            var ResetValue = 0;
            if (item.id == ID_DELMIN) {
                if (name.indexOf("_MIN") > 0)
                    ResetVarlist.Add(name);
                ResetValue = UMG_MAX_INT;
            }
            if (item.id == ID_DELMAX) {
                if (name.indexOf("_MAX") > 0 && name.indexOf("_AVG") < 0)
                    ResetVarlist.Add(name);
            }
            if (item.id == ID_DELAVGMAX) {
                if (name.indexOf("_AVG_MAX") > 0)
                    ResetVarlist.Add(name);
            }

        }
        i++;
    }
    var url_action = ResetVarlist.Build() + "=" + ResetValue;
    // BUG: _N_MIN,_M_MIN = MAX_INT, Solution: Comma (insert MAXINT)=> =MAXINT,
    url_action = url_action.replace(/,/ig, "=" + ResetValue + "&");
    AjaxRequestProvider.RegisterRequest(uncache("/dummy.html?" + url_action), null, "");
    //defer update 
    window.setTimeout("SysvarWorker();", 300);
    return true;
}

var ID_AUTOUPDATE = 1;
var ID_DELMIN = 2;
var ID_DELMAX = 3;
var ID_DELAVGMAX = 4;
var _stdMenu = null;
function GetStdTableMenu() {
    //Delayed init cause of tl function need LangXX.js
    if (_stdMenu != null)
        delete _stdMenu;
    _stdMenu = new CMenu(StdMenuCallback);
    _stdMenu.AddCheck(ID_AUTOUPDATE, tl("cmenu.autoupdate"), false);
    _stdMenu.AddSeperator();
    _stdMenu.AddButton(ID_DELMIN, tl("cmenu.delmin"), "img/menu_min.png");
    _stdMenu.AddButton(ID_DELMAX, tl("cmenu.delmax"), "img/menu_max.png");
    _stdMenu.AddButton(ID_DELAVGMAX, tl("cmenu.delavgmax"), "img/menu_avgmax.png");
    return _stdMenu;

}

///////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
var timeout = -1;
function slide(dir, _obj) {
    timeout = -1;

    var objname = _obj.getAttribute("name");
    var objid = objname.substr(4)
    var obj = ById(objid);
    var val = parseFloat(tlToFloat(obj.value));
    var inc = parseFloat(obj.getAttribute("inc"));
    var min = parseFloat(obj.getAttribute("min"));
    var max = parseFloat(obj.getAttribute("max"));
    if (dir == "up")
        val += inc;
    else
        val -= inc;
    if (!isNaN(min))
        if (val < min)
            val = min;
    if (!isNaN(max))
        if (val > max)
            val = max;
    obj.value = tlnum(Math.frunde(val, 2));

    if (_obj.getAttribute("time") == "1")
        timeout = setTimeout(function() {
            slide(dir, _obj);
        }, 250);
}

function slide_start(dir, obj) {

    obj.setAttribute("time", "1")
    slide(dir, obj);

}

function slide_stop(obj) {
    //removeEvent( obj.parentNode, "mousemove");
    if (timeout != -1)
        clearTimeout(timeout);
    obj.setAttribute("time", "0")
}

function slide_mmove(evt) {
    evt = (evt) ? evt : ((window.event) ? window.event : "");
    var elem = (evt.target) ? evt.target : evt.srcElement;

    if (elem.tagName == "DIV") {
        elem.setAttribute("time", "0")
        //removeEvent( elem, "mousemove");
        if (timeout != -1)
            clearTimeout(timeout);
    }

}

function AddSlider(id, inc) {

    if (typeof(inc) == "undefined")
        inc = 1;
    var edit = ById(id);
    edit.setAttribute("inc", inc);
    edit.style.cssFloat = "left"
    var kapsel = document.createElement("div");
    kapsel.style.cssFloat = "left";
    kapsel.style.padding = "1px";
    kapsel.style.paddingLeft = "3px";
    kapsel.style.paddingRight = "3px";

    var up = document.createElement("a");
    up.href = "#";
    up.onclick = function() {
        return false;
    };

    up.onmousedown = function() {
        slide_start('up', this);
    };
    up.onmouseup = function() {
        slide_stop(this);
    };
    up.className = "slider_up";
    up.innerHTML = "";
    up.name = "upup" + id; //! 4chars, s. silde
    var down = document.createElement("a");
    down.href = "#";
    down.onclick = function() {
        return false;
    };
    down.onmousedown = function() {
        slide_start('down', this);
    };
    down.onmouseup = function() {
        slide_stop(this);
    };
    down.className = "slider_down";
    down.innerHTML = "";
    down.name = "down" + id;

    kapsel.appendChild(up);
    kapsel.appendChild(down);
    addEvent(kapsel, "mousemove", slide_mmove);
    edit.parentNode.insertBefore(kapsel, edit.nextSibling);


}

/////////////////////////////////////////////////////////////////////////////
var Varlist507 = {"an_conmin_2": 0, "an_consum_2": 0, "an_cont_2": 0, "an_gen_2": 0, "an_prio_2": 0, "ana_041": 0, "ana_042": 0, "ana_para1": 0, "ana_para2": 0, "ana_val01": 0, "ana_val02": 0, "ana_val11": 0, "ana_val12": 0, "analog_t": 0, "anlo_in": 0, "anlo_in_max": 0, "anlo_in_min": 0, "anlo_out1": 0, "anlo_out2": 0, "br_com0": 0, "challenge": 0, "cmp_dw0_1": 0, "cmp_dw0_10": 0, "cmp_dw0_11": 0, "cmp_dw0_12": 0, "cmp_dw0_13": 0, "cmp_dw0_14": 0, "cmp_dw0_15": 0, "cmp_dw0_16": 0, "cmp_dw0_2": 0, "cmp_dw0_3": 0, "cmp_dw0_4": 0, "cmp_dw0_5": 0, "cmp_dw0_6": 0, "cmp_dw0_7": 0, "cmp_dw0_8": 0, "cmp_dw0_9": 0, "cmp_dw1_1": 0, "cmp_dw1_10": 0, "cmp_dw1_11": 0, "cmp_dw1_12": 0, "cmp_dw1_13": 0, "cmp_dw1_14": 0, "cmp_dw1_15": 0, "cmp_dw1_16": 0, "cmp_dw1_2": 0, "cmp_dw1_3": 0, "cmp_dw1_4": 0, "cmp_dw1_5": 0, "cmp_dw1_6": 0, "cmp_dw1_7": 0, "cmp_dw1_8": 0, "cmp_dw1_9": 0, "cmp_par_1": 0, "cmp_par_10": 0, "cmp_par_11": 0, "cmp_par_12": 0, "cmp_par_13": 0, "cmp_par_14": 0, "cmp_par_15": 0, "cmp_par_16": 0, "cmp_par_2": 0, "cmp_par_3": 0, "cmp_par_4": 0, "cmp_par_5": 0, "cmp_par_6": 0, "cmp_par_7": 0, "cmp_par_8": 0, "cmp_par_9": 0, "cmp_pre_1": 0, "cmp_pre_10": 0, "cmp_pre_11": 0, "cmp_pre_12": 0, "cmp_pre_13": 0, "cmp_pre_14": 0, "cmp_pre_15": 0, "cmp_pre_16": 0, "cmp_pre_2": 0, "cmp_pre_3": 0, "cmp_pre_4": 0, "cmp_pre_5": 0, "cmp_pre_6": 0, "cmp_pre_7": 0, "cmp_pre_8": 0, "cmp_pre_9": 0, "cmp_tail_1": 0, "cmp_tail_10": 0, "cmp_tail_11": 0, "cmp_tail_12": 0, "cmp_tail_13": 0, "cmp_tail_14": 0, "cmp_tail_15": 0, "cmp_tail_16": 0, "cmp_tail_2": 0, "cmp_tail_3": 0, "cmp_tail_4": 0, "cmp_tail_5": 0, "cmp_tail_6": 0, "cmp_tail_7": 0, "cmp_tail_8": 0, "cmp_tail_9": 0, "cmp_up0_1": 0, "cmp_up0_10": 0, "cmp_up0_11": 0, "cmp_up0_12": 0, "cmp_up0_13": 0, "cmp_up0_14": 0, "cmp_up0_15": 0, "cmp_up0_16": 0, "cmp_up0_2": 0, "cmp_up0_3": 0, "cmp_up0_4": 0, "cmp_up0_5": 0, "cmp_up0_6": 0, "cmp_up0_7": 0, "cmp_up0_8": 0, "cmp_up0_9": 0, "cmp_up1_1": 0, "cmp_up1_10": 0, "cmp_up1_11": 0, "cmp_up1_12": 0, "cmp_up1_13": 0, "cmp_up1_14": 0, "cmp_up1_15": 0, "cmp_up1_16": 0, "cmp_up1_2": 0, "cmp_up1_3": 0, "cmp_up1_4": 0, "cmp_up1_5": 0, "cmp_up1_6": 0, "cmp_up1_7": 0, "cmp_up1_8": 0, "cmp_up1_9": 0, "consum_1": 0, "consum_10": 0, "consum_11": 0, "consum_12": 0, "consum_13": 0, "consum_14": 0, "consum_15": 0, "consum_16": 0, "consum_2": 0, "consum_3": 0, "consum_4": 0, "consum_5": 0, "consum_6": 0, "consum_7": 0, "consum_8": 0, "consum_9": 0, "cosP1_t": 0, "cosP2_t": 0, "cosP3_t": 0, "cos_sum_t": 0, "ctpri": 0, "ctpri":0, "ctsec": 0, "dev_mode": 0, "devdesc": 0, "dft_value11_i1_t": 0, "dft_value11_i2_t": 0, "dft_value11_i3_t": 0, "dft_value11_u1_t": 0, "dft_value11_u2_t": 0, "dft_value11_u3_t": 0, "dft_value13_i1_t": 0, "dft_value13_i2_t": 0, "dft_value13_i3_t": 0, "dft_value13_u1_t": 0, "dft_value13_u2_t": 0, "dft_value13_u3_t": 0, "dft_value15_i1_t": 0, "dft_value15_i2_t": 0, "dft_value15_i3_t": 0, "dft_value15_u1_t": 0, "dft_value15_u2_t": 0, "dft_value15_u3_t": 0, "dft_value1_i1_t": 0, "dft_value1_i2_t": 0, "dft_value1_i3_t": 0, "dft_value1_u1_t": 0, "dft_value1_u2_t": 0, "dft_value1_u3_t": 0, "dft_value3_i1_t": 0, "dft_value3_i2_t": 0, "dft_value3_i3_t": 0, "dft_value3_u1_t": 0, "dft_value3_u2_t": 0, "dft_value3_u3_t": 0, "dft_value5_i1_t": 0, "dft_value5_i2_t": 0, "dft_value5_i3_t": 0, "dft_value5_u1_t": 0, "dft_value5_u2_t": 0, "dft_value5_u3_t": 0, "dft_value7_i1_t": 0, "dft_value7_i2_t": 0, "dft_value7_i3_t": 0, "dft_value7_u1_t": 0, "dft_value7_u2_t": 0, "dft_value7_u3_t": 0, "dft_value9_i1_t": 0, "dft_value9_i2_t": 0, "dft_value9_i3_t": 0, "dft_value9_u1_t": 0, "dft_value9_u2_t": 0, "dft_value9_u3_t": 0, "dgout_st1": 0, "dgout_st2": 0, "dgout_st3": 0, "dgout_st4": 0, "dgout_st5": 0, "dgout_st6": 0, "digin0": 0, "digin1": 0, "digin2": 0, "digin3": 0, "digin4": 0, "digin5": 0, "digin_c1": 0, "digin_c2": 0, "digin_c3": 0, "digin_c4": 0, "digin_c5": 0, "digin_c6": 0, "digout0": 0, "digout1": 0, "digout2": 0, "digout3": 0, "digout4": 0, "digout5": 1, "em_avbl1": 1, "em_avbl10": 1, "em_avbl11": 1, "em_avbl12": 1, "em_avbl13": 1, "em_avbl14": 1, "em_avbl15": 1, "em_avbl16": 1, "em_avbl2": 1, "em_avbl3": 1, "em_avbl4": 1, "em_avbl5": 1, "em_avbl6": 1, "em_avbl7": 1, "em_avbl8": 1, "em_avbl9": 1, "em_inv_con": 1, "em_lock_t": 1, "em_para": 1, "em_pause_t": 1, "em_soll_1": 1, "em_soll_2": 1, "em_soll_3": 1, "em_soll_4": 1, "em_soll_5": 1, "em_trest": 1, "fl1": 1, "fl1max": 1, "fl1min": 1, "frequenz_t": 1, "g_t": 1, "gen_vor_2": 1, "i1_t": 1, "i1dft1": 1, "i1dft11": 1, "i1dft13": 1, "i1dft15": 1, "i1dft3": 1, "i1dft5": 1, "i1dft7": 1, "i1dft9": 1, "i1dftm1": 1, "i1dftm11": 1, "i1dftm13": 1, "i1dftm15": 1, "i1dftm3": 1, "i1dftm5": 1, "i1dftm7": 1, "i1dftm9": 1, "i1dfts1": 1, "i1dfts11": 1, "i1dfts13": 1, "i1dfts15": 1, "i1dfts3": 1, "i1dfts5": 1, "i1dfts7": 1, "i1dfts9": 1, "i2_t": 1, "i2dft1": 1, "i2dft11": 1, "i2dft13": 1, "i2dft15": 1, "i2dft3": 1, "i2dft5": 1, "i2dft7": 1, "i2dft9": 1, "i2dftm1": 1, "i2dftm11": 1, "i2dftm13": 1, "i2dftm15": 1, "i2dftm3": 1, "i2dftm5": 1, "i2dftm7": 1, "i2dftm9": 1, "i2dfts1": 1, "i2dfts11": 1, "i2dfts13": 1, "i2dfts15": 1, "i2dfts3": 1, "i2dfts5": 1, "i2dfts7": 1, "i2dfts9": 1, "i3_t": 1, "i3dft1": 1, "i3dft11": 1, "i3dft13": 1, "i3dft15": 1, "i3dft3": 1, "i3dft5": 1, "i3dft7": 1, "i3dft9": 1, "i3dftm1": 1, "i3dftm11": 1, "i3dftm13": 1, "i3dftm15": 1, "i3dftm3": 1, "i3dftm5": 1, "i3dftm7": 1, "i3dftm9": 1, "i3dfts1": 1, "i3dfts11": 1, "i3dfts13": 1, "i3dfts15": 1, "i3dfts3": 1, "i3dfts5": 1, "i3dfts7": 1, "i3dfts9": 1, "il1": 1, "il1max": 1, "il1s": 1, "il2": 1, "il2max": 1, "il2s": 1, "il3": 1, "il3max": 1, "il3s": 1, "in_t": 1, "int_av_1": 1, "int_av_2": 1, "int_av_3": 1, "int_av_4": 1, "int_av_5": 1, "int_av_6": 1, "int_n_1": 1, "int_n_2": 1, "int_n_3": 1, "int_n_4": 1, "int_n_5": 1, "int_n_6": 1, "int_par_1": 1, "int_par_2": 1, "int_par_3": 1, "int_par_4": 1, "int_par_5": 1, "int_par_6": 1, "int_s_1": 1, "int_s_2": 1, "int_s_3": 1, "int_s_4": 1, "int_s_5": 1, "int_s_6": 1, "irated": 1, "is": 1, "ismax": 1, "iss": 1, "kfact1_t": 1, "kfact2_t": 1, "kfact3_t": 1, "kfactl1": 1, "kfactl2": 1, "kfactl3": 1, "kfactmax1": 1, "kfactmax2": 1, "kfactmax3": 1, "lpage": 1, "m_t": 1, "mailauthc": 1, "mailpass": 1, "mailsrv": 1, "mailusr": 1, "maxaus_1": 1, "maxaus_10": 1, "maxaus_11": 1, "maxaus_12": 1, "maxaus_13": 1, "maxaus_14": 1, "maxaus_15": 1, "maxaus_16": 1, "maxaus_2": 1, "maxaus_3": 1, "maxaus_4": 1, "maxaus_5": 1, "maxaus_6": 1, "maxaus_7": 1, "maxaus_8": 1, "maxaus_9": 1, "mbbc1": 1, "mbbc10": 1, "mbbc11": 1, "mbbc12": 1, "mbbc13": 1, "mbbc14": 1, "mbbc15": 1, "mbbc16": 1, "mbbc17": 1, "mbbc18": 1, "mbbc19": 1, "mbbc2": 1, "mbbc20": 1, "mbbc21": 1, "mbbc22": 1, "mbbc23": 1, "mbbc24": 1, "mbbc25": 1, "mbbc26": 1, "mbbc27": 1, "mbbc28": 1, "mbbc29": 1, "mbbc3": 1, "mbbc30": 1, "mbbc31": 1, "mbbc32": 1, "mbbc4": 1, "mbbc5": 1, "mbbc6": 1, "mbbc7": 1, "mbbc8": 1, "mbbc9": 1, "mbdesad1": 1, "mbdesad10": 1, "mbdesad11": 1, "mbdesad12": 1, "mbdesad13": 1, "mbdesad14": 1, "mbdesad15": 1, "mbdesad16": 1, "mbdesad17": 1, "mbdesad18": 1, "mbdesad19": 1, "mbdesad2": 1, "mbdesad20": 1, "mbdesad21": 1, "mbdesad22": 1, "mbdesad23": 1, "mbdesad24": 1, "mbdesad25": 1, "mbdesad26": 1, "mbdesad27": 1, "mbdesad28": 1, "mbdesad29": 2, "mbdesad3": 2, "mbdesad30": 2, "mbdesad31": 2, "mbdesad32": 2, "mbdesad4": 2, "mbdesad5": 2, "mbdesad6": 2, "mbdesad7": 2, "mbdesad8": 2, "mbdesad9": 2, "mbdesidx1": 2, "mbdesidx10": 2, "mbdesidx11": 2, "mbdesidx12": 2, "mbdesidx13": 2, "mbdesidx14": 2, "mbdesidx15": 2, "mbdesidx16": 2, "mbdesidx17": 2, "mbdesidx18": 2, "mbdesidx19": 2, "mbdesidx2": 2, "mbdesidx20": 2, "mbdesidx21": 2, "mbdesidx22": 2, "mbdesidx23": 2, "mbdesidx24": 2, "mbdesidx25": 2, "mbdesidx26": 2, "mbdesidx27": 2, "mbdesidx28": 2, "mbdesidx29": 2, "mbdesidx3": 2, "mbdesidx30": 2, "mbdesidx31": 2, "mbdesidx32": 2, "mbdesidx4": 2, "mbdesidx5": 2, "mbdesidx6": 2, "mbdesidx7": 2, "mbdesidx8": 2, "mbdesidx9": 2, "mbdestp1": 2, "mbdestp10": 2, "mbdestp11": 2, "mbdestp12": 2, "mbdestp13": 2, "mbdestp14": 2, "mbdestp15": 2, "mbdestp16": 2, "mbdestp17": 2, "mbdestp18": 2, "mbdestp19": 2, "mbdestp2": 2, "mbdestp20": 2, "mbdestp21": 2, "mbdestp22": 2, "mbdestp23": 2, "mbdestp24": 2, "mbdestp25": 2, "mbdestp26": 2, "mbdestp27": 2, "mbdestp28": 2, "mbdestp29": 2, "mbdestp3": 2, "mbdestp30": 2, "mbdestp31": 2, "mbdestp32": 2, "mbdestp4": 2, "mbdestp5": 2, "mbdestp6": 2, "mbdestp7": 2, "mbdestp8": 2, "mbdestp9": 2, "mblen1": 2, "mblen10": 2, "mblen11": 2, "mblen12": 2, "mblen13": 2, "mblen14": 2, "mblen15": 2, "mblen16": 2, "mblen17": 2, "mblen18": 2, "mblen19": 2, "mblen2": 2, "mblen20": 2, "mblen21": 2, "mblen22": 2, "mblen23": 2, "mblen24": 2, "mblen25": 2, "mblen26": 2, "mblen27": 2, "mblen28": 2, "mblen29": 2, "mblen3": 2, "mblen30": 2, "mblen31": 2, "mblen32": 2, "mblen4": 2, "mblen5": 2, "mblen6": 2, "mblen7": 2, "mblen8": 2, "mblen9": 2, "mbscrad1": 2, "mbscrad10": 2, "mbscrad11": 2, "mbscrad12": 2, "mbscrad13": 2, "mbscrad14": 2, "mbscrad15": 2, "mbscrad16": 2, "mbscrad17": 2, "mbscrad18": 2, "mbscrad19": 2, "mbscrad2": 2, "mbscrad20": 2, "mbscrad21": 2, "mbscrad22": 2, "mbscrad23": 2, "mbscrad24": 2, "mbscrad25": 2, "mbscrad26": 2, "mbscrad27": 2, "mbscrad28": 2, "mbscrad29": 2, "mbscrad3": 2, "mbscrad30": 2, "mbscrad31": 2, "mbscrad32": 2, "mbscrad4": 2, "mbscrad5": 2, "mbscrad6": 2, "mbscrad7": 2, "mbscrad8": 2, "mbscrad9": 2, "mbscridx1": 2, "mbscridx10": 2, "mbscridx11": 2, "mbscridx12": 2, "mbscridx13": 2, "mbscridx14": 2, "mbscridx15": 2, "mbscridx16": 2, "mbscridx17": 2, "mbscridx18": 2, "mbscridx19": 2, "mbscridx2": 2, "mbscridx20": 2, "mbscridx21": 2, "mbscridx22": 2, "mbscridx23": 2, "mbscridx24": 2, "mbscridx25": 2, "mbscridx26": 2, "mbscridx27": 2, "mbscridx28": 2, "mbscridx29": 2, "mbscridx3": 2, "mbscridx30": 2, "mbscridx31": 2, "mbscridx32": 2, "mbscridx4": 2, "mbscridx5": 2, "mbscridx6": 2, "mbscridx7": 2, "mbscridx8": 2, "mbscridx9": 2, "mbscrtp1": 2, "mbscrtp10": 2, "mbscrtp11": 2, "mbscrtp12": 2, "mbscrtp13": 2, "mbscrtp14": 2, "mbscrtp15": 2, "mbscrtp16": 2, "mbscrtp17": 2, "mbscrtp18": 2, "mbscrtp19": 2, "mbscrtp2": 2, "mbscrtp20": 2, "mbscrtp21": 2, "mbscrtp22": 2, "mbscrtp23": 2, "mbscrtp24": 2, "mbscrtp25": 2, "mbscrtp26": 2, "mbscrtp27": 2, "mbscrtp28": 2, "mbscrtp29": 2, "mbscrtp3": 2, "mbscrtp30": 2, "mbscrtp31": 2, "mbscrtp32": 2, "mbscrtp4": 2, "mbscrtp5": 2, "mbscrtp6": 2, "mbscrtp7": 2, "mbscrtp8": 2, "mbscrtp9": 2, "mbusmast_to": 2, "mbusmode": 2, "mdata_1": 2, "mdata_10": 2, "mdata_2": 2, "mdata_3": 2, "mdata_4": 2, "mdata_5": 2, "mdata_6": 2, "mdata_7": 2, "mdata_8": 2, "mdata_9": 2, "mfrom": 2, "minaus_1": 2, "minaus_10": 2, "minaus_11": 2, "minaus_12": 2, "minaus_13": 2, "minaus_14": 2, "minaus_15": 2, "minaus_16": 2, "minaus_2": 2, "minaus_3": 2, "minaus_4": 2, "minaus_5": 2, "minaus_6": 2, "minaus_7": 2, "minaus_8": 3, "minaus_9": 3, "minein_1": 3, "minein_10": 3, "minein_11": 3, "minein_12": 3, "minein_13": 3, "minein_14": 3, "minein_15": 3, "minein_16": 3, "minein_2": 3, "minein_3": 3, "minein_4": 3, "minein_5": 3, "minein_6": 3, "minein_7": 3, "minein_8": 3, "minein_9": 3, "n_t": 3, "op_lg_1": 3, "op_lg_2": 3, "op_lg_3": 3, "op_lg_4": 3, "op_lg_5": 3, "op_lg_6": 3, "op_pa1_1": 3, "op_pa1_2": 3, "op_pa1_3": 3, "op_pa1_4": 3, "op_pa1_5": 3, "op_pa1_6": 3, "op_pa2_1": 3, "op_pa2_2": 3, "op_pa2_3": 3, "op_pa2_4": 3, "op_pa2_5": 3, "op_pa2_6": 3, "op_val_1": 3, "op_val_2": 3, "op_val_3": 3, "op_val_4": 3, "op_val_5": 3, "op_val_6": 3, "outdest_1": 3, "outdest_10": 3, "outdest_11": 3, "outdest_12": 3, "outdest_13": 3, "outdest_14": 3, "outdest_15": 3, "outdest_16": 3, "outdest_17": 3, "outdest_18": 3, "outdest_19": 3, "outdest_2": 3, "outdest_20": 3, "outdest_21": 3, "outdest_22": 3, "outdest_23": 3, "outdest_24": 3, "outdest_25": 3, "outdest_26": 3, "outdest_27": 3, "outdest_28": 3, "outdest_29": 3, "outdest_3": 3, "outdest_30": 3, "outdest_31": 3, "outdest_32": 3, "outdest_33": 3, "outdest_34": 3, "outdest_35": 3, "outdest_36": 3, "outdest_37": 3, "outdest_38": 3, "outdest_39": 3, "outdest_4": 3, "outdest_40": 3, "outdest_41": 3, "outdest_42": 3, "outdest_43": 3, "outdest_44": 3, "outdest_45": 3, "outdest_46": 3, "outdest_47": 3, "outdest_48": 3, "outdest_49": 3, "outdest_5": 3, "outdest_50": 3, "outdest_51": 3, "outdest_52": 3, "outdest_53": 3, "outdest_54": 3, "outdest_55": 3, "outdest_56": 3, "outdest_57": 3, "outdest_58": 3, "outdest_59": 3, "outdest_6": 3, "outdest_60": 3, "outdest_61": 3, "outdest_62": 3, "outdest_63": 3, "outdest_64": 3, "outdest_7": 3, "outdest_8": 3, "outdest_9": 3, "outsrc_1": 3, "outsrc_10": 3, "outsrc_11": 3, "outsrc_12": 3, "outsrc_13": 3, "outsrc_14": 3, "outsrc_15": 3, "outsrc_16": 3, "outsrc_17": 3, "outsrc_18": 3, "outsrc_19": 3, "outsrc_2": 3, "outsrc_20": 3, "outsrc_21": 3, "outsrc_22": 3, "outsrc_23": 3, "outsrc_24": 3, "outsrc_25": 3, "outsrc_26": 3, "outsrc_27": 3, "outsrc_28": 3, "outsrc_29": 3, "outsrc_3": 3, "outsrc_30": 3, "outsrc_31": 3, "outsrc_32": 3, "outsrc_33": 3, "outsrc_34": 3, "outsrc_35": 3, "outsrc_36": 3, "outsrc_37": 3, "outsrc_38": 3, "outsrc_39": 3, "outsrc_4": 3, "outsrc_40": 3, "outsrc_41": 3, "outsrc_42": 3, "outsrc_43": 3, "outsrc_44": 3, "outsrc_45": 3, "outsrc_46": 3, "outsrc_47": 3, "outsrc_48": 3, "outsrc_49": 3, "outsrc_5": 3, "outsrc_50": 3, "outsrc_51": 3, "outsrc_52": 3, "outsrc_53": 3, "outsrc_54": 3, "outsrc_55": 3, "outsrc_56": 3, "outsrc_57": 3, "outsrc_58": 3, "outsrc_59": 3, "outsrc_6": 3, "outsrc_60": 3, "outsrc_61": 3, "outsrc_62": 3, "outsrc_63": 3, "outsrc_64": 3, "outsrc_7": 3, "outsrc_8": 3, "outsrc_9": 3, "outtype_1": 3, "outtype_10": 3, "outtype_11": 3, "outtype_12": 3, "outtype_13": 3, "outtype_14": 3, "outtype_15": 3, "outtype_16": 3, "outtype_17": 3, "outtype_18": 3, "outtype_19": 3, "outtype_2": 3, "outtype_20": 3, "outtype_21": 3, "outtype_22": 3, "outtype_23": 3, "outtype_24": 3, "outtype_25": 3, "outtype_26": 3, "outtype_27": 3, "outtype_28": 3, "outtype_29": 3, "outtype_3": 3, "outtype_30": 3, "outtype_31": 3, "outtype_32": 3, "outtype_33": 3, "outtype_34": 3, "outtype_35": 3, "outtype_36": 3, "outtype_37": 3, "outtype_38": 3, "outtype_39": 3, "outtype_4": 3, "outtype_40": 3, "outtype_41": 3, "outtype_42": 3, "outtype_43": 3, "outtype_44": 3, "outtype_45": 3, "outtype_46": 3, "outtype_47": 3, "outtype_48": 3, "outtype_49": 3, "outtype_5": 3, "outtype_50": 3, "outtype_51": 3, "outtype_52": 3, "outtype_53": 3, "outtype_54": 3, "outtype_55": 3, "outtype_56": 3, "outtype_57": 3, "outtype_58": 3, "outtype_59": 3, "outtype_6": 3, "outtype_60": 3, "outtype_61": 3, "outtype_62": 3, "outtype_63": 4, "outtype_64": 4, "outtype_7": 4, "outtype_8": 4, "outtype_9": 4, "p1_t": 4, "p2_t": 4, "p3_t": 4, "p_sum_t": 4, "p_valin1": 4, "p_valin2": 4, "p_valin3": 4, "p_valin4": 4, "p_valin5": 4, "p_valin6": 4, "phil1": 4, "phil1max": 4, "phil1min": 4, "phil2": 4, "phil2max": 4, "phil2min": 4, "phil3": 4, "phil3max": 4, "phil3min": 4, "pl1": 4, "pl1max": 4, "pl2": 4, "pl2max": 4, "pl3": 4, "pl3max": 4, "prate_1": 4, "prate_2": 4, "prate_3": 4, "prate_4": 4, "prate_5": 4, "prate_6": 4, "prio_1": 4, "prio_10": 4, "prio_11": 4, "prio_12": 4, "prio_13": 4, "prio_14": 4, "prio_15": 4, "prio_16": 4, "prio_2": 4, "prio_3": 4, "prio_4": 4, "prio_5": 4, "prio_6": 4, "prio_7": 4, "prio_8": 4, "prio_9": 4, "pval_1": 4, "pval_2": 4, "pval_3": 4, "pval_4": 4, "pval_5": 4, "pval_6": 4, "pwidth": 4, "pwork_1": 4, "pwork_2": 4, "pwork_3": 4, "pwork_4": 4, "pwork_5": 4, "pwork_6": 4, "q1_t": 4, "q2_t": 4, "q3_t": 4, "q_sum_t": 4, "qh0": 4, "qh1": 4, "qh2": 4, "qh3": 4, "qh4": 4, "qh_storre_t_0": 4, "qh_storre_t_0":4, "qh_storre_t_1": 4, "qh_storre_t_1":4, "qh_storre_t_2": 4, "qh_storre_t_2":4, "qh_storre_t_3": 4, "qh_storre_t_3":4, "qh_storre_t_4": 4, "qh_storre_t_4":4, "qhc0": 4, "qhc1": 4, "qhc2": 4, "qhc3": 4, "qhc4": 4, "qhc_storre_t_0": 4, "qhc_storre_t_0":4, "qhc_storre_t_1": 4, "qhc_storre_t_1":4, "qhc_storre_t_2": 4, "qhc_storre_t_2":4, "qhc_storre_t_3": 4, "qhc_storre_t_3":4, "qhc_storre_t_4": 4, "qhc_storre_t_4":4, "qhi0": 4, "qhi1": 4, "qhi2": 4, "qhi3": 4, "qhi4": 4, "qhi_storre_t_0": 4, "qhi_storre_t_0":4, "qhi_storre_t_1": 4, "qhi_storre_t_1":4, "qhi_storre_t_2": 4, "qhi_storre_t_2":4, "qhi_storre_t_3": 4, "qhi_storre_t_3":4, "qhi_storre_t_4": 4, "qhi_storre_t_4":4, "ql1": 4, "ql1max": 4, "ql2": 4, "ql2max": 4, "ql3": 4, "ql3max": 4, "recip_1": 4, "recip_10": 4, "recip_2": 4, "recip_3": 4, "recip_4": 4, "recip_5": 4, "recip_6": 4, "recip_7": 4, "recip_8": 4, "recip_9": 4, "s0_power_t_1": 4, "s0_power_t_2": 4, "s0_power_t_3": 4, "s0_power_t_4": 4, "s0_power_t_5": 4, "s0_power_t_6": 4, "sanlo_in": 4, "sclk_doff11": 4, "sclk_doff110": 4, "sclk_doff12": 4, "sclk_doff13": 4, "sclk_doff14": 4, "sclk_doff15": 4, "sclk_doff16": 4, "sclk_doff17": 4, "sclk_doff18": 4, "sclk_doff19": 4, "sclk_doff21": 4, "sclk_doff210": 4, "sclk_doff22": 4, "sclk_doff23": 4, "sclk_doff24": 4, "sclk_doff25": 4, "sclk_doff26": 4, "sclk_doff27": 4, "sclk_doff28": 4, "sclk_doff29": 4, "sclk_don11": 4, "sclk_don110": 4, "sclk_don12": 4, "sclk_don13": 4, "sclk_don14": 4, "sclk_don15": 4, "sclk_don16": 4, "sclk_don17": 4, "sclk_don18": 4, "sclk_don19": 4, "sclk_don21": 4, "sclk_don210": 4, "sclk_don22": 4, "sclk_don23": 4, "sclk_don24": 4, "sclk_don25": 4, "sclk_don26": 4, "sclk_don27": 4, "sclk_don28": 4, "sclk_don29": 4, "sclk_hoff1": 4, "sclk_hoff10": 4, "sclk_hoff2": 4, "sclk_hoff3": 4, "sclk_hoff4": 4, "sclk_hoff5": 4, "sclk_hoff6": 4, "sclk_hoff7": 4, "sclk_hoff8": 4, "sclk_hoff9": 4, "sclk_hon1": 4, "sclk_hon10": 4, "sclk_hon2": 4, "sclk_hon3": 4, "sclk_hon4": 4, "sclk_hon5": 4, "sclk_hon6": 4, "sclk_hon7": 4, "sclk_hon8": 4, "sclk_hon9": 4, "sclk_moff1": 4, "sclk_moff10": 4, "sclk_moff2": 4, "sclk_moff3": 4, "sclk_moff4": 4, "sclk_moff5": 4, "sclk_moff6": 4, "sclk_moff7": 4, "sclk_moff8": 4, "sclk_moff9": 4, "sclk_mon1": 4, "sclk_mon10": 4, "sclk_mon2": 4, "sclk_mon3": 4, "sclk_mon4": 4, "sclk_mon5": 4, "sclk_mon6": 4, "sclk_mon7": 4, "sclk_mon8": 4, "sclk_mon9": 4, "seqip_1": 4, "seqip_2": 4, "seqip_3": 4, "seqip_4": 4, "seqip_5": 4, "skfact1": 4, "skfact2": 4, "skfact3": 4, "sl1": 4, "sl1max": 4, "sl2": 4, "sl2max": 4, "sl3": 4, "sl3max": 5, "st_exe": 5, "st_int": 5, "sthd_i1": 5, "sthd_i2": 5, "sthd_i3": 5, "sthd_u1": 5, "sthd_u2": 5, "sthd_u3": 5, "subject": 5, "sym_t": 5, "t_exe": 5, "t_exe_max": 5, "t_exe_min": 5, "t_int": 5, "t_int_max": 5, "t_int_min": 5, "temp": 5, "temp_ext_t": 5, "temp_int_t": 5, "thd_i1": 5, "thd_i1_max": 5, "thd_i1_t": 5, "thd_i2": 5, "thd_i2_max": 5, "thd_i2_t": 5, "thd_i3": 5, "thd_i3_max": 5, "thd_i3_t": 5, "thd_u1": 5, "thd_u1_max": 5, "thd_u1_t": 5, "thd_u2": 5, "thd_u2_max": 5, "thd_u2_t": 5, "thd_u3": 5, "thd_u3_max": 5, "thd_u3_t": 5, "tr_il1max_act": 5, "tr_il1max_act":5, "tr_il1max_lev": 5, "tr_il1max_pre": 5, "tr_il1max_tail": 5, "tr_il2max_act": 5, "tr_il2max_act":5, "tr_il2max_lev": 5, "tr_il2max_pre": 5, "tr_il2max_tail": 5, "tr_il3max_act": 5, "tr_il3max_act":5, "tr_il3max_lev": 5, "tr_il3max_pre": 5, "tr_il3max_tail": 5, "tr_ul1max_act": 5, "tr_ul1max_act":5, "tr_ul1max_lev": 5, "tr_ul1max_pre": 5, "tr_ul1max_tail": 5, "tr_ul1min_act": 5, "tr_ul1min_act":5, "tr_ul1min_lev": 5, "tr_ul1min_pre": 5, "tr_ul1min_tail": 5, "tr_ul2max_act": 5, "tr_ul2max_act":5, "tr_ul2max_lev": 5, "tr_ul2max_pre": 5, "tr_ul2max_tail": 5, "tr_ul2min_act": 5, "tr_ul2min_act":5, "tr_ul2min_lev": 5, "tr_ul2min_pre": 5, "tr_ul2min_tail": 5, "tr_ul3max_act": 5, "tr_ul3max_act":5, "tr_ul3max_lev": 5, "tr_ul3max_pre": 5, "tr_ul3max_tail": 5, "tr_ul3min_act": 5, "tr_ul3min_act":5, "tr_ul3min_lev": 5, "tr_ul3min_pre": 5, "tr_ul3min_tail": 5, "u0": 5, "u0max": 5, "u0min": 5, "u0s": 5, "u1": 5, "u1_t": 5, "u1dft1": 5, "u1dft11": 5, "u1dft13": 5, "u1dft15": 5, "u1dft3": 5, "u1dft5": 5, "u1dft7": 5, "u1dft9": 5, "u1dftm1": 5, "u1dftm11": 5, "u1dftm13": 5, "u1dftm15": 5, "u1dftm3": 5, "u1dftm5": 5, "u1dftm7": 5, "u1dftm9": 5, "u1dfts1": 5, "u1dfts11": 5, "u1dfts13": 5, "u1dfts15": 5, "u1dfts3": 5, "u1dfts5": 5, "u1dfts7": 5, "u1dfts9": 5, "u1max": 5, "u1min": 5, "u1s": 5, "u2": 5, "u2_t": 5, "u2dft1": 5, "u2dft11": 5, "u2dft13": 5, "u2dft15": 5, "u2dft3": 5, "u2dft5": 5, "u2dft7": 5, "u2dft9": 5, "u2dftm1": 5, "u2dftm11": 5, "u2dftm13": 5, "u2dftm15": 5, "u2dftm3": 5, "u2dftm5": 5, "u2dftm7": 5, "u2dftm9": 5, "u2dfts1": 5, "u2dfts11": 5, "u2dfts13": 5, "u2dfts15": 5, "u2dfts3": 5, "u2dfts5": 5, "u2dfts7": 5, "u2dfts9": 5, "u2max": 5, "u2min": 5, "u2s": 5, "u3_t": 5, "u3dft1": 5, "u3dft11": 5, "u3dft13": 5, "u3dft15": 5, "u3dft3": 5, "u3dft5": 5, "u3dft7": 5, "u3dft9": 5, "u3dftm1": 5, "u3dftm11": 5, "u3dftm13": 5, "u3dftm15": 5, "u3dftm3": 5, "u3dftm5": 5, "u3dftm7": 5, "u3dftm9": 5, "u3dfts1": 5, "u3dfts11": 5, "u3dfts13": 5, "u3dfts15": 5, "u3dfts3": 5, "u3dfts5": 5, "u3dfts7": 5, "u3dfts9": 5, "ul1": 5, "ul12": 5, "ul12_t": 5, "ul12max": 5, "ul12min": 5, "ul12s": 5, "ul1max": 5, "ul1min": 5, "ul1s": 5, "ul2": 5, "ul23": 5, "ul23_t": 5, "ul23max": 5, "ul23min": 5, "ul23s": 5, "ul2max": 5, "ul2min": 5, "ul2s": 5, "ul3": 5, "ul31": 5, "ul31_t": 5, "ul31max": 5, "ul31min": 5, "ul31s": 5, "ul3max": 5, "ul3min": 5, "ul3s": 5, "usym": 5, "usymmax": 5, "usymmin": 5, "usyms": 5, "vkndest_1": 5, "vkndest_10": 5, "vkndest_100": 5, "vkndest_101": 5, "vkndest_102": 5, "vkndest_103": 5, "vkndest_104": 5, "vkndest_105": 5, "vkndest_106": 5, "vkndest_107": 5, "vkndest_108": 5, "vkndest_109": 5, "vkndest_11": 5, "vkndest_110": 5, "vkndest_111": 5, "vkndest_112": 5, "vkndest_113": 5, "vkndest_114": 5, "vkndest_115": 5, "vkndest_116": 5, "vkndest_117": 5, "vkndest_118": 5, "vkndest_119": 5, "vkndest_12": 5, "vkndest_120": 5, "vkndest_121": 5, "vkndest_122": 5, "vkndest_123": 5, "vkndest_124": 5, "vkndest_125": 6, "vkndest_126": 6, "vkndest_127": 6, "vkndest_128": 6, "vkndest_13": 6, "vkndest_14": 6, "vkndest_15": 6, "vkndest_16": 6, "vkndest_17": 6, "vkndest_18": 6, "vkndest_19": 6, "vkndest_2": 6, "vkndest_20": 6, "vkndest_21": 6, "vkndest_22": 6, "vkndest_23": 6, "vkndest_24": 6, "vkndest_25": 6, "vkndest_26": 6, "vkndest_27": 6, "vkndest_28": 6, "vkndest_29": 6, "vkndest_3": 6, "vkndest_30": 6, "vkndest_31": 6, "vkndest_32": 6, "vkndest_33": 6, "vkndest_34": 6, "vkndest_35": 6, "vkndest_36": 6, "vkndest_37": 6, "vkndest_38": 6, "vkndest_39": 6, "vkndest_4": 6, "vkndest_40": 6, "vkndest_41": 6, "vkndest_42": 6, "vkndest_43": 6, "vkndest_44": 6, "vkndest_45": 6, "vkndest_46": 6, "vkndest_47": 6, "vkndest_48": 6, "vkndest_49": 6, "vkndest_5": 6, "vkndest_50": 6, "vkndest_51": 6, "vkndest_52": 6, "vkndest_53": 6, "vkndest_54": 6, "vkndest_55": 6, "vkndest_56": 6, "vkndest_57": 6, "vkndest_58": 6, "vkndest_59": 6, "vkndest_6": 6, "vkndest_60": 6, "vkndest_61": 6, "vkndest_62": 6, "vkndest_63": 6, "vkndest_64": 6, "vkndest_65": 6, "vkndest_66": 6, "vkndest_67": 6, "vkndest_68": 6, "vkndest_69": 6, "vkndest_7": 6, "vkndest_70": 6, "vkndest_71": 6, "vkndest_72": 6, "vkndest_73": 6, "vkndest_74": 6, "vkndest_75": 6, "vkndest_76": 6, "vkndest_77": 6, "vkndest_78": 6, "vkndest_79": 6, "vkndest_8": 6, "vkndest_80": 6, "vkndest_81": 6, "vkndest_82": 6, "vkndest_83": 6, "vkndest_84": 6, "vkndest_85": 6, "vkndest_86": 6, "vkndest_87": 6, "vkndest_88": 6, "vkndest_89": 6, "vkndest_9": 6, "vkndest_90": 6, "vkndest_91": 6, "vkndest_92": 6, "vkndest_93": 6, "vkndest_94": 6, "vkndest_95": 6, "vkndest_96": 6, "vkndest_97": 6, "vkndest_98": 6, "vkndest_99": 6, "vknlg_1": 6, "vknlg_10": 6, "vknlg_100": 6, "vknlg_101": 6, "vknlg_102": 6, "vknlg_103": 6, "vknlg_104": 6, "vknlg_105": 6, "vknlg_106": 6, "vknlg_107": 6, "vknlg_108": 6, "vknlg_109": 6, "vknlg_11": 6, "vknlg_110": 6, "vknlg_111": 6, "vknlg_112": 6, "vknlg_113": 6, "vknlg_114": 6, "vknlg_115": 6, "vknlg_116": 6, "vknlg_117": 6, "vknlg_118": 6, "vknlg_119": 6, "vknlg_12": 6, "vknlg_120": 6, "vknlg_121": 6, "vknlg_122": 6, "vknlg_123": 6, "vknlg_124": 6, "vknlg_125": 6, "vknlg_126": 6, "vknlg_127": 6, "vknlg_128": 6, "vknlg_13": 6, "vknlg_14": 6, "vknlg_15": 6, "vknlg_16": 6, "vknlg_17": 6, "vknlg_18": 6, "vknlg_19": 6, "vknlg_2": 6, "vknlg_20": 6, "vknlg_21": 6, "vknlg_22": 6, "vknlg_23": 6, "vknlg_24": 6, "vknlg_25": 6, "vknlg_26": 6, "vknlg_27": 6, "vknlg_28": 6, "vknlg_29": 6, "vknlg_3": 6, "vknlg_30": 6, "vknlg_31": 6, "vknlg_32": 6, "vknlg_33": 6, "vknlg_34": 6, "vknlg_35": 6, "vknlg_36": 6, "vknlg_37": 6, "vknlg_38": 6, "vknlg_39": 6, "vknlg_4": 6, "vknlg_40": 6, "vknlg_41": 6, "vknlg_42": 6, "vknlg_43": 6, "vknlg_44": 6, "vknlg_45": 6, "vknlg_46": 6, "vknlg_47": 6, "vknlg_48": 6, "vknlg_49": 6, "vknlg_5": 6, "vknlg_50": 6, "vknlg_51": 6, "vknlg_52": 6, "vknlg_53": 6, "vknlg_54": 6, "vknlg_55": 6, "vknlg_56": 6, "vknlg_57": 6, "vknlg_58": 6, "vknlg_59": 6, "vknlg_6": 6, "vknlg_60": 6, "vknlg_61": 6, "vknlg_62": 6, "vknlg_63": 6, "vknlg_64": 6, "vknlg_65": 6, "vknlg_66": 6, "vknlg_67": 6, "vknlg_68": 6, "vknlg_69": 6, "vknlg_7": 6, "vknlg_70": 6, "vknlg_71": 6, "vknlg_72": 6, "vknlg_73": 6, "vknlg_74": 6, "vknlg_75": 6, "vknlg_76": 6, "vknlg_77": 6, "vknlg_78": 6, "vknlg_79": 6, "vknlg_8": 6, "vknlg_80": 6, "vknlg_81": 6, "vknlg_82": 6, "vknlg_83": 6, "vknlg_84": 6, "vknlg_85": 6, "vknlg_86": 6, "vknlg_87": 6, "vknlg_88": 6, "vknlg_89": 6, "vknlg_9": 6, "vknlg_90": 6, "vknlg_91": 6, "vknlg_92": 6, "vknlg_93": 6, "vknlg_94": 6, "vknlg_95": 6, "vknlg_96": 6, "vknlg_97": 6, "vknlg_98": 6, "vknlg_99": 6, "vkns1_1": 6, "vkns1_10": 6, "vkns1_100": 6, "vkns1_101": 7, "vkns1_102": 7, "vkns1_103": 7, "vkns1_104": 7, "vkns1_105": 7, "vkns1_106": 7, "vkns1_107": 7, "vkns1_108": 7, "vkns1_109": 7, "vkns1_11": 7, "vkns1_110": 7, "vkns1_111": 7, "vkns1_112": 7, "vkns1_113": 7, "vkns1_114": 7, "vkns1_115": 7, "vkns1_116": 7, "vkns1_117": 7, "vkns1_118": 7, "vkns1_119": 7, "vkns1_12": 7, "vkns1_120": 7, "vkns1_121": 7, "vkns1_122": 7, "vkns1_123": 7, "vkns1_124": 7, "vkns1_125": 7, "vkns1_126": 7, "vkns1_127": 7, "vkns1_128": 7, "vkns1_13": 7, "vkns1_14": 7, "vkns1_15": 7, "vkns1_16": 7, "vkns1_17": 7, "vkns1_18": 7, "vkns1_19": 7, "vkns1_2": 7, "vkns1_20": 7, "vkns1_21": 7, "vkns1_22": 7, "vkns1_23": 7, "vkns1_24": 7, "vkns1_25": 7, "vkns1_26": 7, "vkns1_27": 7, "vkns1_28": 7, "vkns1_29": 7, "vkns1_3": 7, "vkns1_30": 7, "vkns1_31": 7, "vkns1_32": 7, "vkns1_33": 7, "vkns1_34": 7, "vkns1_35": 7, "vkns1_36": 7, "vkns1_37": 7, "vkns1_38": 7, "vkns1_39": 7, "vkns1_4": 7, "vkns1_40": 7, "vkns1_41": 7, "vkns1_42": 7, "vkns1_43": 7, "vkns1_44": 7, "vkns1_45": 7, "vkns1_46": 7, "vkns1_47": 7, "vkns1_48": 7, "vkns1_49": 7, "vkns1_5": 7, "vkns1_50": 7, "vkns1_51": 7, "vkns1_52": 7, "vkns1_53": 7, "vkns1_54": 7, "vkns1_55": 7, "vkns1_56": 7, "vkns1_57": 7, "vkns1_58": 7, "vkns1_59": 7, "vkns1_6": 7, "vkns1_60": 7, "vkns1_61": 7, "vkns1_62": 7, "vkns1_63": 7, "vkns1_64": 7, "vkns1_65": 7, "vkns1_66": 7, "vkns1_67": 7, "vkns1_68": 7, "vkns1_69": 7, "vkns1_7": 7, "vkns1_70": 7, "vkns1_71": 7, "vkns1_72": 7, "vkns1_73": 7, "vkns1_74": 7, "vkns1_75": 7, "vkns1_76": 7, "vkns1_77": 7, "vkns1_78": 7, "vkns1_79": 7, "vkns1_8": 7, "vkns1_80": 7, "vkns1_81": 7, "vkns1_82": 7, "vkns1_83": 7, "vkns1_84": 7, "vkns1_85": 7, "vkns1_86": 7, "vkns1_87": 7, "vkns1_88": 7, "vkns1_89": 7, "vkns1_9": 7, "vkns1_90": 7, "vkns1_91": 7, "vkns1_92": 7, "vkns1_93": 7, "vkns1_94": 7, "vkns1_95": 7, "vkns1_96": 7, "vkns1_97": 7, "vkns1_98": 7, "vkns1_99": 7, "vkns2_1": 7, "vkns2_10": 7, "vkns2_100": 7, "vkns2_101": 7, "vkns2_102": 7, "vkns2_103": 7, "vkns2_104": 7, "vkns2_105": 7, "vkns2_106": 7, "vkns2_107": 7, "vkns2_108": 7, "vkns2_109": 7, "vkns2_11": 7, "vkns2_110": 7, "vkns2_111": 7, "vkns2_112": 7, "vkns2_113": 7, "vkns2_114": 7, "vkns2_115": 7, "vkns2_116": 7, "vkns2_117": 7, "vkns2_118": 7, "vkns2_119": 7, "vkns2_12": 7, "vkns2_120": 7, "vkns2_121": 7, "vkns2_122": 7, "vkns2_123": 7, "vkns2_124": 7, "vkns2_125": 7, "vkns2_126": 7, "vkns2_127": 7, "vkns2_128": 7, "vkns2_13": 7, "vkns2_14": 7, "vkns2_15": 7, "vkns2_16": 7, "vkns2_17": 7, "vkns2_18": 7, "vkns2_19": 7, "vkns2_2": 7, "vkns2_20": 7, "vkns2_21": 7, "vkns2_22": 7, "vkns2_23": 7, "vkns2_24": 7, "vkns2_25": 7, "vkns2_26": 7, "vkns2_27": 7, "vkns2_28": 7, "vkns2_29": 7, "vkns2_3": 7, "vkns2_30": 7, "vkns2_31": 7, "vkns2_32": 7, "vkns2_33": 7, "vkns2_34": 7, "vkns2_35": 7, "vkns2_36": 7, "vkns2_37": 7, "vkns2_38": 7, "vkns2_39": 7, "vkns2_4": 7, "vkns2_40": 7, "vkns2_41": 7, "vkns2_42": 7, "vkns2_43": 7, "vkns2_44": 7, "vkns2_45": 7, "vkns2_46": 7, "vkns2_47": 7, "vkns2_48": 7, "vkns2_49": 7, "vkns2_5": 7, "vkns2_50": 7, "vkns2_51": 7, "vkns2_52": 7, "vkns2_53": 7, "vkns2_54": 7, "vkns2_55": 7, "vkns2_56": 7, "vkns2_57": 7, "vkns2_58": 7, "vkns2_59": 7, "vkns2_6": 7, "vkns2_60": 7, "vkns2_61": 7, "vkns2_62": 7, "vkns2_63": 7, "vkns2_64": 7, "vkns2_65": 7, "vkns2_66": 7, "vkns2_67": 7, "vkns2_68": 7, "vkns2_69": 7, "vkns2_7": 7, "vkns2_70": 7, "vkns2_71": 7, "vkns2_72": 7, "vkns2_73": 7, "vkns2_74": 7, "vkns2_75": 7, "vkns2_76": 7, "vkns2_77": 7, "vkns2_78": 7, "vkns2_79": 8, "vkns2_8": 8, "vkns2_80": 8, "vkns2_81": 8, "vkns2_82": 8, "vkns2_83": 8, "vkns2_84": 8, "vkns2_85": 8, "vkns2_86": 8, "vkns2_87": 8, "vkns2_88": 8, "vkns2_89": 8, "vkns2_9": 8, "vkns2_90": 8, "vkns2_91": 8, "vkns2_92": 8, "vkns2_93": 8, "vkns2_94": 8, "vkns2_95": 8, "vkns2_96": 8, "vkns2_97": 8, "vkns2_98": 8, "vkns2_99": 8, "vtpri": 8, "vtpri":8, "vtsec": 8, "wh0": 8, "wh1": 8, "wh2": 8, "wh3": 8, "wh4": 8, "wh_storre_t_0": 8, "wh_storre_t_0":8, "wh_storre_t_1": 8, "wh_storre_t_1":8, "wh_storre_t_2": 8, "wh_storre_t_2":8, "wh_storre_t_3": 8, "wh_storre_t_3":8, "wh_storre_t_4": 8, "wh_storre_t_4":8, "whv0": 8, "whv1": 8, "whv2": 8, "whv3": 8, "whv4": 8, "whv_storre_t_0": 8, "whv_storre_t_0":8, "whv_storre_t_1": 8, "whv_storre_t_1":8, "whv_storre_t_2": 8, "whv_storre_t_2":8, "whv_storre_t_3": 8, "whv_storre_t_3":8, "whv_storre_t_4": 8, "whv_storre_t_4":8, "whz0": 8, "whz1": 8, "whz2": 8, "whz3": 8, "whz4": 8, "whz_storre_t_0": 8, "whz_storre_t_0":8, "whz_storre_t_1": 8, "whz_storre_t_1":8, "whz_storre_t_2": 8, "whz_storre_t_2":8, "whz_storre_t_3": 8, "whz_storre_t_3":8, "whz_storre_t_4": 8, "whz_storre_t_4":8, "isl1max": 8, "isl2max": 8, "isl3max": 8, "issmax": 8, "ul1max_t": 8, "ul2max_t": 8, "ul3max_t": 8, "ul12max_t": 8, "ul23max_t": 8, "ul31max_t": 8, "il1max_t": 8, "il2max_t": 8, "il3max_t": 8, "ismax_t": 8, "phil1max_t": 8, "phil2max_t": 8, "phil3max_t": 8, "phismax_t": 8, "pl1max_t": 8, "pl2max_t": 8, "pl3max_t": 8, "psmax": 8, "psmax_t": 8, "ql1max_t": 8, "ql2max_t": 8, "ql3max_t": 8, "qsmax_t": 8, "sl1max_t": 8, "sl2max_t": 8, "sl3max_t": 8, "ssmax_t": 8, "fl1max_t": 8, "u2max_t": 8, "u1max_t": 8, "u0max_t": 8, "usymmax_t": 8, "kfactmax1_t": 8, "kfactmax2_t": 8, "kfactmax3_t": 8, "psl1max_t": 8, "psl2max_t": 8, "psl3max_t": 8, "pssmax_t": 8, "isl1max_t": 8, "isl2max_t": 8, "isl3max_t": 8, "issmax_t": 8, "ul1min_t": 8, "ul2min_t": 8, "ul3min_t": 8, "ul12min_t": 8, "ul23min_t": 8, "ul31min_t": 8, "phil1min_t": 8, "phil2min_t": 8, "phil3min_t": 8, "phismin_t": 8, "fl1min_t": 8, "u2min_t": 8, "u1min_t": 8, "u0min_t": 8, "usymmin_t": 8, "thd_u1_max_t": 8, "thd_u2_max_t": 8, "thd_u3_max_t": 8, "thd_i1_max_t": 8, "thd_i2_max_t": 8, "thd_i3_max_t": 8, "t_int_max_t": 8, "t_exe_max_t": 8, "t_int_min_t": 8, "t_exe_min_t": 8, "anlo_in_max_t": 8, "anlo_in_min_t": 8, "so_in1max_t": 8, "so_in2max_t": 8, "so_in3max_t": 8, "so_in4max_t": 8, "so_in5max_t": 8, "so_in6max_t": 8, "pl1s": 8, "pl2s": 8, "pl3s": 8, "pl1s_t": 8, "pl2s_t": 8, "pl3s_t": 8, "pss_t": 8, "pss": 8, "ps": 8, "qs": 8, "ql1s": 8, "ql2s": 8, "ql3s": 8, "qss": 8, "ql1s_t": 8, "ql2s_t": 8, "ql3s_t": 8, "qss_t": 8, "qsmax": 8, "phis": 8, "sl1s": 8, "sl2s": 8, "sl3s": 8, "ss": 8, "sss": 8, "ssmax": 8, "vah0": 8, "vah1": 8, "vah2": 8, "vah3": 8, "vah4": 8, "so_in1": 8, "so_in2": 8, "so_in3": 8, "so_in4": 8, "so_in5": 8, "so_in6": 8, "sso_in1": 8, "sso_in2": 8, "sso_in3": 8, "sso_in4": 8, "sso_in5": 8, "sso_in6": 8, "so_in1max": 8, "so_in2max": 8, "so_in3max": 8, "so_in4max": 8, "so_in5max": 8, "so_in6max": 8, "st_int":8, "st_exe":8, "": 0}
/////////////////////////////////////////////////////////////////////////////
var Varlist510 = new Object();
var TRANS_TBL_510 = [
    "", "bincntdt0", "bincntdt1",
    "bincntdt2", "bincntdt3", "bincntdt4", "bincntdt5", "bincntdt6",
    "bincntdt7", "bincntr0[0]", "bincntr0[1]", "bincntr0[2]",
    "bincntr0[3]", "bincntr0[4]", "bincntr1[0]", "bincntr1[1]",
    "bincntr1[2]", "bincntr1[3]", "bincntr1[4]", "bincntr2[0]",
    "bincntr2[1]", "bincntr2[2]", "bincntr2[3]", "bincntr2[4]",
    "bincntr3[0]", "bincntr3[1]", "bincntr3[2]", "bincntr3[3]",
    "bincntr3[4]", "bincntr4[0]", "bincntr4[1]", "bincntr4[2]",
    "bincntr4[3]", "bincntr4[4]", "bincntr5[0]", "bincntr5[1]",
    "bincntr5[2]", "bincntr5[3]", "bincntr5[4]", "bincntr6[0]",
    "bincntr6[1]", "bincntr6[2]", "bincntr6[3]", "bincntr6[4]",
    "bincntr7[0]", "bincntr7[1]", "bincntr7[2]", "bincntr7[3]",
    "bincntr7[4]", "binfrq[0]", "binfrq[1]", "binfrq[2]", "binfrq[3]",
    "binfrq[4]", "binfrq[5]", "binfrq[6]", "binfrq[7]", "binoutp[0]",
    "binoutp[1]", "binoutp[2]", "binoutp[3]", "binoutp[4]",
    "binval[0]", "binval[1]", "binval[2]", "binval[3]", "binval[4]",
    "binval[5]", "binval[6]", "binval[7]", "binxinp[0]", "binxinp[1]",
    "binxinp[2]", "binxinp[3]", "binxinp[4]", "binxinp[5]",
    "binxinp[6]", "binxinp[7]", "cmpstat[0]", "cmpstat[1]",
    "cmpstat[2]", "cmpstat[3]", "cmpstat[4]", "cmpstat[5]",
    "cmpstat[6]", "cmpstat[7]", "D0", "D1", "D2", "D3", "finput",
    "fliinstU0", "fliinstU1", "fliinstU2", "fliinstU3", "fliPltU0",
    "fliPltU1", "fliPltU2", "fliPltU3", "fliPstU0", "fliPstU1",
    "fliPstU2", "fliPstU3", "fundangle0", "fundangle1", "fundangle2",
    "fundangle3", "fundDPF0", "fundDPF012", "fundDPF1", "fundDPF2",
    "fundDPF3", "fundIabs0", "fundIabs1", "fundIabs2", "fundIabs3",
    "fundIim0", "fundIim1", "fundIim2", "fundIim3", "fundIre0",
    "fundIre1", "fundIre2", "fundIre3", "fundP0", "fundP012", "fundP1",
    "fundP2", "fundP3", "fundQ0", "fundQ012", "fundQ1", "fundQ2",
    "fundQ3", "fundS0", "fundS012", "fundS1", "fundS2", "fundS3",
    "fundUabs0", "fundUabs1", "fundUabs2", "fundUabs3", "fundUim0",
    "fundUim1", "fundUim12", "fundUim20", "fundUim3", "fundUre0",
    "fundUre1", "fundUre12", "fundUre20", "fundUre3", "Icf0", "Icf1",
    "Icf2", "Icf3", "IHDI0", "IHDI1", "IHDI2", "IHDI3", "IHDU0",
    "IHDU1", "IHDU2", "IHDU3", "inpcntr[0]", "inpcntr[1]",
    "inpcntr[2]", "inpcntr[3]", "inpcntr[4]", "inpcntr[5]",
    "inpcntr[6]", "inpcntr[7]", "intcQ012[0]", "intcQ012[1]",
    "intcQ012[2]", "intcQ012[3]", "intcQ012[4]", "intcQ3[0]",
    "intcQ3[1]", "intcQ3[1]", "intcQ3[2]", "intcQ3[3]", "intcQ3[4]",
    "intiQ012[0]", "intiQ012[1]", "intiQ012[2]", "intiQ012[3]",
    "intiQ012[4]", "intiQ3[0]", "intiQ3[1]", "intiQ3[2]", "intiQ3[3]",
    "intiQ3[4]", "intnP012[0]", "intnP012[1]", "intnP012[2]",
    "intnP012[3]", "intnP012[4]", "intnP3[0]", "intnP3[1]",
    "intnP3[2]", "intnP3[3]", "intnP3[4]", "intpP012[0]",
    "intpP012[1]", "intpP012[2]", "intpP012[3]", "intpP012[4]",
    "intpP3[0]", "intpP3[1]", "intpP3[2]", "intpP3[3]", "intpP3[4]",
    "intS012[0]", "intS012[1]", "intS012[2]", "intS012[3]",
    "intS012[4]", "intS3[0]", "intS3[1]", "intS3[2]", "intS3[3]",
    "intS3[4]", "Iover0", "Iover1", "Iover2", "Iover3", "Ipkn0",
    "Ipkn1", "Ipkn2", "Ipkn3", "Ipkp0", "Ipkp1", "Ipkp2", "Ipkp3",
    "Iptp0", "Iptp1", "Iptp2", "Iptp3", "Irms0", "Irms1", "Irms2",
    "Irms3", "Iunbal012", "Iundr0", "Iundr1", "Iundr2", "Iundr3",
    "meastime0", "meastime1", "meastime2", "meastime3", "P0", "P1",
    "P2", "P3", "PF0", "Pf0", "PF1", "Pf1", "PF2", "Pf2", "Pf3", "PF3",
    "Q0", "Q1", "Q2", "Q3", "Qf0", "Qf1", "Qf2", "Qf3", "rcU0", "rcU1",
    "rcU2", "rcU3", "S0", "S1", "S2", "S3", "sc0I012", "sc0U012",
    "sc1I012", "sc1U012", "sc2I012", "sc2U012", "spU012", "sumI012",
    "sumI0123", "sumP012", "sumP012", "sumPF012", "sumQ012", "sumQ012",
    "sumS012", "sumS012", "systemp", "THDI0", "THDI1", "THDI2",
    "THDI3", "THDU0", "THDU1", "THDU2", "THDU3", "Ucf0", "Ucf1",
    "Ucf2", "Ucf3", "Uover0", "Uover1", "Uover2", "Uover3", "Upkn0",
    "Upkn1", "Upkn2", "Upkn3", "Upkp0", "Upkp1", "Upkp2", "Upkp3",
    "Uptp0", "Uptp1", "Uptp2", "Uptp3", "Urms02", "Urms10", "Urms21",
    "URrms0", "URrms1", "URrms2", "URrms3", "Uunbal012", "Uundr0",
    "Uundr1", "Uundr2", "Uundr3"
];
function populate510Varlist() {
    var maxPerFile = 100;
    var cnt = 0;
    var iPerFile = 0;

    for (var i = 1; i < TRANS_TBL_510.length; i++, iPerFile++) {
        if (iPerFile > maxPerFile) {
            iPerFile = 0;
            cnt++;
        }
        var varname = TRANS_TBL_510[i];
        Varlist510[varname] = cnt;

    }
    cnt++;
    for (var j = 0; j < 32; j++) {
        Varlist510[getNameForID_static(1000 + j * 100)] = (cnt + j);
    }

}

function getNameForID_static(i) {
    var s = "";
    if (i < 4200) {
        switch (i / 100) {
            case 10: // '\n'
                s = "hrmIabs0";
                break;

            case 11: // '\013'
                s = "hrmIabs1";
                break;

            case 12: // '\f'
                s = "hrmIabs2";
                break;

            case 13: // '\r'
                s = "hrmIabs3";
                break;

            case 14: // '\016'
                s = "hrmIrel0";
                break;

            case 15: // '\017'
                s = "hrmIrel1";
                break;

            case 16: // '\020'
                s = "hrmIrel2";
                break;

            case 17: // '\021'
                s = "hrmIrel3";
                break;

            case 18: // '\022'
                s = "hrmUabs0";
                break;

            case 19: // '\023'
                s = "hrmUabs1";
                break;

            case 20: // '\024'
                s = "hrmUabs2";
                break;

            case 21: // '\025'
                s = "hrmUabs3";
                break;

            case 22: // '\026'
                s = "hrmUrel0";
                break;

            case 23: // '\027'
                s = "hrmUrel1";
                break;

            case 24: // '\030'
                s = "hrmUrel2";
                break;

            case 25: // '\031'
                s = "hrmUrel3";
                break;

            case 26: // '\032'
                s = "ihrmIabs0";
                break;

            case 27: // '\033'
                s = "ihrmIabs1";
                break;

            case 28: // '\034'
                s = "ihrmIabs2";
                break;

            case 29: // '\035'
                s = "ihrmIabs3";
                break;

            case 30: // '\036'
                s = "ihrmIrel0";
                break;

            case 31: // '\037'
                s = "ihrmIrel1";
                break;

            case 32: // ' '
                s = "ihrmIrel2";
                break;

            case 33: // '!'
                s = "ihrmIrel3";
                break;

            case 34: // '"'
                s = "ihrmUabs0";
                break;

            case 35: // '#'
                s = "ihrmUabs1";
                break;

            case 36: // '$'
                s = "ihrmUabs2";
                break;

            case 37: // '%'
                s = "ihrmUabs3";
                break;

            case 38: // '&'
                s = "ihrmUrel0";
                break;

            case 39: // '\''
                s = "ihrmUrel1";
                break;

            case 40: // '('
                s = "ihrmUrel2";
                break;

            case 41: // ')'
                s = "ihrmUrel3";
                break;
        }
        //  s = s + (i % 100) + "]";
    } // else
    return s;
}
/////////////////////////////////////////////////////////////////////////////
